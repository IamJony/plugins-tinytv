// Sanson: YouTube straight to innertube. Lists, channels, metadata and the live chat come from
// the web client; the streams from the VisionOS client, whose googlevideo URLs play as they are
// (no signature to decipher, no PO token). GPL-3.0-or-later.

const PLATFORM = "YouTube";
const YT = "https://www.youtube.com";
const WEB = { clientName: "WEB", clientVersion: "2.20251030.01.00", hl: "es" };
// Player clients, in order. VisionOS gives every quality as plain URLs; iOS is the second chance.
const PLAYERS = [
    {
        name: "VisionOS",
        ua: "com.google.visionos.youtube/1.04 (RealityDevice17,1; U; CPU visionOS 26_6_0 like Mac OS X; US) gzip",
        client: { clientName: "VISIONOS", clientVersion: "1.04", deviceMake: "Apple", deviceModel: "RealityDevice17,1",
                  osName: "visionOS", osVersion: "26.6.0", hl: "es" }
    },
    {
        name: "iOS",
        ua: "com.google.ios.youtube/20.10.4 (iPhone16,2; U; CPU iOS 18_3_2 like Mac OS X;)",
        client: { clientName: "IOS", clientVersion: "20.10.4", deviceMake: "Apple", deviceModel: "iPhone16,2",
                  osName: "iPhone", osVersion: "18.3.2.22D82", hl: "es" }
    }
];
// Browse params of channel tabs and the channels search filter.
const TAB_VIDEOS = "EgZ2aWRlb3PyBgQKAjoA";
const TAB_LIVE = "EgdzdHJlYW1z8gYECgJ6AA%3D%3D";
const TAB_SHORTS = "EgZzaG9ydHPyBgUKA5oBAA%3D%3D";
const ONLY_CHANNELS = "EgIQAg%3D%3D";
// Home without an account: YouTube's own topic channels (music, live, news, sports, gaming).
const TOPICS = ["UC-9-kyTW8ZkZNDHQJ6FgpwQ", "UC4R8DWoMoI7CAwX8_LjQHig", "UCYfdidRxbB8Qhf0Nx7ioOYw",
                "UCEgdi0XIXXZ-qJOFPf4JSKw", "UCOpNcN46UbXVtpKMrmU4Abg"];

let state = { visitorData: "", at: 0 };
let lastSubtitles = [];

source.enable = function (conf, settings, saved) {
    try {
        const s = JSON.parse(saved ?? "null");
        if (s?.visitorData && Date.now() / 1000 - s.at < 3 * 86400)
            state = s;
    } catch (e) {
    }
};

source.saveState = function () {
    return JSON.stringify(state);
};

function logged() {
    return bridge.isLoggedIn();
}

// --- innertube -----------------------------------------------------------------------------

function api(endpoint, body, auth) {
    const useAuth = auth ?? logged();
    const client = Object.assign({}, WEB);
    if (state.visitorData && !useAuth)
        client.visitorData = state.visitorData;
    const headers = {
        "Content-Type": "application/json",
        "Origin": YT,
        "X-Origin": YT,
        "Referer": YT + "/",
        "X-Youtube-Client-Name": "1",
        "X-Youtube-Client-Version": WEB.clientVersion
    };
    if (useAuth)
        headers["X-Goog-AuthUser"] = "0";
    const d = sansonJson("POST", YT + "/youtubei/v1/" + endpoint + "?prettyPrint=false",
        JSON.stringify(Object.assign({ context: { client } }, body)), headers, useAuth, "YouTube");
    const vd = d?.responseContext?.visitorData;
    if (vd && !useAuth && vd !== state.visitorData) {
        state.visitorData = vd;
        state.at = Math.floor(Date.now() / 1000);
    }
    return d;
}

// Without visitorData YouTube asks the player clients to "confirm you are not a bot" for lives.
function visitor() {
    if (!state.visitorData)
        api("visitor_id", {}, false);
    if (!state.visitorData)
        api("browse", { browseId: "FEwhat_to_watch" }, false);
    return state.visitorData;
}

function player(videoId, p) {
    const client = Object.assign({ visitorData: visitor() }, p.client);
    const body = { videoId, contentCheckOk: true, racyCheckOn: true, context: { client } };
    return sansonJson("POST", YT + "/youtubei/v1/player?prettyPrint=false", JSON.stringify(body),
        { "Content-Type": "application/json", "User-Agent": p.ua, "X-Goog-Api-Format-Version": "2" }, false, "YouTube");
}

// --- urls ----------------------------------------------------------------------------------

function videoIdOf(url) {
    const m = /(?:[?&]v=|youtu\.be\/|\/shorts\/|\/live\/|\/embed\/)([\w-]{11})/.exec(url ?? "");
    if (m)
        return m[1];
    // youtube.com/@channel/live and the like: ask YouTube what it points to.
    const r = api("navigation/resolve_url", { url }, false);
    const id = r?.endpoint?.watchEndpoint?.videoId;
    if (!id)
        throw new UnavailableException("No se reconoce el video: " + url);
    return id;
}

function channelUrl(id) {
    return YT + "/channel/" + id;
}

function playlistIdOf(url) {
    const m = /[?&]list=([\w-]+)/.exec(url ?? "");
    return m && !/[?&]v=/.test(url) ? m[1] : null;
}

function browseIdOf(url) {
    const m = /\/channel\/(UC[\w-]{22})/.exec(url ?? "");
    if (m)
        return m[1];
    const r = api("navigation/resolve_url", { url }, false);
    const id = r?.endpoint?.browseEndpoint?.browseId;
    if (!id)
        throw new UnavailableException("No se encontró el canal: " + url);
    return id;
}

// --- items -----------------------------------------------------------------------------------

function lastUrl(list) {
    const l = list ?? [];
    let u = l.length ? l[l.length - 1].url : "";
    if (u && u.startsWith("//"))
        u = "https:" + u;
    return u ?? "";
}

function findKey(o, key, depth) {
    if (!o || typeof o !== "object" || (depth ?? 0) > 25)
        return null;
    if (o[key] !== undefined)
        return o[key];
    for (const k in o) {
        const r = findKey(o[k], key, (depth ?? 0) + 1);
        if (r != null)
            return r;
    }
    return null;
}

function video(o) {
    return new PlatformVideo({
        id: sansonPid(PLATFORM, o.id),
        name: o.title ?? "",
        thumbnails: sansonThumbs("https://i.ytimg.com/vi/" + o.id + "/mqdefault.jpg"),
        author: sansonAuthor(PLATFORM, o.channelId, o.author, o.channelId ? channelUrl(o.channelId) : (o.authorUrl ?? ""), o.authorThumb),
        uploadDate: o.date ?? 0,
        duration: o.duration ?? 0,
        viewCount: o.views ?? -1,
        url: o.short ? YT + "/shorts/" + o.id : YT + "/watch?v=" + o.id,
        isLive: !!o.live
    });
}

function ownerOf(text) {
    const run = (text?.runs ?? []).find(r => r.navigationEndpoint?.browseEndpoint);
    return { author: sansonText(text), channelId: run?.navigationEndpoint?.browseEndpoint?.browseId ?? "" };
}

function fromVideoRenderer(v, def) {
    if (!v?.videoId || v.upcomingEventData)
        return null;
    const owner = ownerOf(v.ownerText ?? v.longBylineText ?? v.shortBylineText);
    const overlays = v.thumbnailOverlays ?? [];
    const timeStatus = overlays.map(o => o.thumbnailOverlayTimeStatusRenderer).find(Boolean);
    const live = (v.badges ?? []).some(b => /LIVE/.test(b.metadataBadgeRenderer?.style ?? "")) ||
        timeStatus?.style === "LIVE";
    const views = sansonText(v.viewCountText) || sansonText(v.shortViewCountText);
    const title = sansonText(v.title ?? v.headline);
    if (!title) // ads and promoted cards without data
        return null;
    return video({
        id: v.videoId,
        title,
        author: owner.author || def?.author,
        channelId: owner.channelId || def?.channelId,
        authorThumb: lastUrl(v.channelThumbnailSupportedRenderers?.channelThumbnailWithLinkRenderer?.thumbnail?.thumbnails ??
            v.channelThumbnail?.thumbnails) || def?.authorThumb,
        duration: live ? 0 : sansonSecs(sansonText(v.lengthText) || sansonText(timeStatus?.text)),
        views: sansonCount(views),
        date: sansonAgo(sansonText(v.publishedTimeText)),
        live
    });
}

function fromLockup(l, def) {
    const id = l?.contentId;
    if (!id)
        return null;
    const meta = l.metadata?.lockupMetadataViewModel ?? {};
    const title = sansonText(meta.title);
    const browse = findKey(meta.image, "browseEndpoint") ?? findKey(meta.metadata, "browseEndpoint");
    const rows = meta.metadata?.contentMetadataViewModel?.metadataRows ?? [];
    let author = "", views = -1, date = 0;
    for (const row of rows)
        for (const part of row.metadataParts ?? []) {
            const t = sansonText(part.text);
            const label = part.accessibilityLabel ?? t;
            if (/visualiz|vistas|views|espectador|watching|reproducc|mirando/i.test(label))
                views = sansonCount(t);
            else if (/hace|ago|emitid|stream|transmit/i.test(label))
                date = sansonAgo(label);
            else if (!author && browse && t)
                author = t;
        }
    const badges = findKey(l.contentImage, "badges") ?? [];
    let duration = 0, live = false, count = "";
    for (const b of badges) {
        const v = b.thumbnailBadgeViewModel;
        if (!v)
            continue;
        if (/LIVE/.test(v.badgeStyle ?? ""))
            live = true;
        else if (sansonSecs(v.text))
            duration = sansonSecs(v.text);
        else if (v.text)
            count = v.text;
    }
    if (l.contentType === "LOCKUP_CONTENT_TYPE_PLAYLIST" || l.contentType === "LOCKUP_CONTENT_TYPE_PODCAST") {
        if (id.startsWith("RD")) // automatic mixes: endless, they make no sense as a list here
            return null;
        const thumb = findKey(l.contentImage, "sources");
        return new PlatformPlaylist({
            id: sansonPid(PLATFORM, id),
            name: title,
            thumbnails: sansonThumbs(lastUrl(thumb)),
            author: sansonAuthor(PLATFORM, browse?.browseId ?? def?.channelId, author || def?.author,
                browse?.browseId ? channelUrl(browse.browseId) : "", null),
            url: YT + "/playlist?list=" + id,
            videoCount: sansonCount(count),
            sansonSubtitle: count
        });
    }
    if ((l.contentType && l.contentType !== "LOCKUP_CONTENT_TYPE_VIDEO") || !title)
        return null;
    return video({
        id, title, live, duration, views, date,
        author: author || def?.author,
        channelId: browse?.browseId || def?.channelId,
        authorThumb: lastUrl(findKey(meta.image, "sources")) || def?.authorThumb
    });
}

function fromShort(s, def) {
    const id = s.videoId ?? findKey(s.onTap, "reelWatchEndpoint")?.videoId;
    if (!id)
        return null;
    return video({
        id, short: true,
        author: def?.author, channelId: def?.channelId, authorThumb: def?.authorThumb,
        title: sansonText(s.headline) || sansonText(s.overlayMetadata?.primaryText),
        views: sansonCount(sansonText(s.viewCountText) || sansonText(s.overlayMetadata?.secondaryText))
    });
}

function fromChannelRenderer(c) {
    if (!c?.channelId)
        return null;
    // The new layout puts the subscribers in videoCountText and the @handle in subscriberCountText.
    const texts = [sansonText(c.subscriberCountText), sansonText(c.videoCountText)];
    const subs = texts.find(t => /suscript|subscri/i.test(t));
    return new PlatformChannel({
        id: sansonPid(PLATFORM, c.channelId),
        name: sansonText(c.title),
        thumbnail: lastUrl(c.thumbnail?.thumbnails),
        subscribers: subs ? sansonCount(subs) : -1,
        description: sansonText(c.descriptionSnippet),
        url: channelUrl(c.channelId)
    });
}

function fromPlaylistRenderer(p) {
    if (!p?.playlistId)
        return null;
    const owner = ownerOf(p.shortBylineText ?? p.longBylineText);
    const count = sansonText(p.videoCountText) || (p.videoCount ? p.videoCount + " videos" : "");
    return new PlatformPlaylist({
        id: sansonPid(PLATFORM, p.playlistId),
        name: sansonText(p.title),
        thumbnails: sansonThumbs(lastUrl(p.thumbnails?.[0]?.thumbnails ?? p.thumbnail?.thumbnails)),
        author: sansonAuthor(PLATFORM, owner.channelId, owner.author, owner.channelId ? channelUrl(owner.channelId) : "", null),
        url: YT + "/playlist?list=" + p.playlistId,
        videoCount: sansonCount(count),
        sansonSubtitle: count
    });
}

const SKIP = new Set(["frameworkUpdates", "topbar", "header", "responseContext", "menu", "sidebar", "trackingParams",
                      "commandMetadata", "loggingDirectives", "accessibility", "playerOverlays", "engagementPanels"]);

// Every video, channel and playlist under `root`, and the token of the next page.
function collect(root, def) {
    const items = [];
    const seen = new Set();
    let token = null;
    const add = v => {
        if (v && v.url && !seen.has(v.url)) {
            seen.add(v.url);
            items.push(v);
        }
    };
    const walk = (o, depth) => {
        if (!o || typeof o !== "object" || depth > 80)
            return;
        if (Array.isArray(o)) {
            for (const x of o)
                walk(x, depth + 1);
            return;
        }
        for (const k in o) {
            if (SKIP.has(k))
                continue;
            const v = o[k];
            switch (k) {
            case "videoRenderer":
            case "gridVideoRenderer":
            case "compactVideoRenderer":
            case "playlistVideoRenderer":
                add(fromVideoRenderer(v, def));
                continue;
            case "lockupViewModel":
                add(fromLockup(v, def));
                continue;
            case "reelItemRenderer":
            case "shortsLockupViewModel":
                add(fromShort(v, def));
                continue;
            case "channelRenderer":
            case "gridChannelRenderer":
                add(fromChannelRenderer(v));
                continue;
            case "playlistRenderer":
            case "gridPlaylistRenderer":
                add(fromPlaylistRenderer(v));
                continue;
            case "continuationItemRenderer":
                token = findKey(v, "continuationCommand")?.token ?? token;
                continue;
            }
            walk(v, depth + 1);
        }
    };
    walk(root, 0);
    return { items, token };
}

// A list that continues with innertube continuation tokens on the same endpoint.
function listPager(endpoint, first, auth, def) {
    const fetch = ctx => {
        const d = api(endpoint, { continuation: ctx.token }, ctx.auth);
        const r = collect(d.onResponseReceivedActions ?? d.onResponseReceivedEndpoints ?? d.continuationContents ?? d, ctx.def);
        return { results: r.items, more: !!r.token && r.items.length > 0, context: { token: r.token, auth: ctx.auth, def: ctx.def } };
    };
    return new SansonPager(fetch, null, {
        results: first.items,
        more: !!first.token,
        context: { token: first.token, auth: auth, def: def }
    });
}

// --- home, search, channels ---------------------------------------------------------------------

function related(videoId) {
    const d = api("next", { videoId }, false);
    return collect(d?.contents?.twoColumnWatchNextResults?.secondaryResults).items.filter(v => v instanceof PlatformVideo);
}

function topic(id) {
    try {
        return collect(api("browse", { browseId: id }, false)).items.filter(v => v instanceof PlatformVideo);
    } catch (e) {
        log("topic " + id + ": " + e);
        return [];
    }
}

// Home: the account's own recommendations; without one (or with the history paused), videos
// related to what was watched last in Sanson (`history`: urls, newest first) mixed with YouTube's
// topic channels.
source.getHome = function (history) {
    if (logged()) {
        try {
            const r = collect(api("browse", { browseId: "FEwhat_to_watch" }, true));
            if (r.items.length > 0)
                return listPager("browse", r, true);
        } catch (e) {
            log("home with account: " + e);
        }
    }
    const recent = (history ?? []).filter(u => /youtube\.com|youtu\.be/.test(u)).slice(0, 2);
    const fetch = ctx => {
        const lists = [];
        if (ctx.step === 0) {
            for (const u of recent) {
                try {
                    lists.push(related(videoIdOf(u)));
                } catch (e) {
                    log("related " + u + ": " + e);
                }
            }
            lists.push(topic(TOPICS[0]));
            if (recent.length === 0)
                lists.push(topic(TOPICS[1]));
        } else {
            lists.push(topic(TOPICS[ctx.step + (recent.length ? 0 : 1)] ?? ""));
        }
        const seen = new Set(ctx.seen ?? []);
        const results = sansonMix(lists, seen);
        const next = ctx.step + 1;
        return { results, more: TOPICS[next + (recent.length ? 0 : 1)] !== undefined, context: { step: next, seen: [...seen] } };
    };
    return new SansonPager(fetch, { step: 0 });
};

source.search = function (query) {
    const d = api("search", { query });
    return listPager("search", collect(d.contents));
};

source.searchChannels = function (query) {
    const d = api("search", { query, params: ONLY_CHANNELS });
    return new SansonChannelPager(collect(d.contents).items.filter(v => v instanceof PlatformChannel));
};

function channelHeader(d) {
    const meta = d?.metadata?.channelMetadataRenderer ?? {};
    const head = findKey(d?.header, "pageHeaderViewModel") ?? {};
    let subs = -1;
    for (const row of findKey(head, "metadataRows") ?? [])
        for (const part of row.metadataParts ?? []) {
            const t = sansonText(part.text);
            if (/suscript|subscri/i.test(t))
                subs = sansonCount(t);
        }
    const name = meta.title || sansonText(findKey(head.title, "text"));
    return {
        id: meta.externalId ?? "",
        name,
        thumb: lastUrl(meta.avatar?.thumbnails) || lastUrl(findKey(head.image, "sources")),
        banner: lastUrl(findKey(head.banner, "sources")),
        description: meta.description ?? "",
        subs
    };
}

source.getChannel = function (url) {
    const list = playlistIdOf(url);
    if (list) {
        const d = api("browse", { browseId: "VL" + list });
        const head = findKey(d?.header, "pageHeaderViewModel");
        const title = sansonText(findKey(head?.title, "text")) || sansonText(findKey(d?.header, "title")) ||
            d?.metadata?.playlistMetadataRenderer?.title || "Lista";
        return new PlatformChannel({
            id: sansonPid(PLATFORM, list), name: title, thumbnail: "", banner: "",
            description: d?.metadata?.playlistMetadataRenderer?.description ?? "", subscribers: -1, url
        });
    }
    const h = channelHeader(api("browse", { browseId: browseIdOf(url) }));
    return new PlatformChannel({
        id: sansonPid(PLATFORM, h.id), name: h.name, thumbnail: h.thumb, banner: h.banner,
        description: h.description, subscribers: h.subs, url: h.id ? channelUrl(h.id) : url
    });
};

// A channel's videos (the one live now first), or the videos of a playlist.
source.getChannelContents = function (url) {
    const list = playlistIdOf(url);
    if (list)
        return listPager("browse", collect(api("browse", { browseId: "VL" + list }).contents));
    const id = browseIdOf(url);
    const d = api("browse", { browseId: id, params: TAB_VIDEOS });
    const h = channelHeader(d);
    const def = { author: h.name, channelId: id, authorThumb: h.thumb };
    const first = collect(d.contents, def);
    try {
        const lives = collect(api("browse", { browseId: id, params: TAB_LIVE }).contents, def).items.filter(v => v.isLive);
        first.items = sansonMix([lives, first.items]);
    } catch (e) {
        log("live tab: " + e);
    }
    // The first shorts too: Sanson shows them apart, under their own button.
    try {
        const shorts = collect(api("browse", { browseId: id, params: TAB_SHORTS }).contents, def).items
            .filter(v => /\/shorts\//.test(v.url));
        first.items = first.items.concat(shorts);
    } catch (e) {
        log("shorts tab: " + e);
    }
    return listPager("browse", first, undefined, def);
};

// --- video ---------------------------------------------------------------------------------------

function codecOf(mime) {
    const m = /codecs="([^"]+)"/.exec(mime ?? "");
    return m ? m[1] : "";
}

function sources(streaming, prefix) {
    const videos = [], audios = [];
    for (const f of streaming?.adaptiveFormats ?? []) {
        if (!f.url)
            continue;
        const mime = f.mimeType ?? "";
        const container = mime.split(";")[0];
        if (mime.startsWith("video/")) {
            videos.push(new VideoUrlSource({
                name: (f.qualityLabel ?? (f.height + "p")),
                url: f.url, width: f.width ?? 0, height: f.height ?? 0, codec: codecOf(mime), container,
                bitrate: f.bitrate ?? 0, duration: Math.round((f.approxDurationMs ?? 0) / 1000)
            }));
        } else if (mime.startsWith("audio/")) {
            const track = f.audioTrack ?? {};
            audios.push(new AudioUrlSource({
                name: prefix + (track.displayName ?? "Audio"),
                url: f.url, codec: codecOf(mime), container, bitrate: f.bitrate ?? 0,
                language: (track.id ?? "").split(".")[0] || "Unknown",
                original: !!track.audioIsDefault,
                duration: Math.round((f.approxDurationMs ?? 0) / 1000)
            }));
        }
    }
    return { videos, audios };
}

function playable(videoId) {
    let last = null;
    for (const p of PLAYERS) {
        let r;
        try {
            r = player(videoId, p);
        } catch (e) {
            last = e;
            continue;
        }
        const st = r?.playabilityStatus ?? {};
        if (st.status === "OK" && (r.streamingData?.adaptiveFormats?.length || r.streamingData?.hlsManifestUrl))
            return { r, p };
        const reason = st.reason || sansonText(st.errorScreen?.playerErrorMessageRenderer?.reason) || st.status;
        log(p.name + ": " + st.status + " " + reason);
        // Removed or private videos are final.
        if (st.status === "ERROR")
            throw new UnavailableException(reason);
        // "Sign in to confirm you're not a bot": a session or a verification in the browser.
        if (/not a bot|no eres un bot/i.test(reason ?? ""))
            last = new CaptchaRequiredException("https://www.youtube.com/watch?v=" + videoId, "");
        else if (!(last instanceof CaptchaRequiredException))
            last = new ScriptException(reason ?? "YouTube no entregó el video");
    }
    throw last ?? new ScriptException("YouTube no entregó el video");
}

function watchInfo(videoId) {
    try {
        return api("next", { videoId });
    } catch (e) {
        log("next: " + e);
        return null;
    }
}

source.getContentDetails = function (url) {
    const id = videoIdOf(url);
    const { r, p } = playable(id);
    const vd = r.videoDetails ?? {};
    const next = watchInfo(id);
    const primary = findKey(next?.contents, "videoPrimaryInfoRenderer") ?? {};
    const secondary = findKey(next?.contents, "videoSecondaryInfoRenderer") ?? {};
    const owner = secondary.owner?.videoOwnerRenderer ?? {};
    const channelId = vd.channelId ?? findKey(owner.title, "browseId") ?? "";
    const live = !!vd.isLive || !!r.streamingData?.hlsManifestUrl && !r.streamingData?.adaptiveFormats?.length;
    const likes = sansonCount(sansonText(findKey(findKey(primary, "likeButtonViewModel"), "title")));
    // The player gives the exact count; the watch page only a text, sometimes "0" on old videos.
    const views = vd.viewCount ? parseInt(vd.viewCount, 10) :
        sansonCount(sansonText(findKey(primary.viewCount, "originalViewCount")) || sansonText(findKey(primary.viewCount, "viewCount")));
    let date = sansonAgo(sansonText(primary.relativeDateText));
    const src = sources(r.streamingData, p.name + " ");
    lastSubtitles = (r.captions?.playerCaptionsTracklistRenderer?.captionTracks ?? []).map(t => ({
        name: sansonText(t.name) || t.languageCode,
        url: t.baseUrl + "&fmt=vtt",
        language: t.languageCode,
        format: "text/vtt"
    }));
    // A short keeps its address (Sanson keeps shorts apart) and goes on with more shorts of its
    // channel: the related videos YouTube gives for a short are normal videos.
    const isShort = /\/shorts\//.test(url);
    const related = isShort ? channelShorts(channelId, id) : next ? collect(next?.contents?.twoColumnWatchNextResults?.secondaryResults).items
        .filter(v => v instanceof PlatformVideo) : [];
    const details = new PlatformVideoDetails({
        id: sansonPid(PLATFORM, id),
        name: vd.title ?? sansonText(primary.title),
        thumbnails: sansonThumbs("https://i.ytimg.com/vi/" + id + "/hqdefault.jpg"),
        author: sansonAuthor(PLATFORM, channelId, vd.author ?? sansonText(owner.title), channelUrl(channelId),
            lastUrl(owner.thumbnail?.thumbnails), sansonCount(sansonText(owner.subscriberCountText))),
        uploadDate: date,
        duration: live ? 0 : parseInt(vd.lengthSeconds ?? "0", 10),
        viewCount: views,
        url: isShort ? YT + "/shorts/" + id : YT + "/watch?v=" + id,
        isLive: live,
        description: secondary.attributedDescription?.content ?? vd.shortDescription ?? "",
        rating: new RatingLikes(likes),
        video: live ? new VideoSourceDescriptor([]) : new UnMuxVideoSourceDescriptor(src.videos, src.audios),
        subtitles: lastSubtitles.map(s => new SubtitleSource(s)),
        sansonRelated: related
    });
    if (live)
        details.live = new HLSSource({ name: "live", url: r.streamingData.hlsManifestUrl, duration: 0 });
    return details;
};

function channelShorts(channelId, except) {
    if (!channelId)
        return [];
    try {
        const d = api("browse", { browseId: channelId, params: TAB_SHORTS });
        const h = channelHeader(d);
        return collect(d.contents, { author: h.name, channelId, authorThumb: h.thumb }).items
            .filter(v => /\/shorts\//.test(v.url) && !v.url.endsWith("/" + except));
    } catch (e) {
        log("channel shorts: " + e);
        return [];
    }
}

source.getContentRecommendations = function (url) {
    return new VideoPager(related(videoIdOf(url)), false, {});
};

source.sansonSubtitles = function (index) {
    const s = lastSubtitles[index];
    if (!s)
        throw new ScriptException("Subtítulo no disponible");
    let resp = http.GET(s.url, { "User-Agent": PLAYERS[0].ua }, false);
    if (resp.code == 429 && logged())
        resp = http.GET(s.url, {}, true);
    if (resp.code == 429)
        throw new ScriptException("Google bloqueó los subtítulos para esta red (demasiadas consultas). Prueba en unas horas.");
    if (!resp.isOk)
        throw new ScriptException("No se pudo descargar el subtítulo [" + resp.code + "]");
    return resp.body;
};

// --- comments -----------------------------------------------------------------------------------

source.sansonComments = function (url, token) {
    const auth = logged();
    let cont = token;
    if (!cont) {
        const watch = api("next", { videoId: videoIdOf(url) }, auth);
        const sections = findKey(watch?.contents?.twoColumnWatchNextResults?.results, "contents") ?? [];
        const section = sections.find(s => s.itemSectionRenderer?.sectionIdentifier === "comment-item-section");
        cont = findKey(section, "continuationCommand")?.token;
        if (!cont)
            return { comments: [], next: "", disabled: true };
    }
    const page = api("next", { continuation: cont }, auth);
    const entities = {};
    for (const m of page?.frameworkUpdates?.entityBatchUpdate?.mutations ?? []) {
        const c = m?.payload?.commentEntityPayload;
        if (c?.key)
            entities[c.key] = c;
    }
    const comments = [];
    let next = "";
    const items = (page?.onResponseReceivedEndpoints ?? []).flatMap(e =>
        e.reloadContinuationItemsCommand?.continuationItems ?? e.appendContinuationItemsAction?.continuationItems ?? []);
    for (const it of items) {
        const key = it.commentThreadRenderer?.commentViewModel?.commentViewModel?.commentKey;
        const c = key ? entities[key] : null;
        if (c) {
            comments.push({
                author: c.author?.displayName ?? "",
                text: c.properties?.content?.content ?? "",
                when: c.properties?.publishedTime ?? "",
                likes: c.toolbar?.likeCountNotliked ?? "",
                replies: c.toolbar?.replyCount ?? ""
            });
        } else if (it.continuationItemRenderer) {
            next = findKey(it.continuationItemRenderer, "continuationCommand")?.token ?? "";
        }
    }
    const create = findKey(page, "createCommentEndpoint")?.createCommentParams ?? "";
    const header = findKey(page, "commentsHeaderRenderer");
    const count = sansonText(header?.countText).replace(/[^0-9.,\s]/g, "").trim();
    return { comments, next, create, count };
};

source.sansonPostComment = function (createParams, text) {
    if (!logged())
        throw new ScriptException("Inicia sesión en Ajustes para comentar");
    const r = api("comment/create_comment", { createCommentParams: createParams, commentText: text }, true);
    if (r?.actionResult?.status !== "STATUS_SUCCEEDED")
        throw new ScriptException("YouTube rechazó el comentario");
    return { ok: true };
};

// --- account ---------------------------------------------------------------------------------------

// Channels the account is subscribed to (empty without a session).
source.sansonFollowing = function () {
    if (!logged())
        return new SansonChannelPager([]);
    const d = api("browse", { browseId: "FEchannels" }, true);
    let r = collect(d);
    let items = r.items.filter(v => v instanceof PlatformChannel);
    for (let i = 0; r.token && i < 10; i++) {
        r = collect(api("browse", { continuation: r.token }, true));
        items = items.concat(r.items.filter(v => v instanceof PlatformChannel));
    }
    return new SansonChannelPager(items);
};

function rssVideos(channelId) {
    const xml = sansonRequest("GET", YT + "/feeds/videos.xml?channel_id=" + channelId, null, {}, false, "YouTube");
    const author = (/<author>\s*<name>([^<]*)<\/name>/.exec(xml) ?? [])[1] ?? "";
    const out = [];
    for (const e of xml.split("<entry>").slice(1)) {
        const id = (/<yt:videoId>([^<]+)</.exec(e) ?? [])[1];
        if (!id)
            continue;
        const title = (/<title>([^<]*)<\/title>/.exec(e) ?? [])[1] ?? "";
        const views = (/<media:statistics views="(\d+)"/.exec(e) ?? [])[1];
        out.push(video({
            id, channelId, author: unescapeXml(author), title: unescapeXml(title),
            date: sansonIso((/<published>([^<]+)</.exec(e) ?? [])[1]),
            views: views ? parseInt(views, 10) : -1,
            short: /\/shorts\//.test((/<link rel="alternate" href="([^"]+)"/.exec(e) ?? [])[1] ?? "")
        }));
    }
    return out;
}

function unescapeXml(s) {
    return s.replace(/&quot;/g, "\"").replace(/&#39;/g, "'").replace(/&lt;/g, "<").replace(/&gt;/g, ">").replace(/&amp;/g, "&");
}

// What is new: the account's subscriptions feed, or without a session the latest videos of the
// channels followed in Sanson (`urls`), from their RSS feeds.
source.sansonFeed = function (urls) {
    if (logged()) {
        try {
            const r = collect(api("browse", { browseId: "FEsubscriptions" }, true));
            if (r.items.length > 0)
                return listPager("browse", r, true);
        } catch (e) {
            log("subscriptions feed: " + e);
        }
    }
    // The RSS feeds are light but YouTube breaks them now and then (404/500): then the first
    // page of each channel's Videos tab.
    let all = [], rss = true;
    for (const u of (urls ?? []).slice(0, 16)) {
        try {
            const id = browseIdOf(u);
            let list = null;
            if (rss) {
                try {
                    list = rssVideos(id);
                } catch (e) {
                    log("rss " + id + ": " + e);
                    rss = false;
                }
            }
            if (!list) {
                const d = api("browse", { browseId: id, params: TAB_VIDEOS }, false);
                const h = channelHeader(d);
                list = collect(d.contents, { author: h.name, channelId: id, authorThumb: h.thumb }).items.slice(0, 8);
            }
            all = all.concat(list);
        } catch (e) {
            log("feed " + u + ": " + e);
        }
    }
    all.sort((a, b) => b.uploadDate - a.uploadDate);
    return new VideoPager(all.slice(0, 150), false, {});
};

// --- live chat -----------------------------------------------------------------------------
// The chat of a live comes from innertube: the watch page gives the first continuation and
// get_live_chat the messages from then on, each answer with the next continuation.

// Message text with its custom emojis as __key__ (drawn as pictures by the app).
function chatText(t, emojis) {
    let s = "";
    for (const r of t?.runs ?? []) {
        if (r.text != null) {
            s += r.text;
        } else if (r.emoji) {
            const e = r.emoji;
            const url = lastUrl(e.image?.thumbnails);
            if (e.isCustomEmoji && url) {
                const key = String(e.shortcuts?.[0] ?? e.emojiId).replace(/[\s:]/g, "");
                emojis[key] = url;
                s += " __" + key + "__ ";
            } else {
                s += e.emojiId ?? "";
            }
        }
    }
    return s.trim() || sansonText(t);
}

// `seen`: ids already delivered (a new continuation may bring some of them again).
function chatEvents(actions, emojis, seen) {
    const out = [];
    for (const a of actions ?? []) {
        const item = a.addChatItemAction?.item;
        if (!item)
            continue;
        const id = Object.values(item)[0]?.id;
        if (id) {
            if (seen.has(id))
                continue;
            seen.add(id);
        }
        const text = item.liveChatTextMessageRenderer;
        const paid = item.liveChatPaidMessageRenderer;
        const member = item.liveChatMembershipItemRenderer;
        if (text) {
            const isMember = (text.authorBadges ?? []).some(b => b.liveChatAuthorBadgeRenderer?.customThumbnail);
            out.push(new LiveEventComment(sansonText(text.authorName), chatText(text.message, emojis), "",
                isMember ? "#2ba640" : null, []));
        } else if (paid) {
            out.push(new LiveEventDonation(sansonText(paid.purchaseAmountText), sansonText(paid.authorName),
                chatText(paid.message, emojis), "", 0, null));
        } else if (member) {
            out.push(new LiveEventDonation("Miembro", sansonText(member.authorName),
                sansonText(member.headerSubtext) || chatText(member.message, emojis), "", 0, null));
        }
    }
    return out;
}

function chatContinuation(list) {
    for (const c of list ?? []) {
        const d = c.invalidationContinuationData ?? c.timedContinuationData ?? c.reloadContinuationData;
        if (d?.continuation)
            return { token: d.continuation, wait: d.timeoutMs ?? 0 };
    }
    return null;
}

class YouTubeChatPager extends LiveEventPager {
    constructor(token) {
        super([], true);
        this.token = token;
        this.seen = new Set();
        this.nextPage();
    }
    nextPage() {
        const d = api("live_chat/get_live_chat", { continuation: this.token });
        const live = d?.continuationContents?.liveChatContinuation;
        const next = chatContinuation(live?.continuations);
        if (!next) {
            this.hasMore = false;
            throw new ScriptException("El chat terminó");
        }
        this.token = next.token;
        this.nextRequest = Math.max(1000, Math.min(next.wait || 2000, 5000));
        const emojis = {};
        if (this.seen.size > 2000)
            this.seen = new Set([...this.seen].slice(-500));
        const events = chatEvents(live?.actions, emojis, this.seen);
        this.results = Object.keys(emojis).length ? [new LiveEventEmojis(emojis), ...events] : events;
        return this;
    }
}

source.getLiveEvents = function (url) {
    const d = api("next", { videoId: videoIdOf(url) });
    const bar = d?.contents?.twoColumnWatchNextResults?.conversationBar?.liveChatRenderer;
    const first = chatContinuation(bar?.continuations);
    if (!first)
        throw new UnavailableException("Este video no tiene chat en vivo");
    return new YouTubeChatPager(first.token);
};
