// Sanson: Kick straight to Kick's REST API and its realtime chat.
// GPL-3.0-or-later.

const PLATFORM = "Kick";
const KICK = "https://kick.com";
const HEADERS = { "Accept": "application/json", "Referer": KICK + "/" };
const PAGE = 24;

source.enable = function () {
};

function logged() {
    return bridge.isLoggedIn();
}

function get(url, auth) {
    // Kick's edge drops some requests at random: one more try before giving up.
    try {
        return sansonJson("GET", url, null, HEADERS, auth, "Kick");
    } catch (e) {
        log("retry " + url + ": " + e);
        return sansonJson("GET", url, null, HEADERS, auth, "Kick");
    }
}

// --- urls ----------------------------------------------------------------------------------

function slugOf(url) {
    const m = /kick\.com\/([\w-]+)/.exec(url ?? "");
    if (!m)
        throw new UnavailableException("No se reconoce el canal: " + url);
    return m[1].toLowerCase();
}

function vodOf(url) {
    const m = /kick\.com\/[\w-]+\/videos\/([\w-]+)/.exec(url ?? "");
    return m ? m[1] : null;
}

// --- items -----------------------------------------------------------------------------------

function liveItem(s, ch) {
    // `s`: a livestream of /livestreams (channel inside) or of /channels/<slug> (`ch` outside).
    const c = ch ?? s.channel ?? {};
    const u = c.user ?? {};
    const slug = u.slug ?? c.slug ?? "";
    return new PlatformVideo({
        id: sansonPid(PLATFORM, s.id),
        name: s.session_title ?? s.title ?? u.username ?? slug,
        thumbnails: sansonThumbs(s.thumbnail?.src ?? s.thumbnail?.url ?? s.thumbnail ?? ""),
        author: sansonAuthor(PLATFORM, u.id ?? c.id, u.username ?? c.username ?? slug, KICK + "/" + slug,
            u.profilepic ?? u.profile_pic ?? c.profile_pic ?? null),
        uploadDate: sansonIso(s.start_time ?? s.created_at),
        duration: 0,
        viewCount: s.viewer_count ?? s.viewers ?? -1,
        url: KICK + "/" + slug,
        isLive: true
    });
}

function vodItem(s, user, slug) {
    return new PlatformVideo({
        id: sansonPid(PLATFORM, s.id),
        name: s.session_title ?? "",
        thumbnails: sansonThumbs(s.thumbnail?.src ?? s.thumbnail?.url ?? ""),
        author: sansonAuthor(PLATFORM, user?.id, user?.username ?? slug, KICK + "/" + slug, user?.profile_pic ?? user?.profilepic),
        uploadDate: sansonIso(s.start_time ?? s.created_at),
        duration: Math.round((s.duration ?? 0) / 1000),
        viewCount: s.views ?? s.viewer_count ?? -1,
        url: KICK + "/" + slug + "/videos/" + (s.video?.uuid ?? s.uuid),
        isLive: false
    });
}

function channelItem(c) {
    const u = c.user ?? {};
    return new PlatformChannel({
        id: sansonPid(PLATFORM, c.id),
        name: u.username ?? c.slug,
        thumbnail: u.profile_pic ?? u.profilePic ?? "",
        banner: c.banner_image?.url ?? "",
        subscribers: c.followersCount ?? c.followers_count ?? -1,
        description: u.bio ?? "",
        url: KICK + "/" + c.slug
    });
}

// --- home, search, channels ---------------------------------------------------------------------

source.getHome = function () {
    const fetch = ctx => {
        const j = get("https://web.kick.com/api/v1/livestreams?page=" + ctx.page + "&limit=" + PAGE + "&sort=featured_home&language=en");
        const list = j?.data?.livestreams ?? j?.data ?? [];
        return {
            results: list.map(s => liveItem(s)),
            more: list.length >= PAGE && ctx.page < 10,
            context: { page: ctx.page + 1 }
        };
    };
    return new SansonPager(fetch, { page: 1 });
};

function searchChannels(query) {
    const j = get(KICK + "/api/search?searched_word=" + encodeURIComponent(query));
    return (j?.channels ?? []).filter(c => c?.slug);
}

// Channels (the ones live now also as their stream).
source.search = function (query) {
    const chans = searchChannels(query);
    const out = chans.map(channelItem);
    for (const c of chans)
        if (c.livestream?.is_live || c.livestream?.id)
            out.push(liveItem(c.livestream, c));
    return new VideoPager(out, false, {});
};

source.searchChannels = function (query) {
    return new SansonChannelPager(searchChannels(query).map(channelItem));
};

function channel(slug) {
    return get(KICK + "/api/v2/channels/" + slug);
}

source.getChannel = function (url) {
    return channelItem(channel(slugOf(url)));
};

source.getChannelContents = function (url) {
    const slug = slugOf(url);
    const c = channel(slug);
    const out = [];
    if (c.livestream)
        out.push(liveItem(c.livestream, c));
    try {
        const vids = get(KICK + "/api/v2/channels/" + slug + "/videos");
        for (const v of Array.isArray(vids) ? vids : vids?.data ?? [])
            out.push(vodItem(v, c.user, slug));
    } catch (e) {
        log("videos: " + e);
        const old = get(KICK + "/api/v1/channels/" + slug);
        for (const v of old.previous_livestreams ?? [])
            out.push(vodItem(v, c.user, slug));
    }
    return new VideoPager(out, false, {});
};

// --- video ---------------------------------------------------------------------------------------

source.getContentDetails = function (url) {
    const vod = vodOf(url);
    if (vod) {
        const j = get(KICK + "/api/v1/video/" + vod);
        const ls = j.livestream ?? {};
        const ch = ls.channel ?? {};
        if (!j.source)
            throw new UnavailableException("La grabación no está disponible.");
        const item = vodItem(Object.assign({}, ls, { uuid: j.uuid, views: j.views, created_at: j.created_at, thumbnail: { src: ls.thumbnail } }),
            ch.user, ch.slug);
        return new PlatformVideoDetails(Object.assign({}, item, {
            description: ch.user?.bio ?? "",
            video: new VideoSourceDescriptor([new HLSSource({ name: "source", url: j.source, duration: item.duration })]),
            sansonRelated: others(ch.slug, url)
        }));
    }
    const slug = slugOf(url);
    const c = channel(slug);
    if (!c.livestream)
        throw new UnavailableException((c.user?.username ?? slug) + " no está en vivo ahora.");
    if (!c.playback_url)
        throw new ScriptException("Kick no entregó el directo");
    const item = liveItem(c.livestream, c);
    return new PlatformVideoDetails(Object.assign({}, item, {
        description: c.user?.bio ?? "",
        video: new VideoSourceDescriptor([]),
        live: new HLSSource({ name: "live", url: c.playback_url, duration: 0 }),
        sansonRelated: featured(url)
    }));
};

function others(slug, url) {
    if (!slug)
        return [];
    try {
        const list = source.getChannelContents(KICK + "/" + slug).results.filter(v => !v.isLive);
        const i = list.findIndex(v => v.url === url);
        return i >= 0 ? [...list.slice(i + 1), ...list.slice(0, i)] : list;
    } catch (e) {
        log("others: " + e);
        return [];
    }
}

function featured(url) {
    try {
        const j = get("https://web.kick.com/api/v1/livestreams?page=1&limit=" + PAGE + "&sort=featured_home&language=en");
        return (j?.data?.livestreams ?? []).map(s => liveItem(s)).filter(v => v.url !== url);
    } catch (e) {
        log("featured: " + e);
        return [];
    }
}

source.getContentRecommendations = function (url) {
    const vod = vodOf(url);
    return new VideoPager(vod ? others(slugOf(url), url) : featured(url), false, {});
};

// --- account ---------------------------------------------------------------------------------------

function followed() {
    const out = [];
    let cursor = 0;
    for (let i = 0; i < 10; i++) {
        const j = get(KICK + "/api/v2/channels/followed?cursor=" + cursor, true);
        out.push(...(j?.channels ?? []));
        if (!j?.nextCursor)
            break;
        cursor = j.nextCursor;
    }
    return out;
}

source.sansonFollowing = function () {
    if (!logged())
        return new SansonChannelPager([]);
    return new SansonChannelPager(followed().map(c => new PlatformChannel({
        id: sansonPid(PLATFORM, c.channel_slug),
        name: c.user_username ?? c.channel_slug,
        thumbnail: c.profile_picture ?? "",
        subscribers: c.followers_count ?? -1,
        url: KICK + "/" + c.channel_slug
    })));
};

// Who is live now among the channels followed (the account's and the ones followed in Sanson).
source.sansonFeed = function (urls) {
    const slugs = new Set();
    const live = [];
    if (logged()) {
        try {
            for (const c of followed())
                if (c.is_live)
                    slugs.add(c.channel_slug);
        } catch (e) {
            log("followed: " + e);
        }
    }
    for (const u of urls ?? []) {
        try {
            slugs.add(slugOf(u));
        } catch (e) {
        }
    }
    for (const s of [...slugs].slice(0, 40)) {
        try {
            const c = channel(s);
            if (c.livestream)
                live.push(liveItem(c.livestream, c));
        } catch (e) {
            log("feed " + s + ": " + e);
        }
    }
    live.sort((a, b) => b.viewCount - a.viewCount);
    return new VideoPager(live, false, {});
};

// --- chat ----------------------------------------------------------------------------------
// Live: the last messages from the API, then Kick's realtime service (Centrifugo over
// WebSocket) with a guest token from web.kick.com. Replays: the messages by time, from the API.

const REALTIME = "https://web.kick.com/api/v1/realtime";
const REALTIME_HEADERS = { "Content-Type": "application/json", "Accept": "application/json", "Origin": KICK, "Referer": KICK + "/" };

// "[emote:37233:PogU]" becomes __k37233__ with its picture.
function chatMessage(m, emojis) {
    const text = String(m.content ?? "").replace(/\[emote:(\d+):?[^\]]*\]/g, (all, id) => {
        emojis["k" + id] = "https://files.kick.com/emotes/" + id + "/fullsize";
        return " __k" + id + "__ ";
    }).trim();
    return new LiveEventComment(m.sender?.username ?? "", text, "", m.sender?.identity?.color ?? null, []);
}

function realtime(path, body) {
    return sansonJson("POST", REALTIME + path, JSON.stringify(body), REALTIME_HEADERS, false, "Kick").data;
}

class KickChatPager extends LiveEventPager {
    constructor(slug) {
        super([], true);
        const me = this;
        const c = channel(slug);
        this.events = [];
        this.emojis = {};
        this.nextRequest = 1500;
        const last = get(KICK + "/api/v2/channels/" + c.id + "/messages");
        for (const m of (last?.data?.messages ?? []).slice().reverse())
            if (m.type === "message")
                this.events.push(chatMessage(m, this.emojis));
        const client = utility.randomUUID();
        const conn = realtime("/channels/" + c.id + "/chat/connection",
            { client: { id: client, type: "web" }, capabilities: { accepted_providers: [{ provider: "centrifugo" }] } });
        const url = (conn?.connections ?? []).find(x => x.provider === "centrifugo")?.credentials?.url;
        if (!url) {
            log("chat: no realtime url");
            return;
        }
        const token = realtime("/auth/connection", { client_id: client })?.token ?? "";
        const room = "chatrooms." + c.chatroom?.id + ".v2";
        const ws = http.socket(url, { Origin: KICK }, false);
        this.ws = ws;
        ws.connect({
            open() {
                ws.send(JSON.stringify({ connect: { token, name: "js" }, id: 1 }) + "\n" +
                    JSON.stringify({ subscribe: { channel: room }, id: 2 }));
            },
            message(frame) {
                for (const line of frame.split("\n")) {
                    if (!line)
                        continue;
                    if (line === "{}") { // ping
                        ws.send("{}");
                        continue;
                    }
                    const data = JSON.parse(line)?.push?.pub?.data;
                    if (data?.event === "App\\Events\\ChatMessageEvent") {
                        const m = typeof data.data === "string" ? JSON.parse(data.data) : data.data;
                        me.events.push(chatMessage(m, me.emojis));
                    }
                }
            },
            closed() {
                me.hasMore = false;
            }
        });
    }
    nextPage() {
        const out = Object.keys(this.emojis).length ? [new LiveEventEmojis(this.emojis)] : [];
        this.emojis = {};
        this.results = out.concat(this.events);
        this.events = [];
        if (this.ws && !this.ws.isOpen)
            this.hasMore = false;
        return this;
    }
}

source.getLiveEvents = function (url) {
    return new KickChatPager(slugOf(url));
};

// The recording starts a few seconds before the start time Kick gives: the time of its first
// segment lines the chat up with the picture.
function recordingStart(master) {
    try {
        const list = sansonRequest("GET", master, null, {}, false, "Kick");
        const variant = list.split("\n").map(l => l.trim()).find(l => l && !l.startsWith("#"));
        const media = http.GET(new URL(variant, master).href, { Range: "bytes=0-2047" }, false);
        const t = Date.parse((/#EXT-X-PROGRAM-DATE-TIME:(\S+)/.exec(media.body ?? "") ?? [])[1]);
        return isNaN(t) ? null : t;
    } catch (e) {
        log("recording start: " + e);
        return null;
    }
}

// Kick answers the 25 messages before a time (`cursor`, in microseconds): a stretch of the
// video is read from its end backwards. The pager keeps the next seconds read and asks for
// more as the video advances.
const REPLAY_STEP = 8000;

class KickReplayPager extends LiveEventPager {
    constructor(uuid) {
        super([], true);
        const v = get(KICK + "/api/v1/video/" + uuid);
        this.channelId = v.livestream?.channel_id;
        this.start = recordingStart(v.source) ?? Date.parse(v.livestream?.start_time);
        this.nextRequest = 1000;
        this.cache = [];
        this.emojis = {};
        this.to = -1; // read up to here (ms of the video)
    }
    nextPage(ms) {
        const at = ms ?? 0;
        if (this.to < 0 || at < this.to - 4 * REPLAY_STEP || at > this.to) {
            this.cache = [];
            this.to = at;
        }
        if (this.to < at + 4000) {
            this.fetch(this.to, this.to + REPLAY_STEP);
            this.to += REPLAY_STEP;
        }
        this.cache = this.cache.filter(e => e.time >= at - 1000);
        const out = Object.keys(this.emojis).length ? [new LiveEventEmojis(this.emojis)] : [];
        this.emojis = {};
        this.results = out.concat(this.cache);
        return this;
    }
    // The messages from `a` to `b` (ms of the video), at most a few requests on busy chats.
    fetch(a, b) {
        let cursor = (this.start + b) * 1000;
        for (let i = 0; i < 6; i++) {
            const j = get(KICK + "/api/v2/channels/" + this.channelId + "/messages?cursor=" + cursor);
            const list = j?.data?.messages ?? [];
            let oldest = Infinity;
            for (const m of list) {
                const t = Date.parse(m.created_at) - this.start;
                oldest = Math.min(oldest, t);
                if (m.type !== "message" || t < a || t >= b || this.cache.some(c => c.id === m.id))
                    continue;
                const e = chatMessage(m, this.emojis);
                e.time = t;
                e.id = m.id;
                this.cache.push(e);
            }
            if (list.length < 25 || oldest < a || !j.data.cursor)
                break;
            cursor = j.data.cursor;
        }
        this.cache.sort((x, y) => x.time - y.time);
    }
}

source.getVODEvents = function (url) {
    const uuid = vodOf(url);
    if (!uuid)
        throw new UnavailableException("No es un video de Kick");
    return new KickReplayPager(uuid);
};
