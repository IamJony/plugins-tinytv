"use strict";

const PLATFORM = "RadioBrowser";
const API_BASE = "https://all.api.radio-browser.info";
const RADIO_UA = "BashRadioBrowserMPlayer/1.0 (Linux)";
const DEFAULT_THUMB = "https://raw.githubusercontent.com/IamJony/tinytv/refs/heads/main/data/tinytv.png";

const LATAM_COUNTRIES = [
    ["AR", "Argentina"],
    ["BO", "Bolivia"],
    ["BR", "Brasil"],
    ["CL", "Chile"],
    ["CO", "Colombia"],
    ["CR", "Costa Rica"],
    ["CU", "Cuba"],
    ["DO", "República Dominicana"],
    ["EC", "Ecuador"],
    ["SV", "El Salvador"],
    ["GT", "Guatemala"],
    ["HN", "Honduras"],
    ["MX", "México"],
    ["NI", "Nicaragua"],
    ["PA", "Panamá"],
    ["PY", "Paraguay"],
    ["PE", "Perú"],
    ["PR", "Puerto Rico"],
    ["UY", "Uruguay"],
    ["VE", "Venezuela"]
];

let config = {};

function radioHeaders() {
    return {
        "User-Agent": RADIO_UA,
        "Accept": "application/json"
    };
}

function flagUrl(code) {
    const low = String(code || "").trim().toLowerCase();
    if (!low || low.length !== 2) return DEFAULT_THUMB;
    return "https://flagcdn.com/w160/" + low + ".png";
}

function parseCountryCode(url) {
    const s = String(url || "").trim();
    const prefix = "radiobrowser://country/";
    if (s.indexOf(prefix) !== 0) return "";
    const code = s.slice(prefix.length).split(/[/?#]/)[0].toUpperCase();
    return code.length === 2 ? code : "";
}

function countryNameFromCode(code) {
    const up = String(code || "").toUpperCase();
    for (let i = 0; i < LATAM_COUNTRIES.length; i++) {
        if (LATAM_COUNTRIES[i][0] === up) return LATAM_COUNTRIES[i][1];
    }
    return up || "País";
}

function makeCountryChannel(code, name) {
    const up = String(code || "").toUpperCase();
    const cleanName = String(name || up).trim();
    const img = flagUrl(up);
    return new PlatformChannel({
        id: new PlatformID(PLATFORM, "country:" + up, config.id),
        name: "Radios de " + cleanName,
        url: "radiobrowser://country/" + up,
        thumbnail: img,
        banner: img,
        subscribers: -1,
        description: ""
    });
}

function stationToVideo(st, fallbackCountryCode) {
    const uuid = String(st.stationuuid || st.changeuuid || "");
    const name = String(st.name || "Emisora sin nombre").trim();
    const codec = String(st.codec || "").trim();
    const bitrate = Number(st.bitrate || 0);
    const country = String(st.countrycode || fallbackCountryCode || st.country || "").trim();
    const tags = String(st.tags || "").trim();
    const homepage = String(st.homepage || API_BASE).trim();
    const thumb = String(st.favicon || "").trim();

    const metaParts = [];
    if (codec) metaParts.push(codec);
    if (bitrate > 0) metaParts.push(bitrate + " kbps");
    if (country) metaParts.push(country);
    if (tags) metaParts.push(tags.split(",").slice(0, 3).join(", "));

    return new PlatformVideo({
        id: new PlatformID(PLATFORM, uuid || name, config.id),
        name: name,
        thumbnails: new Thumbnails([
            new Thumbnail(thumb || flagUrl(country), 0)
        ]),
        author: new PlatformAuthorLink(
            new PlatformID(PLATFORM, country || "radio", config.id),
            metaParts.join(" · ") || "RadioBrowser",
            homepage || API_BASE,
            null,
            null
        ),
        url: API_BASE + "/json/stations/byuuid/" + encodeURIComponent(uuid),
        isLive: true,
        duration: 0,
        viewCount: Number(st.clickcount || -1),
        datetime: 0
    });
}

function fetchStationsByCountry(countryCode, limit, offset) {
    const payload = JSON.stringify({
        countrycode: String(countryCode || "").toUpperCase(),
        hidebroken: "true",
        order: "clickcount",
        reverse: "true",
        limit: limit || 50,
        offset: offset || 0
    });
    const res = http.POST(
        API_BASE + "/json/stations/search",
        payload,
        Object.assign({}, radioHeaders(), { "Content-Type": "application/json" }),
        false
    );
    if (!res || !res.isOk) {
        throw new UnavailableException("No se pudieron cargar las emisoras del país");
    }
    const data = JSON.parse(res.body || "[]");
    return Array.isArray(data) ? data : [];
}

function fetchStationsByName(query, limit, offset) {
    const payload = JSON.stringify({
        name: query || "",
        hidebroken: "true",
        order: "clickcount",
        reverse: "true",
        limit: limit || 25,
        offset: offset || 0
    });
    const res = http.POST(
        API_BASE + "/json/stations/search",
        payload,
        Object.assign({}, radioHeaders(), { "Content-Type": "application/json" }),
        false
    );
    if (!res || !res.isOk) {
        throw new UnavailableException("No se pudo consultar RadioBrowser");
    }
    const data = JSON.parse(res.body || "[]");
    return Array.isArray(data) ? data : [];
}

function fetchLatestStations(limit) {
    const n = limit || 40;
    try {
        const res = http.GET(
            API_BASE + "/json/stations/lastchange?limit=" + n + "&hidebroken=true",
            radioHeaders(),
            false
        );
        if (res && res.isOk && res.body) {
            const data = JSON.parse(res.body);
            if (Array.isArray(data) && data.length > 0)
                return data;
        }
    } catch (e) {
        log("RadioBrowser /json/stations/lastchange error: " + e);
    }

    const payload = JSON.stringify({
        hidebroken: "true",
        order: "lastchangetime",
        reverse: "true",
        limit: n,
        offset: 0
    });
    const fb = http.POST(
        API_BASE + "/json/stations/search",
        payload,
        Object.assign({}, radioHeaders(), { "Content-Type": "application/json" }),
        false
    );
    if (!fb || !fb.isOk) {
        throw new UnavailableException("No se pudieron cargar las últimas emisoras");
    }
    const d2 = JSON.parse(fb.body || "[]");
    return Array.isArray(d2) ? d2 : [];
}

function resolveStreamUrl(station) {
    const uuid = String(station.stationuuid || "").trim();
    const fallback = String(station.url_resolved || station.url || "").trim();
    if (!uuid) return fallback;

    try {
        const res = http.GET(API_BASE + "/json/url/" + encodeURIComponent(uuid), radioHeaders(), false);
        if (res && res.isOk && res.body) {
            const j = JSON.parse(res.body);
            if (j && typeof j.url === "string" && j.url.trim()) {
                return j.url.trim();
            }
        }
    } catch (e) {
        log("RadioBrowser /json/url fallback: " + e);
    }
    return fallback;
}

source.enable = function (cfg, settings) {
    config = cfg || {};
};

source.getHome = function () {
    const latamSet = {};
    const channels = [];

    for (let i = 0; i < LATAM_COUNTRIES.length; i++) {
        const code = LATAM_COUNTRIES[i][0];
        const name = LATAM_COUNTRIES[i][1];
        latamSet[code] = true;
        channels.push(makeCountryChannel(code, name));
    }

    try {
        const res = http.GET(API_BASE + "/json/countries?hidebroken=true&order=stationcount&reverse=true", radioHeaders(), false);
        if (res && res.isOk && res.body) {
            const arr = JSON.parse(res.body);
            if (Array.isArray(arr)) {
                for (let i = 0; i < arr.length; i++) {
                    const code = String(arr[i].iso_3166_1 || "").toUpperCase();
                    const rawName = String(arr[i].name || code).trim();
                    if (!code || code.length !== 2 || latamSet[code]) continue;
                    channels.push(makeCountryChannel(code, rawName));
                }
            }
        }
    } catch (e) {
        log("RadioBrowser extra countries error: " + e);
    }

    return new VideoPager(channels, false);
};

source.sansonFeed = function (urls) {
    const stations = fetchLatestStations(40);
    return new VideoPager(stations.map(function (st) { return stationToVideo(st, ""); }), false);
};

source.getChannel = function (url) {
    const code = parseCountryCode(url) || "CO";
    const name = countryNameFromCode(code);
    const img = flagUrl(code);
    return new PlatformChannel({
        id: new PlatformID(PLATFORM, "country:" + code, config.id),
        name: "Radios de " + name,
        url: "radiobrowser://country/" + code,
        thumbnail: img,
        banner: img,
        subscribers: -1,
        description: ""
    });
};

source.getChannelContents = function (url) {
    const code = parseCountryCode(url);
    if (!code) {
        throw new UnavailableException("Canal de país no válido");
    }
    const stations = fetchStationsByCountry(code, 50, 0);
    return new VideoPager(stations.map(function (st) { return stationToVideo(st, code); }), false);
};

source.search = function (query) {
    const stations = fetchStationsByName(query, 25, 0);
    return new VideoPager(stations.map(function (st) { return stationToVideo(st, ""); }), false);
};

source.getContentDetails = function (url) {
    let station = null;
    try {
        const res = http.GET(url, radioHeaders(), false);
        if (res && res.isOk && res.body) {
            const arr = JSON.parse(res.body);
            if (Array.isArray(arr) && arr.length > 0) {
                station = arr[0];
            } else if (arr && typeof arr === "object") {
                station = arr;
            }
        }
    } catch (e) {
        throw new UnavailableException("Error leyendo emisora: " + e);
    }

    if (!station) {
        throw new UnavailableException("Emisora no encontrada");
    }

    const streamUrl = resolveStreamUrl(station);
    if (!streamUrl) {
        throw new UnavailableException("La emisora no devolvió URL de stream");
    }

    const name = String(station.name || "Emisora").trim();
    const codec = String(station.codec || "Stream").trim();
    const bitrate = Number(station.bitrate || 0);
    const label = bitrate > 0 ? name + " (" + codec + " " + bitrate + " kbps)" : name + " (" + codec + ")";

    const rawSrc = new RawPlayerSource({
        label: label,
        url: streamUrl,
        args: [
            "-nolirc",
            "-novideo",
            "-cache", "512",
            "-cache-min", "2",
            "-demuxer", "lavf",
            "-lavfdopts", "probesize=65536:analyzeduration=500000",
            "-user-agent", RADIO_UA
        ]
    });

    const details = new PlatformVideoDetails({
        id: new PlatformID(PLATFORM, String(station.stationuuid || name), config.id),
        name: name,
        thumbnails: new Thumbnails([
            new Thumbnail(String(station.favicon || "").trim() || flagUrl(station.countrycode), 0)
        ]),
        author: new PlatformAuthorLink(
            new PlatformID(PLATFORM, String(station.countrycode || "radio"), config.id),
            String(station.country || station.countrycode || "RadioBrowser"),
            String(station.homepage || API_BASE),
            null,
            null
        ),
        url: url,
        isLive: true,
        duration: 0,
        viewCount: Number(station.clickcount || -1),
        description: [
            station.codec ? "Códec: " + station.codec : "",
            station.bitrate ? "Bitrate: " + station.bitrate + " kbps" : "",
            station.country ? "País: " + station.country : "",
            station.tags ? "Etiquetas: " + station.tags : "",
            "Stream: " + streamUrl
        ].filter(Boolean).join("\n"),
        datetime: 0,
        video: new VideoSourceDescriptor([])
    });

    details.rawSources = [rawSrc];
    return details;
};
