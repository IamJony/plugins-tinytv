// Internet Archive plugin tinytv — Comprobación de ítems vacíos + Catálogo GitHub + Carátulas IA
const PLATFORM = "Internet Archive";
const BASE_URL = "https://archive.org";
const UA = "Mozilla/5.0 (X11; Linux x86_64; rv:133.0) Gecko/20100101 Firefox/133.0";
const PAGE_ROWS = 30;

const GITHUB_CATALOG_URL = "https://raw.githubusercontent.com/IamJony/plugins-tinytv/refs/heads/main/data/catalogo_archive.json";

// Cachés en memoria durante la sesión
const META_CACHE = {};
const COVER_CACHE = {};
const AVAILABILITY_CACHE = {};
let EXTERNAL_CATALOG_CACHE = null;
let EXTERNAL_CATALOG_ATTEMPTED = false;
let FLAT_CATALOG_CACHE = null;

source.enable = function () {};

function parseArchiveDuration(raw) {
    if (raw == null) return 0;
    const s = String(raw).trim();
    if (!s) return 0;
    if (/^\d+(?::\d+){1,2}$/.test(s)) return sansonSecs(s);
    const n = parseFloat(s);
    return isNaN(n) || n < 0 ? 0 : Math.floor(n);
}

function isPlayableMedia(name) {
    if (!name) return false;
    const lower = name.toLowerCase();
    if (
        lower.includes("sample") ||
        lower.includes(".ia.") ||
        lower.endsWith(".thumbs") ||
        lower.endsWith(".jpg") ||
        lower.endsWith(".png")
    ) {
        return false;
    }
    return (
        lower.endsWith(".mp4") ||
        lower.endsWith(".mkv") ||
        lower.endsWith(".ogv") ||
        lower.endsWith(".webm")
    );
}

function formatEpisodeLabel(file) {
    return (file.title || file.name.replace(/\.[^/.]+$/, "").replace(/[_-]+/g, " "))
        .replace(/\s+/g, " ")
        .trim();
}

function encodeArchivePath(fileName) {
    return String(fileName || "")
        .split("/")
        .filter(Boolean)
        .map(encodeURIComponent)
        .join("/");
}

function defaultArchiveThumb(identifier) {
    return BASE_URL + "/services/img/" + encodeURIComponent(identifier);
}

function fetchArchiveMetadata(identifier) {
    if (!identifier) return null;
    if (Object.prototype.hasOwnProperty.call(META_CACHE, identifier)) {
        return META_CACHE[identifier];
    }

    const metaUrl = BASE_URL + "/metadata/" + encodeURIComponent(identifier);
    let resp = null;
    try {
        resp = http.GET(metaUrl, { "User-Agent": UA, "Accept": "application/json" }, false);
    } catch (e) {
        META_CACHE[identifier] = null;
        return null;
    }

    if (!resp || resp.code !== 200) {
        META_CACHE[identifier] = null;
        return null;
    }

    try {
        const json = JSON.parse(resp.body);
        META_CACHE[identifier] = json || null;
        return META_CACHE[identifier];
    } catch (e) {
        META_CACHE[identifier] = null;
        return null;
    }
}

// Comprueba si un identificador de Internet Archive tiene al menos un archivo de video válido
function hasUsableArchiveMedia(identifier) {
    if (!identifier) return false;
    if (Object.prototype.hasOwnProperty.call(AVAILABILITY_CACHE, identifier)) {
        return AVAILABILITY_CACHE[identifier];
    }

    const json = fetchArchiveMetadata(identifier);
    if (!json || !Array.isArray(json.files)) {
        AVAILABILITY_CACHE[identifier] = false;
        return false;
    }

    for (let i = 0; i < json.files.length; i++) {
        const f = json.files[i];
        if (f && isPlayableMedia(f.name)) {
            AVAILABILITY_CACHE[identifier] = true;
            return true;
        }
    }

    AVAILABILITY_CACHE[identifier] = false;
    return false;
}

// Comprueba si una entrada de serie del JSON tiene contenido usable (no está vacía)
function isSeriesEmpty(ser, ids) {
    const hasEpisodesArray = Array.isArray(ser.episodes) && ser.episodes.length > 0;
    const hasPositiveCount = typeof ser.episodeCount === "number" && ser.episodeCount > 0;
    const hasArchiveIds = Array.isArray(ids) && ids.length > 0;

    if (!hasArchiveIds && !hasEpisodesArray) return true;
    if (typeof ser.episodeCount === "number" && ser.episodeCount === 0 && !hasEpisodesArray) return true;
    if (!hasEpisodesArray && !hasPositiveCount && (!ids || ids.length === 0)) return true;

    return false;
}

function resolveArchiveCover(identifier, archiveIds) {
    const candidates = [];
    if (Array.isArray(archiveIds) && archiveIds.length > 0) {
        for (let i = 0; i < archiveIds.length; i++) {
            if (archiveIds[i]) candidates.push(String(archiveIds[i]).trim());
        }
    }
    if (identifier && candidates.indexOf(identifier) === -1) {
        candidates.unshift(identifier);
    }
    if (!candidates.length) return "";

    const cacheKey = candidates.join("|");
    if (Object.prototype.hasOwnProperty.call(COVER_CACHE, cacheKey)) {
        return COVER_CACHE[cacheKey];
    }

    for (let i = 0; i < candidates.length; i++) {
        const id = candidates[i];
        const json = fetchArchiveMetadata(id);
        const files = (json && Array.isArray(json.files)) ? json.files : [];

        let matchedCover = null;
        let thumbFile = null;

        for (let j = 0; j < files.length; j++) {
            const f = files[j];
            if (!f || !f.name) continue;
            const name = String(f.name);
            const lower = name.toLowerCase();

            if (!matchedCover && /(^|[_\-\/])(cover|poster|front|folder)([_\-\.]|\d|$).*\.(jpe?g|png|webp)$/i.test(lower)) {
                matchedCover = name;
            }
            if (!thumbFile && lower === "__ia_thumb.jpg") {
                thumbFile = name;
            }
        }

        if (matchedCover) {
            const url = BASE_URL + "/download/" + encodeURIComponent(id) + "/" + encodeArchivePath(matchedCover);
            COVER_CACHE[cacheKey] = url;
            return url;
        }

        if (thumbFile) {
            const url = BASE_URL + "/download/" + encodeURIComponent(id) + "/" + encodeArchivePath(thumbFile);
            COVER_CACHE[cacheKey] = url;
            return url;
        }
    }

    const fallback = defaultArchiveThumb(candidates[0]);
    COVER_CACHE[cacheKey] = fallback;
    return fallback;
}

function listArchiveMediaFiles(identifier) {
    const json = fetchArchiveMetadata(identifier);
    if (!json) {
        throw new ScriptException("No se pudo conectar con Internet Archive.");
    }

    const meta = json.metadata || {};
    const files = Array.isArray(json.files) ? json.files : [];
    const media = [];

    for (let i = 0; i < files.length; i++) {
        const f = files[i];
        if (!f || !isPlayableMedia(f.name)) continue;
        media.push(f);
    }

    media.sort(function (a, b) {
        const na = formatEpisodeLabel(a);
        const nb = formatEpisodeLabel(b);
        return na.localeCompare(nb, undefined, { numeric: true });
    });

    AVAILABILITY_CACHE[identifier] = media.length > 0;

    const rawTitle = meta.title;
    const title = Array.isArray(rawTitle) ? (rawTitle[0] || identifier) : (rawTitle || identifier);
    const rawDesc = Array.isArray(meta.description) ? meta.description.join("\n") : (meta.description || "");
    const desc = String(rawDesc).replace(/<[^>]+>/g, "").trim();

    return { title: title, desc: desc, files: media };
}

function loadExternalCatalog() {
    if (!GITHUB_CATALOG_URL) return null;
    if (EXTERNAL_CATALOG_ATTEMPTED) return EXTERNAL_CATALOG_CACHE;
    EXTERNAL_CATALOG_ATTEMPTED = true;

    try {
        const resp = http.GET(GITHUB_CATALOG_URL, { "User-Agent": UA, "Accept": "application/json, text/plain, */*" }, false);
        if (!resp || resp.code !== 200 || !resp.body) {
            EXTERNAL_CATALOG_CACHE = null;
            return null;
        }
        EXTERNAL_CATALOG_CACHE = JSON.parse(resp.body);
        return EXTERNAL_CATALOG_CACHE;
    } catch (e) {
        EXTERNAL_CATALOG_CACHE = null;
        return null;
    }
}

function getCatalogCategoriesGrouped() {
    const cat = loadExternalCatalog();
    if (!cat || !Array.isArray(cat.categories)) return [];

    const groups = [];
    for (let c = 0; c < cat.categories.length; c++) {
        const category = cat.categories[c];
        if (!category) continue;
        const catName = String(category.category || category.name || "Catálogo").trim();
        const seriesArr = Array.isArray(category.series) ? category.series : [];
        const entries = [];

        for (let s = 0; s < seriesArr.length; s++) {
            const ser = seriesArr[s];
            if (!ser) continue;

            const ids = Array.isArray(ser.archiveIds) ? ser.archiveIds.filter(Boolean) : [];
            const firstEp = (Array.isArray(ser.episodes) && ser.episodes.length > 0) ? ser.episodes[0] : null;
            if (!ids.length && firstEp && firstEp.archiveId) ids.push(firstEp.archiveId);

            if (isSeriesEmpty(ser, ids)) continue;

            const seriesId = ser.id || ids[0];
            const seriesTitle = ser.title || ser.name || ids[0];

            entries.push({
                id: seriesId,
                title: seriesTitle,
                category: String(ser.category || catName).trim(),
                year: ser.year || "",
                description: ser.description || "",
                archiveIds: ids,
                episodes: Array.isArray(ser.episodes) ? ser.episodes : []
            });
        }

        if (entries.length > 0) {
            groups.push({ name: catName, series: entries });
        }
    }

    return groups;
}

function getCatalogSeriesList() {
    if (FLAT_CATALOG_CACHE !== null) return FLAT_CATALOG_CACHE;

    const groups = getCatalogCategoriesGrouped();
    const list = [];
    for (let g = 0; g < groups.length; g++) {
        for (let s = 0; s < groups[g].series.length; s++) {
            list.push(groups[g].series[s]);
        }
    }

    FLAT_CATALOG_CACHE = list;
    return list;
}

function findCatalogEntryById(identifier) {
    const list = getCatalogSeriesList();
    for (let i = 0; i < list.length; i++) {
        if (list[i].id === identifier || list[i].archiveIds.indexOf(identifier) !== -1) {
            return list[i];
        }
    }
    return null;
}

function channelItem(identifier, title, desc, archiveIds) {
    const thumb = resolveArchiveCover(identifier, archiveIds);
    const url = BASE_URL + "/details/" + encodeURIComponent(identifier);
    return new PlatformChannel({
        id: sansonPid(PLATFORM, identifier),
        name: title || identifier,
        thumbnail: thumb,
        url: url,
        description: desc || "",
        subscribers: -1
    });
}

function videoItem(identifier, fileName, title, duration, archiveIds, categoryTag, fastThumb) {
    const thumb = fastThumb
        ? defaultArchiveThumb((archiveIds && archiveIds[0]) || identifier)
        : resolveArchiveCover(identifier, archiveIds);
    const url = BASE_URL + "/details/" + encodeURIComponent(identifier) + (fileName ? "#file=" + encodeURIComponent(fileName) : "");
    const displayName = categoryTag ? "[" + categoryTag + "] " + (title || identifier) : (title || identifier);
    return new PlatformVideo({
        id: sansonPid(PLATFORM, identifier + (fileName ? "-" + fileName : "")),
        name: displayName,
        thumbnails: sansonThumbs(thumb),
        author: sansonAuthor(PLATFORM, "", categoryTag || "Internet Archive", BASE_URL, null),
        duration: duration || 0,
        viewCount: -1,
        url: url,
        isLive: false
    });
}

function buildFilteredCatalogItems(searchQuery) {
    const groups = getCatalogCategoriesGrouped();
    const qLower = (searchQuery || "").toLowerCase();
    const items = [];

    for (let g = 0; g < groups.length; g++) {
        const grp = groups[g];
        for (let i = 0; i < grp.series.length; i++) {
            const entry = grp.series[i];
            const hay = (entry.title + " " + entry.category + " " + entry.year).toLowerCase();
            if (!qLower || hay.indexOf(qLower) !== -1) {
                const label = entry.title + (entry.year ? " (" + entry.year + ")" : "");
                items.push(videoItem(entry.archiveIds[0], null, label, 0, entry.archiveIds, grp.name, true));
            }
        }
    }

    return items;
}

function fetchArchivePage(ctx) {
    const searchQuery = (ctx && ctx.query) ? String(ctx.query).trim() : "";
    const stage = (ctx && ctx.stage) ? String(ctx.stage) : "catalog";
    const page = (ctx && ctx.page) ? parseInt(ctx.page, 10) : 1;

    // 1. Primero muestra todas las series no vacías del catálogo JSON organizadas por categoría
    if (stage === "catalog") {
        const catalogItems = buildFilteredCatalogItems(searchQuery);
        if (catalogItems.length > 0) {
            return {
                results: catalogItems,
                more: true,
                context: { query: searchQuery, stage: "archive", page: 1 }
            };
        }
    }

    // 2. Apenas se acaben las del JSON, carga Internet Archive omitiendo ítems vacíos o sin archivos reproducibles
    const baseFilter = "mediatype:(movies) AND language:(Spanish OR spa)";
    const fullQuery = searchQuery ? "(" + searchQuery + ") AND " + baseFilter : baseFilter;

    const apiUrl = BASE_URL + "/advancedsearch.php?q=" + encodeURIComponent(fullQuery) +
        "&fl[]=identifier&fl[]=title&fl[]=description&fl[]=year" +
        "&sort[]=downloads+desc&rows=" + PAGE_ROWS + "&page=" + page + "&output=json";

    let resp = null;
    try {
        resp = http.GET(apiUrl, { "User-Agent": UA, "Accept": "application/json" }, false);
    } catch (e) {
        return {
            results: [],
            more: false,
            context: { query: searchQuery, stage: "archive", page: page }
        };
    }

    if (!resp || resp.code !== 200) {
        return {
            results: [],
            more: false,
            context: { query: searchQuery, stage: "archive", page: page }
        };
    }

    const json = JSON.parse(resp.body);
    const docs = (json && json.response && Array.isArray(json.response.docs)) ? json.response.docs : [];
    const items = [];

    for (let i = 0; i < docs.length; i++) {
        const d = docs[i];
        if (!d || !d.identifier) continue;

        // Si el ítem está ya en caché como vacío, saltarlo
        if (Object.prototype.hasOwnProperty.call(AVAILABILITY_CACHE, d.identifier) && !AVAILABILITY_CACHE[d.identifier]) {
            continue;
        }

        const rawTitle = Array.isArray(d.title) ? d.title[0] : (d.title || d.identifier);
        const year = d.year ? " (" + d.year + ")" : "";
        items.push(videoItem(d.identifier, null, rawTitle + year, 0, [d.identifier], "Internet Archive", true));
    }

    return {
        results: items,
        more: docs.length >= PAGE_ROWS,
        context: { query: searchQuery, stage: "archive", page: page + 1 }
    };
}

source.getHome = function () {
    return new SansonPager(fetchArchivePage, { query: "", stage: "catalog", page: 1 });
};

source.search = function (query) {
    return new SansonPager(fetchArchivePage, { query: String(query || ""), stage: "catalog", page: 1 });
};

source.getChannel = function (url) {
    const match = /\/details\/([^\/?#]+)/.exec(url || "");
    const identifier = match ? decodeURIComponent(match[1]) : "";
    if (!identifier) throw new ScriptException("URL de Internet Archive inválida.");

    const entry = findCatalogEntryById(identifier);
    const ids = entry ? entry.archiveIds : [identifier];
    let title = entry ? entry.title : identifier;
    let desc = entry ? entry.description : "";

    try {
        const info = listArchiveMediaFiles(ids[0]);
        if (!entry) title = info.title;
        if (!desc) desc = info.desc;
    } catch (e) {}

    return channelItem(ids[0], title, desc, ids);
};

source.getChannelContents = function (url) {
    const match = /\/details\/([^\/?#]+)/.exec(url || "");
    const identifier = match ? decodeURIComponent(match[1]) : "";
    if (!identifier) return new VideoPager([], false, {});

    const entry = findCatalogEntryById(identifier);
    const ids = entry ? entry.archiveIds : [identifier];
    const items = [];

    if (entry && Array.isArray(entry.episodes) && entry.episodes.length > 0) {
        for (let i = 0; i < entry.episodes.length; i++) {
            const ep = entry.episodes[i];
            if (!ep) continue;
            const arcId = ep.archiveId || ids[0];
            const rawFile = ep.archiveFile ? decodeURIComponent(ep.archiveFile) : "";
            const sStr = ep.season ? "S" + String(ep.season).padStart(2, "0") : "";
            const eStr = ep.episode ? "E" + String(ep.episode).padStart(2, "0") : "";
            const prefix = (sStr || eStr) ? (sStr + eStr + " - ") : "";
            const label = prefix + (ep.title || rawFile || ("Episodio " + (i + 1)));
            items.push(videoItem(arcId, rawFile || null, label, 0, ids, entry.category, false));
        }
        return new VideoPager(items, false, {});
    }

    for (let a = 0; a < ids.length; a++) {
        const arcId = ids[a];
        try {
            const info = listArchiveMediaFiles(arcId);
            for (let i = 0; i < info.files.length; i++) {
                const f = info.files[i];
                const cleanName = formatEpisodeLabel(f);
                const dur = parseArchiveDuration(f.length);
                items.push(videoItem(arcId, f.name, cleanName, dur, ids, entry ? entry.category : null, false));
            }
        } catch (e) {}
    }

    return new VideoPager(items, false, {});
};

source.getContentDetails = function (url) {
    const match = /\/details\/([^\/?#]+)/.exec(url || "");
    const identifier = match ? decodeURIComponent(match[1]) : "";
    if (!identifier) throw new ScriptException("URL de contenido inválida.");

    const fileMatch = /#file=([^&]+)/.exec(url || "");
    const targetFile = fileMatch ? decodeURIComponent(fileMatch[1]) : null;

    const info = listArchiveMediaFiles(identifier);
    const files = info.files;
    if (!files.length) {
        AVAILABILITY_CACHE[identifier] = false;
        throw new ScriptException("Este ítem está vacío o no tiene archivos de video reproducibles.");
    }

    let finalFile = null;
    if (targetFile) {
        for (let i = 0; i < files.length; i++) {
            if (files[i].name === targetFile) {
                finalFile = files[i];
                break;
            }
        }
    }

    if (!finalFile) {
        for (let i = 0; i < files.length; i++) {
            const lower = files[i].name.toLowerCase();
            if (lower.endsWith(".mp4")) {
                if (!finalFile || files[i].source === "original") {
                    finalFile = files[i];
                }
            }
        }
    }

    if (!finalFile) finalFile = files[0];

    const encodedPath = encodeArchivePath(finalFile.name);
    const videoUrl = BASE_URL + "/download/" + encodeURIComponent(identifier) + "/" + encodedPath;

    const entry = findCatalogEntryById(identifier);
    const ids = entry ? entry.archiveIds : [identifier];
    const baseTitle = (entry && entry.title) ? entry.title : info.title;

    let epTitle = "";
    if (targetFile || files.length > 1) {
        const rawEp = formatEpisodeLabel(finalFile);
        const normBase = baseTitle.toLowerCase().replace(/[^a-z0-9]+/g, " ").trim();
        const normEp = rawEp.toLowerCase().replace(/[^a-z0-9]+/g, " ").trim();
        const strippedEp = (normBase && normEp.startsWith(normBase))
            ? rawEp.replace(new RegExp("^" + baseTitle.replace(/[.*+?^${}()|[\]\\]/g, "\\$&") + "[\\s:–—-]*", "i"), "").trim()
            : rawEp;
        epTitle = strippedEp ? " - " + strippedEp : "";
    }

    const totalInfo = files.length > 1 ? "\nEpisodios disponibles en este ítem: " + files.length : "";
    const fullDesc = ((entry && entry.description) || info.desc || "Contenido disponible en Internet Archive.") + totalInfo;

    const thumb = resolveArchiveCover(identifier, ids);
    const duration = parseArchiveDuration(finalFile.length);
    const ext = finalFile.name.split(".").pop().toLowerCase();

    return new PlatformVideoDetails({
        id: sansonPid(PLATFORM, url),
        name: baseTitle + epTitle,
        thumbnails: sansonThumbs(thumb),
        author: sansonAuthor(PLATFORM, BASE_URL + "/details/" + encodeURIComponent(identifier), baseTitle, BASE_URL, null),
        url: url,
        duration: duration,
        viewCount: -1,
        description: fullDesc,
        video: new VideoSourceDescriptor([
            new VideoUrlSource({
                name: ext.toUpperCase(),
                url: videoUrl,
                width: parseInt(finalFile.width || "0", 10) || 0,
                height: parseInt(finalFile.height || "0", 10) || 0,
                codec: "",
                container: ext,
                bitrate: 0,
                duration: duration
            })
        ])
    });
};

source.getContentRecommendations = function (url) {
    const match = /\/details\/([^\/?#]+)/.exec(url || "");
    const identifier = match ? decodeURIComponent(match[1]) : "";
    if (!identifier) return new VideoPager([], false, {});

    const fileMatch = /#file=([^&]+)/.exec(url || "");
    const currentFile = fileMatch ? decodeURIComponent(fileMatch[1]) : null;

    const entry = findCatalogEntryById(identifier);
    const ids = entry ? entry.archiveIds : [identifier];

    try {
        const info = listArchiveMediaFiles(identifier);
        if (info.files.length <= 1) return new VideoPager([], false, {});

        const items = [];
        for (let i = 0; i < info.files.length; i++) {
            const f = info.files[i];
            if (currentFile && f.name === currentFile) continue;
            items.push(videoItem(identifier, f.name, formatEpisodeLabel(f), parseArchiveDuration(f.length), ids, entry ? entry.category : null, false));
        }
        return new VideoPager(items, false, {});
    } catch (e) {
        return new VideoPager([], false, {});
    }
};
