// Internet Archive plugin para Sanson — Películas y Series en Español
const PLATFORM = "Internet Archive";
const BASE_URL = "https://archive.org";
const UA = "Mozilla/5.0 (X11; Linux x86_64; rv:133.0) Gecko/20100101 Firefox/133.0";
const PAGE_ROWS = 30;

source.enable = function () {};

function parseArchiveDuration(raw) {
    if (raw == null) return 0;
    const s = String(raw).trim();
    if (!s) return 0;
    if (/^\d+(?::\d+){1,2}$/.test(s)) return sansonSecs(s);
    const n = parseFloat(s);
    return isNaN(n) || n < 0 ? 0 : Math.floor(n);
}

function isPlayableMedia(name) {
    if (!name) return false;
    const lower = name.toLowerCase();
    if (
        lower.includes("sample") ||
        lower.endsWith(".thumbs") ||
        lower.endsWith(".jpg") ||
        lower.endsWith(".png")
    ) {
        return false;
    }
    return (
        lower.endsWith(".mp4") ||
        lower.endsWith(".mkv") ||
        lower.endsWith(".ogv") ||
        lower.endsWith(".webm")
    );
}

function listArchiveMediaFiles(identifier) {
    const metaUrl = BASE_URL + "/metadata/" + identifier;
    const resp = http.GET(metaUrl, { "User-Agent": UA }, false);
    if (resp.code !== 200) {
        throw new ScriptException("No se pudo conectar con Internet Archive.");
    }

    const json = JSON.parse(resp.body);
    const meta = (json && json.metadata) ? json.metadata : {};
    const files = (json && Array.isArray(json.files)) ? json.files : [];
    const media = [];

    for (let i = 0; i < files.length; i++) {
        const f = files[i];
        if (!f || !isPlayableMedia(f.name)) continue;
        media.push(f);
    }

    media.sort(function (a, b) {
        const na = a.title || a.name || "";
        const nb = b.title || b.name || "";
        return na.localeCompare(nb, undefined, { numeric: true });
    });

    const rawTitle = meta.title;
    const title = Array.isArray(rawTitle) ? (rawTitle[0] || identifier) : (rawTitle || identifier);
    const rawDesc = Array.isArray(meta.description) ? meta.description.join("\n") : (meta.description || "");
    const desc = String(rawDesc).replace(/<[^>]+>/g, "").trim();

    return { title: title, desc: desc, files: media };
}

// Construye un objeto de Canal (usado para series o ítems con varios archivos)
function channelItem(identifier, title, desc) {
    const thumb = BASE_URL + "/services/img/" + identifier;
    const url = BASE_URL + "/details/" + identifier;
    return new PlatformChannel({
        id: sansonPid(PLATFORM, identifier),
        name: title || identifier,
        thumbnail: thumb,
        url: url,
        description: desc || "",
        subscribers: -1
    });
}

// Construye un objeto de Video individual (película o episodio)
function videoItem(identifier, fileName, title, duration) {
    const thumb = BASE_URL + "/services/img/" + identifier;
    // Usamos #file= para identificar capítulos dentro de un mismo ítem de Archive.org
    const url = BASE_URL + "/details/" + identifier + (fileName ? "#file=" + encodeURIComponent(fileName) : "");
    return new PlatformVideo({
        id: sansonPid(PLATFORM, identifier + (fileName ? "-" + fileName : "")),
        name: title || identifier,
        thumbnails: sansonThumbs(thumb),
        author: sansonAuthor(PLATFORM, "", "Internet Archive", BASE_URL, null),
        duration: duration || 0,
        viewCount: -1,
        url: url,
        isLive: false
    });
}

function buildArchiveEntry(doc, checkMultiEpisode) {
    const identifier = doc.identifier;
    const rawTitle = Array.isArray(doc.title) ? doc.title[0] : (doc.title || identifier);
    const year = doc.year ? " (" + doc.year + ")" : "";
    const fallbackName = rawTitle + year;

    if (!checkMultiEpisode) {
        return videoItem(identifier, null, fallbackName, 0);
    }

    try {
        const info = listArchiveMediaFiles(identifier);
        if (info.files.length > 1) {
            const label = info.title + year + " [" + info.files.length + " cap.]";
            return channelItem(identifier, label, info.desc);
        }
        if (info.files.length === 1) {
            const f = info.files[0];
            return videoItem(identifier, f.name, info.title + year, parseArchiveDuration(f.length));
        }
    } catch (e) {}

    return videoItem(identifier, null, fallbackName, 0);
}

function fetchArchivePage(ctx) {
    const page = (ctx && ctx.page) ? parseInt(ctx.page, 10) : 1;
    const searchQuery = (ctx && ctx.query) ? String(ctx.query).trim() : "";
    const baseFilter = "mediatype:(movies) AND language:(Spanish OR spa)";
    const fullQuery = searchQuery ? "(" + searchQuery + ") AND " + baseFilter : baseFilter;

    const apiUrl = BASE_URL + "/advancedsearch.php?q=" + encodeURIComponent(fullQuery) +
        "&fl[]=identifier&fl[]=title&fl[]=description&fl[]=year" +
        "&sort[]=downloads+desc&rows=" + PAGE_ROWS + "&page=" + page + "&output=json";

    const resp = http.GET(apiUrl, { "User-Agent": UA, "Accept": "application/json" }, false);
    if (resp.code !== 200) {
        return {
            results: [],
            more: false,
            context: { query: searchQuery, page: page }
        };
    }

    const json = JSON.parse(resp.body);
    const docs = (json && json.response && Array.isArray(json.response.docs)) ? json.response.docs : [];
    const items = [];
    const shouldCheckSeries = searchQuery.length > 0 && docs.length <= 15;

    for (let i = 0; i < docs.length; i++) {
        const d = docs[i];
        if (!d || !d.identifier) continue;
        items.push(buildArchiveEntry(d, shouldCheckSeries));
    }

    return {
        results: items,
        more: docs.length >= PAGE_ROWS,
        context: { query: searchQuery, page: page + 1 }
    };
}

// Pantalla principal: muestra las películas/series en español más descargadas
source.getHome = function () {
    return new SansonPager(fetchArchivePage, { query: "", page: 1 });
};

// Buscador: filtra por palabra clave + idioma español
source.search = function (query) {
    return new SansonPager(fetchArchivePage, { query: String(query || ""), page: 1 });
};

// Información del ítem como canal (útil si el usuario entra a ver todos los capítulos)
source.getChannel = function (url) {
    const match = /\/details\/([^\/?#]+)/.exec(url || "");
    const identifier = match ? match[1] : "";
    if (!identifier) throw new ScriptException("URL de Internet Archive inválida.");

    let title = identifier;
    let desc = "";
    try {
        const info = listArchiveMediaFiles(identifier);
        title = info.title;
        desc = info.desc;
    } catch (e) {}

    return channelItem(identifier, title, desc);
};

// Lista todos los archivos de video dentro de un ítem (ideal para series o temporadas completas)
source.getChannelContents = function (url) {
    const match = /\/details\/([^\/?#]+)/.exec(url || "");
    const identifier = match ? match[1] : "";
    if (!identifier) return new VideoPager([], false, {});

    const info = listArchiveMediaFiles(identifier);
    const items = [];

    for (let i = 0; i < info.files.length; i++) {
        const f = info.files[i];
        const cleanName = (f.title || f.name.replace(/\.[^/.]+$/, "").replace(/[_-]+/g, " "))
            .replace(/\s+/g, " ")
            .trim();
        const dur = parseArchiveDuration(f.length);
        items.push(videoItem(identifier, f.name, cleanName, dur));
    }

    items.sort(function (a, b) {
        return a.name.localeCompare(b.name, undefined, { numeric: true });
    });

    return new VideoPager(items, false, {});
};

// Extrae el enlace directo al archivo de video (.mp4) para reproducirlo
source.getContentDetails = function (url) {
    const match = /\/details\/([^\/?#]+)/.exec(url || "");
    const identifier = match ? match[1] : "";
    if (!identifier) throw new ScriptException("URL de contenido inválida.");

    const fileMatch = /#file=([^&]+)/.exec(url || "");
    const targetFile = fileMatch ? decodeURIComponent(fileMatch[1]) : null;

    const metaUrl = BASE_URL + "/metadata/" + identifier;
    const resp = http.GET(metaUrl, { "User-Agent": UA }, false);
    if (resp.code !== 200) throw new ScriptException("No se pudo conectar con Internet Archive.");

    const json = JSON.parse(resp.body);
    const meta = (json && json.metadata) ? json.metadata : {};
    const files = (json && Array.isArray(json.files)) ? json.files : [];

    let selectedFile = null;
    let fallbackFile = null;

    for (let i = 0; i < files.length; i++) {
        const f = files[i];
        if (!f || !isPlayableMedia(f.name)) continue;
        const lower = f.name.toLowerCase();

        // Si se pidió un episodio específico de una serie
        if (targetFile && f.name === targetFile) {
            selectedFile = f;
            break;
        }

        // Si es una película o primer capítulo, priorizar formato MP4 estándar
        if (!targetFile) {
            if (lower.endsWith(".mp4")) {
                if (!selectedFile || f.source === "original") {
                    selectedFile = f;
                }
            } else if (!fallbackFile) {
                fallbackFile = f;
            }
        }
    }

    const finalFile = selectedFile || fallbackFile;
    if (!finalFile) throw new ScriptException("No se encontró un archivo de video compatible.");

    // Codificar segmentos de ruta respetando subcarpetas dentro del ítem
    const encodedPath = finalFile.name.split("/").map(encodeURIComponent).join("/");
    const videoUrl = BASE_URL + "/download/" + identifier + "/" + encodedPath;

    const rawTitle = meta.title;
    const baseTitle = Array.isArray(rawTitle) ? (rawTitle[0] || identifier) : (rawTitle || identifier);

    let epTitle = "";
    if (targetFile) {
        const rawEp = (finalFile.title || finalFile.name.replace(/\.[^/.]+$/, ""))
            .replace(/[_-]+/g, " ")
            .replace(/\s+/g, " ")
            .trim();
        const normBase = baseTitle.toLowerCase().replace(/[^a-z0-9]+/g, " ").trim();
        const normEp = rawEp.toLowerCase().replace(/[^a-z0-9]+/g, " ").trim();
        const strippedEp = (normBase && normEp.startsWith(normBase))
            ? rawEp.replace(new RegExp("^" + baseTitle.replace(/[.*+?^${}()|[\]\\]/g, "\\$&") + "[\\s:–—-]*", "i"), "").trim()
            : rawEp;
        epTitle = strippedEp ? " - " + strippedEp : "";
    }

    const rawDesc = Array.isArray(meta.description) ? meta.description.join("\n") : (meta.description || "");
    const cleanDesc = String(rawDesc).replace(/<[^>]+>/g, "").trim();

    const thumb = BASE_URL + "/services/img/" + identifier;
    const duration = parseArchiveDuration(finalFile.length);
    const ext = finalFile.name.split(".").pop().toLowerCase();

    return new PlatformVideoDetails({
        id: sansonPid(PLATFORM, url),
        name: baseTitle + epTitle,
        thumbnails: sansonThumbs(thumb),
        author: sansonAuthor(PLATFORM, BASE_URL + "/details/" + identifier, baseTitle, BASE_URL, null),
        url: url,
        duration: duration,
        viewCount: -1,
        description: cleanDesc || "Contenido disponible en Internet Archive.",
        video: new VideoSourceDescriptor([
            new VideoUrlSource({
                name: ext.toUpperCase(),
                url: videoUrl,
                width: parseInt(finalFile.width || "0", 10) || 0,
                height: parseInt(finalFile.height || "0", 10) || 0,
                codec: "",
                container: ext,
                bitrate: 0,
                duration: duration
            })
        ])
    });
};

source.getContentRecommendations = function (url) {
    return new VideoPager([], false, {});
};
