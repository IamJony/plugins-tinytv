// Internet Archive plugin para Sanson — Rápido en inicio/búsqueda y con capítulos completos
const PLATFORM = "Internet Archive";
const BASE_URL = "https://archive.org";
const UA = "Mozilla/5.0 (X11; Linux x86_64; rv:133.0) Gecko/20100101 Firefox/133.0";
const PAGE_ROWS = 30;

source.enable = function () {};

function parseArchiveDuration(raw) {
    if (raw == null) return 0;
    const s = String(raw).trim();
    if (!s) return 0;
    if (/^\d+(?::\d+){1,2}$/.test(s)) return sansonSecs(s);
    const n = parseFloat(s);
    return isNaN(n) || n < 0 ? 0 : Math.floor(n);
}

function isPlayableMedia(name) {
    if (!name) return false;
    const lower = name.toLowerCase();
    if (
        lower.includes("sample") ||
        lower.includes(".ia.") ||
        lower.endsWith(".thumbs") ||
        lower.endsWith(".jpg") ||
        lower.endsWith(".png")
    ) {
        return false;
    }
    return (
        lower.endsWith(".mp4") ||
        lower.endsWith(".mkv") ||
        lower.endsWith(".ogv") ||
        lower.endsWith(".webm")
    );
}

function formatEpisodeLabel(file) {
    return (file.title || file.name.replace(/\.[^/.]+$/, "").replace(/[_-]+/g, " "))
        .replace(/\s+/g, " ")
        .trim();
}

function listArchiveMediaFiles(identifier) {
    const metaUrl = BASE_URL + "/metadata/" + encodeURIComponent(identifier);
    const resp = http.GET(metaUrl, { "User-Agent": UA }, false);
    if (resp.code !== 200) {
        throw new ScriptException("No se pudo conectar con Internet Archive.");
    }

    const json = JSON.parse(resp.body);
    const meta = (json && json.metadata) ? json.metadata : {};
    const files = (json && Array.isArray(json.files)) ? json.files : [];
    const media = [];

    for (let i = 0; i < files.length; i++) {
        const f = files[i];
        if (!f || !isPlayableMedia(f.name)) continue;
        media.push(f);
    }

    media.sort(function (a, b) {
        const na = formatEpisodeLabel(a);
        const nb = formatEpisodeLabel(b);
        return na.localeCompare(nb, undefined, { numeric: true });
    });

    const rawTitle = meta.title;
    const title = Array.isArray(rawTitle) ? (rawTitle[0] || identifier) : (rawTitle || identifier);
    const rawDesc = Array.isArray(meta.description) ? meta.description.join("\n") : (meta.description || "");
    const desc = String(rawDesc).replace(/<[^>]+>/g, "").trim();

    return { title: title, desc: desc, files: media };
}

function channelItem(identifier, title, desc) {
    const thumb = BASE_URL + "/services/img/" + encodeURIComponent(identifier);
    const url = BASE_URL + "/details/" + encodeURIComponent(identifier);
    return new PlatformChannel({
        id: sansonPid(PLATFORM, identifier),
        name: title || identifier,
        thumbnail: thumb,
        url: url,
        description: desc || "",
        subscribers: -1
    });
}

function videoItem(identifier, fileName, title, duration) {
    const thumb = BASE_URL + "/services/img/" + encodeURIComponent(identifier);
    const url = BASE_URL + "/details/" + encodeURIComponent(identifier) + (fileName ? "#file=" + encodeURIComponent(fileName) : "");
    return new PlatformVideo({
        id: sansonPid(PLATFORM, identifier + (fileName ? "-" + fileName : "")),
        name: title || identifier,
        thumbnails: sansonThumbs(thumb),
        author: sansonAuthor(PLATFORM, "", "Internet Archive", BASE_URL, null),
        duration: duration || 0,
        viewCount: -1,
        url: url,
        isLive: false
    });
}

function fetchArchivePage(ctx) {
    const page = (ctx && ctx.page) ? parseInt(ctx.page, 10) : 1;
    const searchQuery = (ctx && ctx.query) ? String(ctx.query).trim() : "";
    const baseFilter = "mediatype:(movies) AND language:(Spanish OR spa)";
    const fullQuery = searchQuery ? "(" + searchQuery + ") AND " + baseFilter : baseFilter;

    const apiUrl = BASE_URL + "/advancedsearch.php?q=" + encodeURIComponent(fullQuery) +
        "&fl[]=identifier&fl[]=title&fl[]=description&fl[]=year" +
        "&sort[]=downloads+desc&rows=" + PAGE_ROWS + "&page=" + page + "&output=json";

    const resp = http.GET(apiUrl, { "User-Agent": UA, "Accept": "application/json" }, false);
    if (resp.code !== 200) {
        return {
            results: [],
            more: false,
            context: { query: searchQuery, page: page }
        };
    }

    const json = JSON.parse(resp.body);
    const docs = (json && json.response && Array.isArray(json.response.docs)) ? json.response.docs : [];
    const items = [];

    for (let i = 0; i < docs.length; i++) {
        const d = docs[i];
        if (!d || !d.identifier) continue;
        const rawTitle = Array.isArray(d.title) ? d.title[0] : (d.title || d.identifier);
        const year = d.year ? " (" + d.year + ")" : "";
        items.push(videoItem(d.identifier, null, rawTitle + year, 0));
    }

    return {
        results: items,
        more: docs.length >= PAGE_ROWS,
        context: { query: searchQuery, page: page + 1 }
    };
}

source.getHome = function () {
    return new SansonPager(fetchArchivePage, { query: "", page: 1 });
};

source.search = function (query) {
    return new SansonPager(fetchArchivePage, { query: String(query || ""), page: 1 });
};

source.getChannel = function (url) {
    const match = /\/details\/([^\/?#]+)/.exec(url || "");
    const identifier = match ? decodeURIComponent(match[1]) : "";
    if (!identifier) throw new ScriptException("URL de Internet Archive inválida.");

    let title = identifier;
    let desc = "";
    try {
        const info = listArchiveMediaFiles(identifier);
        title = info.title;
        desc = info.desc;
    } catch (e) {}

    return channelItem(identifier, title, desc);
};

source.getChannelContents = function (url) {
    const match = /\/details\/([^\/?#]+)/.exec(url || "");
    const identifier = match ? decodeURIComponent(match[1]) : "";
    if (!identifier) return new VideoPager([], false, {});

    const info = listArchiveMediaFiles(identifier);
    const items = [];

    for (let i = 0; i < info.files.length; i++) {
        const f = info.files[i];
        const cleanName = formatEpisodeLabel(f);
        const dur = parseArchiveDuration(f.length);
        items.push(videoItem(identifier, f.name, cleanName, dur));
    }

    return new VideoPager(items, false, {});
};

source.getContentDetails = function (url) {
    const match = /\/details\/([^\/?#]+)/.exec(url || "");
    const identifier = match ? decodeURIComponent(match[1]) : "";
    if (!identifier) throw new ScriptException("URL de contenido inválida.");

    const fileMatch = /#file=([^&]+)/.exec(url || "");
    const targetFile = fileMatch ? decodeURIComponent(fileMatch[1]) : null;

    const info = listArchiveMediaFiles(identifier);
    const files = info.files;
    if (!files.length) throw new ScriptException("No se encontró un archivo de video compatible.");

    let finalFile = null;
    if (targetFile) {
        for (let i = 0; i < files.length; i++) {
            if (files[i].name === targetFile) {
                finalFile = files[i];
                break;
            }
        }
    }

    if (!finalFile) {
        for (let i = 0; i < files.length; i++) {
            const lower = files[i].name.toLowerCase();
            if (lower.endsWith(".mp4")) {
                if (!finalFile || files[i].source === "original") {
                    finalFile = files[i];
                }
            }
        }
    }

    if (!finalFile) finalFile = files[0];

    const encodedPath = finalFile.name.split("/").map(encodeURIComponent).join("/");
    const videoUrl = BASE_URL + "/download/" + encodeURIComponent(identifier) + "/" + encodedPath;

    const baseTitle = info.title;
    let epTitle = "";
    if (targetFile || files.length > 1) {
        const rawEp = formatEpisodeLabel(finalFile);
        const normBase = baseTitle.toLowerCase().replace(/[^a-z0-9]+/g, " ").trim();
        const normEp = rawEp.toLowerCase().replace(/[^a-z0-9]+/g, " ").trim();
        const strippedEp = (normBase && normEp.startsWith(normBase))
            ? rawEp.replace(new RegExp("^" + baseTitle.replace(/[.*+?^${}()|[\]\\]/g, "\\$&") + "[\\s:–—-]*", "i"), "").trim()
            : rawEp;
        epTitle = strippedEp ? " - " + strippedEp : "";
    }

    const totalInfo = files.length > 1 ? "\nEpisodios disponibles en este ítem: " + files.length : "";
    const fullDesc = (info.desc || "Contenido disponible en Internet Archive.") + totalInfo;

    const thumb = BASE_URL + "/services/img/" + encodeURIComponent(identifier);
    const duration = parseArchiveDuration(finalFile.length);
    const ext = finalFile.name.split(".").pop().toLowerCase();

    return new PlatformVideoDetails({
        id: sansonPid(PLATFORM, url),
        name: baseTitle + epTitle,
        thumbnails: sansonThumbs(thumb),
        author: sansonAuthor(PLATFORM, BASE_URL + "/details/" + encodeURIComponent(identifier), baseTitle, BASE_URL, null),
        url: url,
        duration: duration,
        viewCount: -1,
        description: fullDesc,
        video: new VideoSourceDescriptor([
            new VideoUrlSource({
                name: ext.toUpperCase(),
                url: videoUrl,
                width: parseInt(finalFile.width || "0", 10) || 0,
                height: parseInt(finalFile.height || "0", 10) || 0,
                codec: "",
                container: ext,
                bitrate: 0,
                duration: duration
            })
        ])
    });
};

source.getContentRecommendations = function (url) {
    const match = /\/details\/([^\/?#]+)/.exec(url || "");
    const identifier = match ? decodeURIComponent(match[1]) : "";
    if (!identifier) return new VideoPager([], false, {});

    const fileMatch = /#file=([^&]+)/.exec(url || "");
    const currentFile = fileMatch ? decodeURIComponent(fileMatch[1]) : null;

    try {
        const info = listArchiveMediaFiles(identifier);
        if (info.files.length <= 1) return new VideoPager([], false, {});

        const items = [];
        for (let i = 0; i < info.files.length; i++) {
            const f = info.files[i];
            if (currentFile && f.name === currentFile) continue;
            items.push(videoItem(identifier, f.name, formatEpisodeLabel(f), parseArchiveDuration(f.length)));
        }
        return new VideoPager(items, false, {});
    } catch (e) {
        return new VideoPager([], false, {});
    }
};
