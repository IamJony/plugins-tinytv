// Música: YouTube Music (WEB_REMIX innertube, no account) for Sanson.
// Songs, albums, artists and radio come from music.youtube.com; the audio itself is asked to the
// YouTube plugin by Sanson (same video id). Lyrics: LRCLIB (synced) and YouTube Music (plain).
// When YouTube gives no audio, sansonFallback() looks the song up on SoundCloud.

const PLATFORM = "Música";
const YTM = "https://music.youtube.com";
const UA = "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Safari/537.36";
const CLIENT = { clientName: "WEB_REMIX", clientVersion: "1.20251015.03.00", hl: "es" };
const SONGS_FILTER = "EgWKAQIIAWoKEAkQBRAKEAMQBA%3D%3D";
const ARTISTS_FILTER = "EgWKAQIgAWoKEAkQBRAKEAMQBA%3D%3D";
const BIG = 544;

let config = {};

source.enable = function (conf) {
    config = conf ?? {};
};

function ytm(endpoint, body, query) {
    const url = YTM + "/youtubei/v1/" + endpoint + "?prettyPrint=false" + (query ?? "");
    const resp = http.POST(url, JSON.stringify(Object.assign({ context: { client: CLIENT } }, body ?? {})), {
        "Content-Type": "application/json",
        "Origin": YTM,
        "Referer": YTM + "/",
        "User-Agent": UA
    }, false);
    if (!resp.isOk) {
        if (/google\.com\/sorry|unusual traffic|captcha/i.test(resp.body ?? ""))
            throw new CaptchaRequiredException(url, "");
        throw new ScriptException("YouTube Music respondió " + resp.code);
    }
    return JSON.parse(resp.body);
}

function text(t) {
    if (!t) return "";
    if (typeof t === "string") return t;
    if (t.simpleText) return t.simpleText;
    return (t.runs ?? []).map(r => r.text).join("");
}

function bigThumb(url) {
    if (!url) return "";
    if (url.startsWith("//")) url = "https:" + url;
    // lh3/yt3 images take the size in the URL: ask for a cover big enough for the player.
    if (/=w\d+-h\d+/.test(url)) return url.replace(/=w\d+-h\d+[^&]*$/, "=w" + BIG + "-h" + BIG + "-l90-rj");
    return url;
}

function thumbOf(o) {
    const list = o?.musicThumbnailRenderer?.thumbnail?.thumbnails ?? o?.thumbnails ?? o?.croppedSquareThumbnailRenderer?.thumbnail?.thumbnails ?? [];
    if (!list.length) return "";
    return bigThumb(list[list.length - 1].url);
}

function pageType(nav) {
    return nav?.browseEndpoint?.browseEndpointContextSupportedConfigs?.browseEndpointContextMusicConfig?.pageType ?? "";
}

function secs(s) {
    if (!/^\d+(:\d+){1,2}$/.test(s ?? "")) return 0;
    return s.split(":").reduce((a, b) => a * 60 + parseInt(b, 10), 0);
}

function count(s) {
    // "586 M reproducciones", "1,2 k", "54.300" -> number (approximate for M/k)
    const m = /([\d.,]+)\s*(k|K|mil|M|B|mill)?/.exec(s ?? "");
    if (!m) return -1;
    let n = parseFloat(m[1].replace(/\./g, "").replace(",", "."));
    if (m[2] && m[2].toLowerCase() === "k" || m[2] === "mil") n *= 1e3;
    else if (m[2] === "M" || m[2] === "mill") n *= 1e6;
    else if (m[2] === "B") n *= 1e9;
    return Math.round(n);
}

function pid(id) {
    return new PlatformID(PLATFORM, id, config.id);
}

function artistLink(runs, fallbackName, fallbackUrl) {
    const names = [], ids = [];
    for (const r of runs ?? []) {
        const t = pageType(r.navigationEndpoint);
        if (t === "MUSIC_PAGE_TYPE_ARTIST" || t === "MUSIC_PAGE_TYPE_USER_CHANNEL") {
            names.push(r.text);
            ids.push(r.navigationEndpoint.browseEndpoint.browseId);
        }
    }
    const name = names.length ? names.join(", ") : (fallbackName ?? "");
    const url = ids.length ? YTM + "/channel/" + ids[0] : (fallbackUrl ?? "");
    return new PlatformAuthorLink(pid(ids[0] ?? ""), name, url, null);
}

function song(o) {
    // o: {videoId, title, runs (artists/album/duration), thumb, duration, plays, album, albumUrl, artist, artistUrl}
    let album = o.album ?? "", albumUrl = o.albumUrl ?? "", duration = o.duration ?? 0, plays = o.plays ?? -1;
    const plain = [];
    for (const r of o.runs ?? []) {
        const t = pageType(r.navigationEndpoint);
        if (t === "MUSIC_PAGE_TYPE_ALBUM") {
            album = r.text;
            albumUrl = YTM + "/browse/" + r.navigationEndpoint.browseEndpoint.browseId;
        } else if (!t && r.text.trim() && r.text.trim() !== "•" && r.text.trim() !== "&" && r.text.trim() !== ",") {
            plain.push(r.text.trim());
        }
    }
    for (const p of plain) {
        if (!duration && secs(p)) duration = secs(p);
        else if (/reprod|plays|vistas|views/i.test(p)) plays = count(p);
    }
    let author = artistLink(o.runs, o.artist, o.artistUrl);
    if (!author.name) {
        // Runs without links: "Canción • Artista • Álbum • 3:33" -> the first plain text that is
        // not the type nor the duration.
        const kinds = /^(canción|song|video|vídeo|episodio|episode)$/i;
        const guess = plain.find(p => !kinds.test(p) && !secs(p) && !/reprod|plays|vistas|views/i.test(p));
        if (guess) author = new PlatformAuthorLink(pid(""), guess, o.artistUrl ?? "", null);
    }
    return new PlatformVideo({
        id: pid(o.videoId),
        name: o.title,
        thumbnails: new Thumbnails([new Thumbnail(o.thumb || ("https://i.ytimg.com/vi/" + o.videoId + "/hqdefault.jpg"), BIG)]),
        author: author,
        duration: duration,
        viewCount: plays,
        url: YTM + "/watch?v=" + o.videoId,
        isLive: false,
        sansonAlbum: album,
        sansonAlbumUrl: albumUrl
    });
}

function album(o) {
    return new PlatformPlaylist({
        id: pid(o.browseId),
        name: o.title,
        thumbnails: new Thumbnails([new Thumbnail(o.thumb, BIG)]),
        author: artistLink(o.runs, o.artist, o.artistUrl),
        url: YTM + "/browse/" + o.browseId,
        sansonKind: o.kind ?? "album",
        sansonSubtitle: o.subtitle ?? ""
    });
}

function artist(o) {
    return new PlatformChannel({
        id: pid(o.browseId),
        name: o.title,
        thumbnail: o.thumb,
        url: YTM + "/channel/" + o.browseId,
        subscribers: o.subs ?? -1
    });
}

// musicResponsiveListItemRenderer: search results, album tracks, artist top songs.
function fromResponsive(r, ctx) {
    const cols = (r.flexColumns ?? []).map(c => c.musicResponsiveListItemFlexColumnRenderer?.text?.runs ?? []);
    const title = (cols[0] ?? []).map(x => x.text).join("");
    const runs = [].concat(...cols.slice(1));
    const fixed = (r.fixedColumns ?? []).map(c => text(c.musicResponsiveListItemFixedColumnRenderer?.text)).join(" ");
    const thumb = thumbOf(r.thumbnail) || ctx?.thumb || "";
    const nav = r.navigationEndpoint;
    const t = pageType(nav);
    if (t === "MUSIC_PAGE_TYPE_ARTIST" || t === "MUSIC_PAGE_TYPE_USER_CHANNEL") {
        const sub = runs.map(x => x.text).find(x => /suscript|subscri|oyentes|listeners/i.test(x));
        return artist({ browseId: nav.browseEndpoint.browseId, title: title, thumb: thumb, subs: sub ? count(sub) : -1 });
    }
    if (t === "MUSIC_PAGE_TYPE_ALBUM" || t === "MUSIC_PAGE_TYPE_PLAYLIST") {
        return album({ browseId: nav.browseEndpoint.browseId, title: title, thumb: thumb, runs: runs,
            kind: t === "MUSIC_PAGE_TYPE_ALBUM" ? "album" : "playlist",
            subtitle: runs.map(x => x.text).join("") });
    }
    const videoId = r.playlistItemData?.videoId ??
        r.overlay?.musicItemThumbnailOverlayRenderer?.content?.musicPlayButtonRenderer?.playNavigationEndpoint?.watchEndpoint?.videoId ??
        (cols[0] ?? []).find(x => x.navigationEndpoint?.watchEndpoint)?.navigationEndpoint.watchEndpoint.videoId;
    if (!videoId)
        return null;
    return song({ videoId: videoId, title: title, runs: runs, thumb: thumb, duration: secs(fixed.trim()),
        album: ctx?.album, albumUrl: ctx?.albumUrl, artist: ctx?.artist, artistUrl: ctx?.artistUrl });
}

// musicTwoRowItemRenderer: carousels (home, artist albums and singles).
function fromTwoRow(r) {
    const title = text(r.title);
    const runs = r.subtitle?.runs ?? [];
    const thumb = thumbOf(r.thumbnailRenderer);
    const nav = r.navigationEndpoint;
    if (nav?.watchEndpoint?.videoId)
        return song({ videoId: nav.watchEndpoint.videoId, title: title, runs: runs, thumb: thumb });
    const t = pageType(nav);
    if (t === "MUSIC_PAGE_TYPE_ARTIST" || t === "MUSIC_PAGE_TYPE_USER_CHANNEL")
        return artist({ browseId: nav.browseEndpoint.browseId, title: title, thumb: thumb, subs: count(text(r.subtitle)) });
    if (t === "MUSIC_PAGE_TYPE_ALBUM" || t === "MUSIC_PAGE_TYPE_PLAYLIST")
        return album({ browseId: nav.browseEndpoint.browseId, title: title, thumb: thumb, runs: runs,
            kind: t === "MUSIC_PAGE_TYPE_ALBUM" ? "album" : "playlist", subtitle: runs.map(x => x.text).join("") });
    return null;
}

// Every list item of a response, in document order.
function collect(node, ctx, out) {
    out = out ?? [];
    if (Array.isArray(node)) {
        for (const n of node) collect(n, ctx, out);
    } else if (node && typeof node === "object") {
        if (node.musicResponsiveListItemRenderer) {
            const it = fromResponsive(node.musicResponsiveListItemRenderer, ctx);
            if (it) out.push(it);
            return out;
        }
        if (node.musicTwoRowItemRenderer) {
            const it = fromTwoRow(node.musicTwoRowItemRenderer);
            if (it) out.push(it);
            return out;
        }
        for (const k in node) {
            if (k === "header" || k === "frameworkUpdates" || k === "responseContext") continue;
            collect(node[k], ctx, out);
        }
    }
    return out;
}

function find(node, key) {
    if (Array.isArray(node)) {
        for (const n of node) {
            const r = find(n, key);
            if (r) return r;
        }
    } else if (node && typeof node === "object") {
        if (node[key]) return node[key];
        for (const k in node) {
            const r = find(node[k], key);
            if (r) return r;
        }
    }
    return null;
}

function dedupe(items) {
    const seen = {};
    return items.filter(it => {
        const k = it.url;
        if (seen[k]) return false;
        seen[k] = true;
        return true;
    });
}

class MusicPager extends VideoPager {
    constructor(items, more, ctx) {
        super(items, more, ctx);
    }
    nextPage() {
        const c = this.context;
        const r = ytm("browse", {}, "&ctoken=" + encodeURIComponent(c.token) + "&continuation=" + encodeURIComponent(c.token) + "&type=next");
        const items = dedupe(collect(r));
        const token = find(r, "nextContinuationData")?.continuation;
        return new MusicPager(items, !!token, { token: token });
    }
}

source.getHome = function () {
    const r = ytm("browse", { browseId: "FEmusic_home" });
    const items = dedupe(collect(r));
    const token = find(r, "nextContinuationData")?.continuation;
    return new MusicPager(items, !!token, { token: token });
};

source.searchChannels = function (query) {
    const r = ytm("search", { query: query, params: ARTISTS_FILTER });
    return new ChannelPager(collect(r).filter(x => x instanceof PlatformChannel).slice(0, 6), false);
};

source.search = function (query) {
    // Unfiltered search: best match, albums and playlists; filtered by songs: the songs.
    const all = collect(ytm("search", { query: query }));
    const songs = collect(ytm("search", { query: query, params: SONGS_FILTER })).filter(x => x instanceof PlatformVideo);
    const albums = all.filter(x => x instanceof PlatformPlaylist).slice(0, 6);
    return new VideoPager(dedupe(albums.concat(songs)), false);
};

function browseId(url) {
    const m = /\/(channel|browse)\/([^/?#]+)/.exec(url ?? "");
    if (!m) throw new ScriptException("Dirección no reconocida: " + url);
    return m[2];
}

function header(r) {
    const h = find(r, "musicResponsiveHeaderRenderer") ?? find(r, "musicImmersiveHeaderRenderer") ??
        find(r, "musicVisualHeaderRenderer") ?? find(r, "musicDetailHeaderRenderer") ?? {};
    const sub = find(h, "subscriberCountText");
    return {
        title: text(h.title),
        thumb: thumbOf(h.thumbnail?.musicThumbnailRenderer ? h.thumbnail : (h.foregroundThumbnail ?? h.thumbnail)),
        artistRuns: h.straplineTextOne?.runs ?? [],
        subtitle: text(h.subtitle) + (h.secondSubtitle ? " · " + text(h.secondSubtitle) : ""),
        subs: sub ? count(text(sub)) : -1,
        description: text(find(h, "description")?.musicDescriptionShelfRenderer?.description ?? h.description)
    };
}

source.getChannel = function (url) {
    const id = browseId(url);
    const r = ytm("browse", { browseId: id });
    const h = header(r);
    const a = artistLink(h.artistRuns);
    return new PlatformChannel({
        id: pid(id),
        name: h.title + (a.name ? " · " + a.name : ""),
        thumbnail: h.thumb,
        url: url,
        subscribers: h.subs,
        description: h.description
    });
};

source.getChannelContents = function (url) {
    const id = browseId(url);
    const r = ytm("browse", { browseId: id });
    const h = header(r);
    const isList = id.startsWith("MPRE") || id.startsWith("VL") || id.startsWith("OLAK");
    if (isList) {
        const a = artistLink(h.artistRuns);
        const ctx = { thumb: h.thumb, album: id.startsWith("VL") ? "" : h.title, albumUrl: id.startsWith("VL") ? "" : url,
            artist: a.name, artistUrl: a.url };
        const items = collect(r, ctx).filter(x => x instanceof PlatformVideo);
        const token = find(r, "nextContinuationData")?.continuation;
        return new MusicPager(items, !!token, { token: token });
    }
    // Artist: top songs first, then albums, singles and related artists.
    const items = dedupe(collect(r));
    const self = new PlatformAuthorLink(pid(id), h.title, url, null);
    for (const it of items)
        if (!(it instanceof PlatformChannel) && !it.author?.name)
            it.author = self;
    const songs = items.filter(x => x instanceof PlatformVideo);
    const rest = items.filter(x => !(x instanceof PlatformVideo));
    return new VideoPager(songs.concat(rest), false);
};

function videoIdOf(url) {
    const m = /[?&]v=([\w-]{11})/.exec(url ?? "") ?? /^([\w-]{11})$/.exec(url ?? "");
    if (!m) throw new ScriptException("Canción no reconocida: " + url);
    return m[1];
}

// Metadata of a song (no sources: Sanson takes the audio from the YouTube plugin).
source.getContentDetails = function (url) {
    const id = videoIdOf(url);
    const r = ytm("next", { videoId: id, isAudioOnly: true, playlistId: "RDAMVM" + id });
    const panel = find(r, "playlistPanelVideoRenderer");
    let s = null;
    if (panel && panel.videoId === id)
        s = fromPanel(panel);
    if (!s) s = song({ videoId: id, title: "", runs: [] });
    const lyricsTab = (find(r, "tabs") ?? []).map(t => t.tabRenderer).find(t => pageType(t?.endpoint) === "MUSIC_PAGE_TYPE_TRACK_LYRICS");
    return new PlatformVideoDetails(Object.assign({}, s, {
        description: "",
        sansonLyricsId: lyricsTab?.endpoint?.browseEndpoint?.browseId ?? ""
    }));
};

function fromPanel(p) {
    const runs = p.longBylineText?.runs ?? p.shortBylineText?.runs ?? [];
    return song({ videoId: p.videoId, title: text(p.title), runs: runs, thumb: thumbOf(p.thumbnail),
        duration: secs(text(p.lengthText)) });
}

function videoType(p) {
    return p?.navigationEndpoint?.watchEndpoint?.watchEndpointMusicSupportedConfigs?.watchEndpointMusicConfig?.musicVideoType ?? "";
}

// Radio of a song: what YouTube Music would play after it. Started from a music video it would
// bring only videos (other intros, so synced lyrics drift): it starts from the song instead.
source.sansonRadio = function (url) {
    let id = videoIdOf(url);
    let r = ytm("next", { videoId: id, isAudioOnly: true, playlistId: "RDAMVM" + id });
    const seed = find(r, "playlistPanelVideoRenderer");
    if (seed && videoType(seed) !== "MUSIC_VIDEO_TYPE_ATV") {
        const artistName = (seed.longBylineText?.runs ?? seed.shortBylineText?.runs ?? [])[0]?.text ?? "";
        const q = cleanTitle(text(seed.title), artistName) + " " + artistName;
        const hit = collect(ytm("search", { query: q, params: SONGS_FILTER })).find(x => x instanceof PlatformVideo);
        const atv = hit ? videoIdOf(hit.url) : "";
        if (atv && atv !== id) {
            const r2 = ytm("next", { videoId: atv, isAudioOnly: true, playlistId: "RDAMVM" + atv });
            if (find(r2, "playlistPanelVideoRenderer")) {
                r = r2;
                id = atv;
            }
        }
    }
    const out = [];
    const walk = n => {
        if (Array.isArray(n)) n.forEach(walk);
        else if (n && typeof n === "object") {
            if (n.playlistPanelVideoRenderer) {
                if (n.playlistPanelVideoRenderer.videoId && n.playlistPanelVideoRenderer.videoId !== id)
                    out.push(fromPanel(n.playlistPanelVideoRenderer));
                return;
            }
            for (const k in n) walk(n[k]);
        }
    };
    walk(r);
    return new VideoPager(dedupe(out), false);
};

function norm(s) {
    return (s ?? "").toLowerCase()
        .normalize("NFD").replace(/[̀-ͯ]/g, "")
        .replace(/\(.*?\)|\[.*?\]/g, " ")
        .replace(/-\s*(remaster|remasterizado|live|en vivo).*$/i, " ")
        .replace(/[^a-z0-9ñ ]/g, " ").replace(/\s+/g, " ").trim();
}

// "Queen - Bohemian Rhapsody (Official Video Remastered)" -> "Bohemian Rhapsody": music videos
// carry the artist and words like these, which LRCLIB does not have in its titles.
function cleanTitle(title, artistName) {
    let t = (title ?? "").replace(/\s*[\(\[][^\)\]]*(official|oficial|video|v[ií]deo|lyric|letra|audio|visuali[sz]er|hd|4k|remaster)[^\)\]]*[\)\]]/gi, "");
    const a = (artistName ?? "").split(/,| & | y | feat/i)[0].trim();
    if (a) {
        const lead = new RegExp("^\\s*" + a.replace(/[.*+?^${}()|[\]\\]/g, "\\$&") + "\\s*[-–—:|]\\s*", "i");
        t = t.replace(lead, "");
    }
    return t.replace(/\s+/g, " ").trim() || (title ?? "");
}

function parseLrc(lrc) {
    const lines = [];
    for (const l of (lrc ?? "").split("\n")) {
        const stamps = [...l.matchAll(/\[(\d+):(\d+(?:\.\d+)?)\]/g)];
        const t = l.replace(/\[[^\]]*\]/g, "").trim();
        for (const m of stamps)
            lines.push([Math.round((parseInt(m[1], 10) * 60 + parseFloat(m[2])) * 1000), t]);
    }
    return lines.sort((a, b) => a[0] - b[0]);
}

// Synced lyrics of YouTube Music: the app for phones gets them with times (the web only as text).
// They belong to this very song, so the times match the audio that plays.
function ytmTimedLyrics(lyricsId) {
    const resp = http.POST(YTM + "/youtubei/v1/browse?prettyPrint=false",
        JSON.stringify({ context: { client: { clientName: "ANDROID_MUSIC", clientVersion: "7.21.50", hl: "es" } }, browseId: lyricsId }),
        { "Content-Type": "application/json" }, false);
    if (!resp.isOk)
        return null;
    const r = JSON.parse(resp.body);
    const model = find(r.contents, "timedLyricsModel");
    const data = model?.lyricsData?.timedLyricsData ?? [];
    const lines = [];
    for (const l of data) {
        const ms = parseInt(l.cueRange?.startTimeMilliseconds ?? "", 10);
        if (!isNaN(ms)) lines.push([ms, l.lyricLine ?? ""]);
    }
    if (!lines.length)
        return null;
    const src = (model.lyricsData.sourceMessage ?? "").replace(/^(Fuente|Source):\s*/i, "");
    return { synced: lines.sort((a, b) => a[0] - b[0]), source: "YouTube Music" + (src ? " (" + src + ")" : "") };
}

// Lyrics of a song: synced ones of YouTube Music, then LRCLIB (synced when available), then the
// plain ones of YouTube Music. Returns {synced: [[ms, line], ...]} or {plain: "..."}, plus the source.
source.sansonLyrics = function (title, artistName, albumName, duration, lyricsId) {
    if (lyricsId) {
        try {
            const t = ytmTimedLyrics(lyricsId);
            if (t) return t;
        } catch (e) {
            log("YouTube Music timed lyrics: " + e);
        }
    }
    const H = { "User-Agent": "Sanson (https://gitlab.com/AnddyCort/Sanson-FLinux)" };
    const q = s => encodeURIComponent(s ?? "");
    const first = (artistName ?? "").split(/,| & | y | feat/i)[0].trim();
    title = cleanTitle(title, artistName);
    const tries = [];
    if (duration > 0)
        tries.push("https://lrclib.net/api/get?track_name=" + q(title) + "&artist_name=" + q(first) + "&album_name=" + q(albumName) + "&duration=" + Math.round(duration));
    let plainFound = null;
    for (const u of tries) {
        const r = http.GET(u, H, false);
        if (r.isOk) {
            const d = JSON.parse(r.body);
            if (d.syncedLyrics) return { synced: parseLrc(d.syncedLyrics), source: "LRCLIB" };
            if (d.plainLyrics) plainFound = d.plainLyrics;
        }
    }
    const r = http.GET("https://lrclib.net/api/search?track_name=" + q(title) + "&artist_name=" + q(first), H, false);
    if (r.isOk) {
        const list = JSON.parse(r.body) ?? [];
        const nt = norm(title);
        const ok = list.filter(x => norm(x.trackName) === nt || norm(x.trackName).startsWith(nt) || nt.startsWith(norm(x.trackName)));
        const close = x => !(duration > 0) || Math.abs((x.duration ?? 0) - duration) <= 8;
        const best = ok.find(x => x.syncedLyrics && close(x)) ?? ok.find(x => x.syncedLyrics) ?? ok.find(x => x.plainLyrics);
        if (best?.syncedLyrics) return { synced: parseLrc(best.syncedLyrics), source: "LRCLIB" };
        if (best?.plainLyrics && !plainFound) plainFound = best.plainLyrics;
    }
    if (plainFound) return { plain: plainFound, source: "LRCLIB" };
    if (lyricsId) {
        const b = ytm("browse", { browseId: lyricsId });
        const shelf = find(b, "musicDescriptionShelfRenderer");
        if (shelf?.description) return { plain: text(shelf.description), source: text(shelf.footer) || "YouTube Music" };
    }
    return { none: true };
};

// SoundCloud: client_id comes from the site's scripts (the same the web player uses).
let scClientId = null;
function scClient() {
    if (scClientId) return scClientId;
    const home = http.GET("https://soundcloud.com/", { "User-Agent": UA }, false);
    const scripts = [...(home.body ?? "").matchAll(/https:\/\/a-v2\.sndcdn\.com\/assets\/[^"]+\.js/g)].map(m => m[0]).reverse();
    for (const s of scripts) {
        const js = http.GET(s, { "User-Agent": UA }, false).body ?? "";
        const m = /client_id\s*:\s*"([A-Za-z0-9]{32})"/.exec(js);
        if (m) return (scClientId = m[1]);
    }
    throw new ScriptException("SoundCloud no disponible");
}

// Fallback when YouTube gives no audio: the same song on SoundCloud (full, not a preview).
// Returns {url: m3u8 (AAC fMP4), title, user} or {none: true}.
source.sansonFallback = function (title, artistName, duration) {
    const cid = scClient();
    const query = encodeURIComponent(((artistName ?? "").split(",")[0] + " " + title).trim());
    const r = http.GET("https://api-v2.soundcloud.com/search/tracks?q=" + query + "&limit=20&client_id=" + cid, { "User-Agent": UA }, false);
    if (!r.isOk) {
        scClientId = null;
        return { none: true };
    }
    const nt = norm(title), na = norm((artistName ?? "").split(",")[0]);
    const cands = (JSON.parse(r.body).collection ?? []).filter(t => {
        if (t.policy === "SNIP" || t.policy === "BLOCK") return false;
        const tc = (t.media?.transcodings ?? []).find(x => x.format?.protocol === "hls" && !x.snipped);
        if (!tc) return false;
        const tt = norm(t.title);
        if (!tt.includes(nt)) return false;
        const d = (t.full_duration ?? t.duration ?? 0) / 1000;
        return !(duration > 0) || Math.abs(d - duration) <= 15;
    });
    cands.sort((a, b) => {
        const sa = (norm(a.title + " " + a.user?.username).includes(na) ? 0 : 1);
        const sb = (norm(b.title + " " + b.user?.username).includes(na) ? 0 : 1);
        return sa - sb;
    });
    for (const t of cands) {
        const tcs = (t.media.transcodings ?? []).filter(x => x.format?.protocol === "hls" && !x.snipped);
        // AAC first (the MP3 HLS one answers 404 to anonymous clients).
        tcs.sort((a, b) => (a.format.mime_type.includes("mp4") ? 0 : 1) - (b.format.mime_type.includes("mp4") ? 0 : 1));
        for (const tc of tcs) {
            const s = http.GET(tc.url + "?client_id=" + cid + "&track_authorization=" + encodeURIComponent(t.track_authorization ?? ""),
                { "User-Agent": UA, "Origin": "https://soundcloud.com", "Referer": "https://soundcloud.com/" }, false);
            if (!s.isOk) continue;
            const u = JSON.parse(s.body).url;
            if (u) return { url: u, title: t.title, user: t.user?.username ?? "" };
        }
    }
    return { none: true };
};
