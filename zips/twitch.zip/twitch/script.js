// Sanson: Twitch straight to Twitch's GQL API, usher (HLS) and the chat's IRC.
// GPL-3.0-or-later.

const PLATFORM = "Twitch";
const TW = "https://www.twitch.tv";
// The web client: its id is the one the auth-token cookie of twitch.tv belongs to.
const CLIENT_ID = "kimne78kx3ncx6brgo4mv6wki5h1ko";
const PAGE = 30;

const STREAM = "stream{id title viewersCount createdAt previewImageURL(width:320,height:180) game{displayName}}";
const USER = "id login displayName profileImageURL(width:150) followers{totalCount}";
const VIDEO = "id title lengthSeconds viewCount createdAt publishedAt previewThumbnailURL(width:320,height:180) broadcastType " +
    "owner{id login displayName profileImageURL(width:70)} game{displayName}";

source.enable = function () {
};

function logged() {
    return bridge.isLoggedIn();
}

function gql(query, variables, auth) {
    const d = sansonJson("POST", "https://gql.twitch.tv/gql", JSON.stringify({ query, variables: variables ?? {} }),
        { "Client-Id": CLIENT_ID, "Content-Type": "application/json", "Origin": TW, "Referer": TW + "/" }, !!auth, "Twitch");
    if (d.errors && !d.data)
        throw new ScriptException("Twitch: " + (d.errors[0]?.message ?? "error"));
    return d.data ?? {};
}

// --- urls ----------------------------------------------------------------------------------

function vodIdOf(url) {
    const m = /twitch\.tv\/(?:videos|[\w-]+\/video)\/(\d+)/.exec(url ?? "");
    return m ? m[1] : null;
}

function loginOf(url) {
    const m = /twitch\.tv\/([\w-]+)/.exec(url ?? "");
    if (!m || ["videos", "directory", "search"].includes(m[1]))
        throw new UnavailableException("No se reconoce el canal: " + url);
    return m[1].toLowerCase();
}

// --- items -----------------------------------------------------------------------------------

function author(u) {
    return sansonAuthor(PLATFORM, u?.id, u?.displayName ?? u?.login, TW + "/" + (u?.login ?? ""), u?.profileImageURL);
}

function liveItem(u, s) {
    return new PlatformVideo({
        id: sansonPid(PLATFORM, s.id),
        name: s.title || (u.displayName ?? u.login),
        thumbnails: sansonThumbs(s.previewImageURL),
        author: author(u),
        uploadDate: sansonIso(s.createdAt),
        duration: 0,
        viewCount: s.viewersCount ?? -1,
        url: TW + "/" + u.login,
        isLive: true,
        sansonGame: s.game?.displayName ?? ""
    });
}

function vodItem(v, owner) {
    const o = v.owner ?? owner;
    return new PlatformVideo({
        id: sansonPid(PLATFORM, v.id),
        name: v.title ?? "",
        thumbnails: sansonThumbs(v.previewThumbnailURL),
        author: author(o),
        uploadDate: sansonIso(v.publishedAt ?? v.createdAt),
        duration: v.lengthSeconds ?? 0,
        viewCount: v.viewCount ?? -1,
        url: TW + "/videos/" + v.id,
        isLive: false
    });
}

function channelItem(u) {
    return new PlatformChannel({
        id: sansonPid(PLATFORM, u.id),
        name: u.displayName ?? u.login,
        thumbnail: u.profileImageURL ?? "",
        subscribers: u.followers?.totalCount ?? -1,
        description: u.description ?? "",
        banner: u.bannerImageURL ?? "",
        url: TW + "/" + u.login
    });
}

// --- home, search, channels ---------------------------------------------------------------------

source.getHome = function () {
    const fetch = ctx => {
        const d = gql("query($n:Int,$a:Cursor){streams(first:$n,after:$a){edges{cursor node{" +
            "id title viewersCount createdAt previewImageURL(width:320,height:180) game{displayName} " +
            "broadcaster{id login displayName profileImageURL(width:70)}}} pageInfo{hasNextPage}}}", { n: PAGE, a: ctx.after });
        const edges = d.streams?.edges ?? [];
        const results = edges.filter(e => e.node?.broadcaster).map(e => liveItem(e.node.broadcaster, e.node));
        return { results, more: !!d.streams?.pageInfo?.hasNextPage, context: { after: edges.length ? edges[edges.length - 1].cursor : null } };
    };
    return new SansonPager(fetch, { after: null });
};

function searchFor(query) {
    return gql("query($q:String!){searchFor(userQuery:$q,platform:\"web\",options:{targets:[{index:CHANNEL},{index:VOD}]}){" +
        "channels{edges{item{...on User{" + USER + " " + STREAM + "}}}} videos{edges{item{...on Video{" + VIDEO + "}}}}}}", { q: query }).searchFor ?? {};
}

// Channels first; the ones live now also as their stream.
source.search = function (query) {
    const r = searchFor(query);
    const users = (r.channels?.edges ?? []).map(e => e.item).filter(u => u?.login);
    const lives = users.filter(u => u.stream).map(u => liveItem(u, u.stream));
    const vods = (r.videos?.edges ?? []).map(e => e.item).filter(v => v?.id).map(v => vodItem(v));
    return new VideoPager([...users.slice(0, 4).map(channelItem), ...lives, ...vods], false, {});
};

source.searchChannels = function (query) {
    const r = searchFor(query);
    return new SansonChannelPager((r.channels?.edges ?? []).map(e => e.item).filter(u => u?.login).map(channelItem));
};

function user(login) {
    const d = gql("query($l:String!){user(login:$l){" + USER + " description bannerImageURL " + STREAM + "}}", { l: login });
    if (!d.user)
        throw new UnavailableException("El canal no existe: " + login);
    return d.user;
}

source.getChannel = function (url) {
    return channelItem(user(loginOf(url)));
};

// The stream (if live) and then the past broadcasts, newest first.
source.getChannelContents = function (url) {
    const login = loginOf(url);
    const fetch = ctx => {
        const d = gql("query($l:String!,$n:Int,$a:Cursor){user(login:$l){" + USER + " " + STREAM +
            " videos(first:$n,after:$a,sort:TIME){edges{cursor node{" + VIDEO + "}} pageInfo{hasNextPage}}}}", { l: login, n: PAGE, a: ctx.after });
        const u = d.user;
        if (!u)
            throw new UnavailableException("El canal no existe: " + login);
        const edges = u.videos?.edges ?? [];
        const results = edges.map(e => vodItem(e.node, u));
        if (!ctx.after && u.stream)
            results.unshift(liveItem(u, u.stream));
        return { results, more: !!u.videos?.pageInfo?.hasNextPage, context: { after: edges.length ? edges[edges.length - 1].cursor : null } };
    };
    return new SansonPager(fetch, { after: null });
};

// --- video ---------------------------------------------------------------------------------------

const TOKEN_PARAMS = "params:{platform:\"web\",playerBackend:\"mediaplayer\",playerType:\"site\"}";

function usher(path, tok) {
    const q = {
        acmb: "e30=", allow_source: "true", fast_bread: "true", p: String(Math.floor(Math.random() * 9000000) + 1000000),
        player_backend: "mediaplayer", playlist_include_framerate: "true", reassignments_supported: "true",
        sig: tok.signature, supported_codecs: "h264", token: tok.value, transcode_mode: "cbr_v1", cdm: "wv"
    };
    return "https://usher.ttvnw.net/" + path + "?" + Object.keys(q).map(k => k + "=" + encodeURIComponent(q[k])).join("&");
}

function forbidden(tok) {
    try {
        const v = JSON.parse(tok.value);
        if (v?.authorization?.forbidden)
            return v.authorization.reason || "No disponible";
        if (v?.chansub?.restricted_bitrates?.length && !v?.chansub?.view_until)
            return null;
    } catch (e) {
    }
    return null;
}

source.getContentDetails = function (url) {
    const vod = vodIdOf(url);
    if (vod) {
        const d = gql("query($id:ID!){video(id:$id){" + VIDEO + " description " +
            "} videoPlaybackAccessToken(id:$id," + TOKEN_PARAMS + "){value signature}}", { id: vod }, logged());
        const v = d.video;
        const tok = d.videoPlaybackAccessToken;
        if (!v || !tok)
            throw new UnavailableException("La grabación no existe o es solo para suscriptores.");
        const why = forbidden(tok);
        if (why)
            throw new UnavailableException(why);
        const item = vodItem(v);
        return new PlatformVideoDetails(Object.assign({}, item, {
            description: v.description ?? "",
            video: new VideoSourceDescriptor([new HLSSource({ name: "source", url: usher("vod/" + vod + ".m3u8", tok), duration: v.lengthSeconds ?? 0 })]),
            sansonRelated: others(v.owner?.login, url)
        }));
    }
    const login = loginOf(url);
    const d = gql("query($l:String!){user(login:$l){" + USER + " description " + STREAM + "} streamPlaybackAccessToken(channelName:$l," +
        TOKEN_PARAMS + "){value signature}}", { l: login }, logged());
    const u = d.user;
    if (!u)
        throw new UnavailableException("El canal no existe: " + login);
    if (!u.stream)
        throw new UnavailableException(u.displayName + " no está en vivo ahora.");
    const tok = d.streamPlaybackAccessToken;
    if (!tok)
        throw new ScriptException("Twitch no entregó el directo");
    const why = forbidden(tok);
    if (why)
        throw new UnavailableException(why);
    const item = liveItem(u, u.stream);
    return new PlatformVideoDetails(Object.assign({}, item, {
        description: (u.stream.game?.displayName ? "Jugando: " + u.stream.game.displayName + "\n\n" : "") + (u.description ?? ""),
        video: new VideoSourceDescriptor([]),
        live: new HLSSource({ name: "live", url: usher("api/channel/hls/" + login + ".m3u8", tok), duration: 0 }),
        sansonRelated: sameGame(u.stream.game?.displayName, url)
    }));
};

// After a past broadcast: the channel's other ones, oldest after it first.
function others(login, url) {
    if (!login)
        return [];
    try {
        const d = gql("query($l:String!){user(login:$l){" + USER + " videos(first:20,sort:TIME){edges{node{" + VIDEO + "}}}}}", { l: login });
        const list = (d.user?.videos?.edges ?? []).map(e => vodItem(e.node, d.user));
        const i = list.findIndex(v => v.url === url);
        return i >= 0 ? [...list.slice(i + 1), ...list.slice(0, i)] : list;
    } catch (e) {
        log("others: " + e);
        return [];
    }
}

// After a live stream: other streams of the same game.
function sameGame(game, url) {
    if (!game)
        return [];
    try {
        const d = gql("query($g:String!){game(name:$g){streams(first:20){edges{node{id title viewersCount createdAt " +
            "previewImageURL(width:320,height:180) broadcaster{id login displayName profileImageURL(width:70)}}}}}}", { g: game });
        return (d.game?.streams?.edges ?? []).filter(e => e.node?.broadcaster).map(e => liveItem(e.node.broadcaster, e.node))
            .filter(v => v.url !== url);
    } catch (e) {
        log("same game: " + e);
        return [];
    }
}

source.getContentRecommendations = function (url) {
    const vod = vodIdOf(url);
    if (vod) {
        const d = gql("query($id:ID!){video(id:$id){owner{login}}}", { id: vod });
        return new VideoPager(others(d.video?.owner?.login, url), false, {});
    }
    const u = user(loginOf(url));
    return new VideoPager(sameGame(u.stream?.game?.displayName, url), false, {});
};

// --- account ---------------------------------------------------------------------------------------

source.sansonFollowing = function () {
    if (!logged())
        return new SansonChannelPager([]);
    let all = [], after = null;
    for (let i = 0; i < 10; i++) {
        const d = gql("query($a:Cursor){currentUser{follows(first:100,after:$a){edges{cursor node{" + USER + "}} pageInfo{hasNextPage}}}}", { a: after }, true);
        const f = d.currentUser?.follows;
        const edges = f?.edges ?? [];
        all = all.concat(edges.map(e => e.node).filter(Boolean).map(channelItem));
        if (!f?.pageInfo?.hasNextPage || !edges.length)
            break;
        after = edges[edges.length - 1].cursor;
    }
    return new SansonChannelPager(all);
};

// Who is live now among the channels followed (the account's and the ones followed in Sanson).
source.sansonFeed = function (urls) {
    const live = [];
    const seen = new Set();
    const add = (u) => {
        if (u?.stream && !seen.has(u.login)) {
            seen.add(u.login);
            live.push(liveItem(u, u.stream));
        }
    };
    if (logged()) {
        try {
            const d = gql("query{currentUser{followedLiveUsers(first:100){nodes{" + USER + " " + STREAM + "}}}}", {}, true);
            for (const u of d.currentUser?.followedLiveUsers?.nodes ?? [])
                add(u);
        } catch (e) {
            log("followed live: " + e);
        }
    }
    const logins = [];
    for (const u of urls ?? []) {
        try {
            logins.push(loginOf(u));
        } catch (e) {
        }
    }
    for (let i = 0; i < logins.length; i += 100) {
        const d = gql("query($ls:[String!]){users(logins:$ls){" + USER + " " + STREAM + "}}", { ls: logins.slice(i, i + 100) });
        for (const u of d.users ?? [])
            add(u);
    }
    live.sort((a, b) => b.viewCount - a.viewCount);
    return new VideoPager(live, false, {});
};

// --- chat ----------------------------------------------------------------------------------
// Live: Twitch's IRC over WebSocket as an anonymous viewer (justinfanNNNN), with the viewers
// read again every half minute. Replays: the comments of the video by time, from GQL.

const EMOTE = id => "https://static-cdn.jtvnw.net/emoticons/v2/" + id + "/default/dark/1.0";

// IRC tag values escape ';', ' ' and '\'.
function ircTag(tags, name) {
    const m = new RegExp("(?:^|;)" + name + "=([^;]*)").exec(tags);
    return m ? m[1].replace(/\\s/g, " ").replace(/\\:/g, ";").replace(/\\\\/g, "\\") : "";
}

// "emotes=25:0-4,6-10/1902:12-16" applied to the text: each emote becomes __e<id>__.
function ircText(text, emotes, found) {
    if (!emotes)
        return text;
    const ranges = [];
    for (const part of emotes.split("/")) {
        const [id, list] = part.split(":");
        for (const r of (list ?? "").split(",")) {
            const [a, b] = r.split("-").map(Number);
            if (!isNaN(a) && !isNaN(b))
                ranges.push({ id, a, b });
        }
    }
    ranges.sort((x, y) => x.a - y.a);
    // The positions count characters, not UTF-16 units.
    const chars = Array.from(text);
    let out = "", at = 0;
    for (const r of ranges) {
        out += chars.slice(at, r.a).join("") + " __e" + r.id + "__ ";
        found["e" + r.id] = EMOTE(r.id);
        at = r.b + 1;
    }
    return (out + chars.slice(at).join("")).trim();
}

class TwitchChatPager extends LiveEventPager {
    constructor(login) {
        super([], true);
        const me = this;
        this.login = login;
        this.events = [];
        this.emojis = {};
        this.viewersAt = 0;
        this.nextRequest = 1500;
        const nick = "justinfan" + Math.floor(1000 + Math.random() * 89999);
        const irc = http.socket("wss://irc-ws.chat.twitch.tv", {}, false);
        this.irc = irc;
        irc.connect({
            open() {
                irc.send("CAP REQ :twitch.tv/tags twitch.tv/commands");
                irc.send("PASS SCHMOOPIIE");
                irc.send("NICK " + nick);
                irc.send("JOIN #" + login);
            },
            message(line) {
                if (line.startsWith("PING")) {
                    irc.send("PONG" + line.slice(4));
                    return;
                }
                const m = /^@(\S+) :[^ ]+ (PRIVMSG|USERNOTICE) #\S+(?: :(.*))?$/.exec(line);
                if (!m)
                    return;
                const tags = m[1], text = m[3] ?? "";
                const name = ircTag(tags, "display-name") || ircTag(tags, "login");
                if (m[2] === "USERNOTICE") {
                    const sys = ircTag(tags, "system-msg");
                    if (sys)
                        me.events.push(new LiveEventDonation(ircTag(tags, "msg-id") === "raid" ? "Raid" : "Suscripción",
                            name, sys + (text ? " · " + text : ""), "", 0, null));
                    return;
                }
                const bits = ircTag(tags, "bits");
                const msg = ircText(text, ircTag(tags, "emotes"), me.emojis);
                if (bits)
                    me.events.push(new LiveEventDonation(bits + " bits", name, msg, "", 0, null));
                else
                    me.events.push(new LiveEventComment(name, msg, "", ircTag(tags, "color") || null, []));
            },
            closed() {
                me.hasMore = false;
            }
        });
        this.results = [];
    }
    nextPage() {
        const out = [];
        if (Object.keys(this.emojis).length) {
            out.push(new LiveEventEmojis(this.emojis));
            this.emojis = {};
        }
        if (Date.now() - this.viewersAt > 30000) {
            this.viewersAt = Date.now();
            try {
                const n = gql("query($l:String!){user(login:$l){stream{viewersCount}}}", { l: this.login }).user?.stream?.viewersCount;
                if (n != null)
                    out.push(new LiveEventViewCount(n));
            } catch (e) {
                log("viewers: " + e);
            }
        }
        this.results = out.concat(this.events);
        this.events = [];
        if (!this.irc.isOpen)
            this.hasMore = false;
        return this;
    }
}

source.getLiveEvents = function (url) {
    return new TwitchChatPager(loginOf(url));
};

// Twitch gives the comments from a second of the video on (a page; on busy chats only a few
// seconds). The pager keeps what it read and asks for more as the video advances.
class TwitchReplayPager extends LiveEventPager {
    constructor(id) {
        super([], true);
        this.id = id;
        this.nextRequest = 1000;
        this.cache = [];
        this.from = -1;
        this.to = -1;
    }
    nextPage(ms) {
        const at = ms ?? 0;
        if (this.from < 0 || at < this.from || at > this.to + 1000) {
            this.cache = [];
            this.from = at;
            this.to = at - 1;
        }
        for (let i = 0; i < 3 && this.to < at + 5000; i++)
            this.fetch(Math.floor((this.to + 1) / 1000));
        this.cache = this.cache.filter(e => e.time >= at - 1000);
        const found = {};
        const events = this.cache.map(e => {
            const c = new LiveEventComment(e.name, e.text, "", e.color, []);
            c.time = e.time;
            Object.assign(found, e.emotes);
            return c;
        });
        this.results = Object.keys(found).length ? [new LiveEventEmojis(found), ...events] : events;
        return this;
    }
    fetch(secs) {
        const d = gql("query($id:ID!,$o:Int){video(id:$id){comments(contentOffsetSeconds:$o){edges{node{id contentOffsetSeconds " +
            "commenter{displayName login} message{fragments{text emote{emoteID}} userColor}}}}}}", { id: this.id, o: secs });
        const edges = d.video?.comments?.edges ?? [];
        let last = -1;
        for (const e of edges) {
            const n = e.node;
            if (!n)
                continue;
            const t = (n.contentOffsetSeconds ?? 0) * 1000;
            last = Math.max(last, t);
            if (this.cache.some(c => c.id === n.id))
                continue;
            const emotes = {};
            const text = (n.message?.fragments ?? []).map(f => {
                if (!f.emote?.emoteID)
                    return f.text ?? "";
                emotes["e" + f.emote.emoteID] = EMOTE(f.emote.emoteID);
                return " __e" + f.emote.emoteID + "__ ";
            }).join("").trim();
            if (text)
                this.cache.push({ id: n.id, time: t, name: n.commenter?.displayName ?? n.commenter?.login ?? "", text,
                                  color: n.message?.userColor ?? null, emotes });
        }
        // An empty page (a quiet stretch): no comments for half a minute.
        this.to = Math.max(this.to + 1000, last >= secs * 1000 ? last + 999 : secs * 1000 + 30000);
        this.cache.sort((a, b) => a.time - b.time);
    }
}

source.getVODEvents = function (url) {
    const id = vodIdOf(url);
    if (!id)
        throw new UnavailableException("No es un video de Twitch");
    return new TwitchReplayPager(id);
};
