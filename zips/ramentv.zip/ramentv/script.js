// RamenTV plugin para Sanson — Feed, tendencias, paginación y comentarios
const PLATFORM = "RamenTV";
const _0x5f = "https://jkanime.net";
const LOGIN_BASE = "https://login.jkanime.net";
const UA = "Mozilla/5.0 (X11; Linux x86_64; rv:133.0) Gecko/20100101 Firefox/133.0";
let session = null;

source.enable = function () {};

function safeTrace(msg) {
    if (typeof trace === "function") {
        trace(msg);
    } else if (typeof log === "function") {
        log(msg);
    }
}

function isOkResp(resp) {
    if (!resp) return false;
    if (typeof resp.isOk === "boolean") return resp.isOk;
    return resp.code === 200;
}

function decodeHtmlEntities(str) {
    if (!str) return "";
    return String(str)
        .replace(/&amp;/g, "&")
        .replace(/&quot;/g, '"')
        .replace(/&#039;/g, "'")
        .replace(/&lt;/g, "<")
        .replace(/&gt;/g, ">")
        .replace(/\s+/g, " ")
        .trim();
}

function initSession() {
    const resp = http.GET(_0x5f + "/", {
        "User-Agent": UA,
        "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8"
    }, false);
    if (!isOkResp(resp)) throw new CaptchaRequiredException(_0x5f + "/", "");

    const csrfMatch = /name="csrf-token" content="([^"]+)"/.exec(resp.body || "");
    if (!csrfMatch) throw new ScriptException("No se pudo obtener CSRF");

    let setCookies = resp.headers ? resp.headers["set-cookie"] : [];
    if (!Array.isArray(setCookies)) setCookies = setCookies ? [setCookies] : [];
    let cookieHeader = "";
    for (const c of setCookies) {
        const kv = String(c).split(";")[0].trim();
        if (kv.includes("=")) cookieHeader += (cookieHeader ? "; " : "") + kv;
    }
    session = { csrf: csrfMatch[1], cookies: cookieHeader, home: resp.body || "" };
    return session;
}

function getSession() {
    if (!session) initSession();
    return session;
}

function animeItem(id, title, url, thumb, type, status) {
    return new PlatformChannel({
        id: sansonPid(PLATFORM, String(id || url)),
        name: title || "",
        thumbnail: thumb || "",
        url: url,
        description: (type || "") + (status ? (type ? " · " : "") + status : ""),
        subscribers: -1
    });
}

function parseRelativeDateToUnix(label) {
    const nowSec = Math.floor(Date.now() / 1000);
    const clean = decodeHtmlEntities(label || "").toLowerCase();
    if (!clean) return nowSec;

    if (clean.includes("hoy")) {
        return nowSec;
    }
    if (clean.includes("ayer")) {
        return nowSec - 86400;
    }

    const dayMatch = /(\d{1,2})\s*$/.exec(clean);
    if (dayMatch) {
        const targetDay = parseInt(dayMatch[1], 10);
        const d = new Date();
        const curDay = d.getDate();
        let diffDays = curDay - targetDay;
        if (diffDays < 0) {
            diffDays += 30;
        }
        return nowSec - diffDays * 86400;
    }

    return nowSec;
}

function episodeItem(slug, num, title, thumb, datetimeSec) {
    const finalThumb = thumb || ("https://cdn.jkdesa.com/assets/images/animes/image/" + slug + ".jpg");
    return new PlatformVideo({
        id: sansonPid(PLATFORM, slug + "-" + num),
        name: title || ("Episodio " + num),
        thumbnails: sansonThumbs(finalThumb),
        author: sansonAuthor(PLATFORM, "", "RamenTV", _0x5f, null),
        duration: 0,
        viewCount: -1,
        datetime: datetimeSec || Math.floor(Date.now() / 1000),
        url: _0x5f + "/" + slug + "/" + num + "/",
        isLive: false
    });
}

function parseProgramacionEpisodes(html) {
    if (!html) return [];
    const tabMatch = /<div class="tab-pane[^"]*" id="animes"[^>]*>([\s\S]*?)<\/div>\s*<div class="tab-pane/i.exec(html);
    const scope = tabMatch ? tabMatch[1] : html;
    const episodes = [];
    const seen = new Set();

    const cardRe = /<div class="card[^"]*">([\s\S]*?)<\/a>\s*<\/div>/gi;
    let cm;
    while ((cm = cardRe.exec(scope)) !== null) {
        const card = cm[1];
        const hrefMatch = /<a\s+href="(https:\/\/jkanime\.net\/([\w-]+)\/(\d+)\/?)"/i.exec(card);
        if (!hrefMatch) continue;

        const slug = hrefMatch[2];
        const num = hrefMatch[3];
        const key = slug + "-" + num;
        if (seen.has(key)) continue;
        seen.add(key);

        const titleMatch = /<h5[^>]*class="[^"]*card-title[^"]*"[^>]*>([\s\S]*?)<\/h5>/i.exec(card);
        const epMatch = /<span[^>]*class="[^"]*badge-primary[^"]*"[^>]*>([\s\S]*?)<\/span>/i.exec(card);
        const timeMatch = /<span[^>]*class="[^"]*badge-secondary[^"]*"[^>]*>([\s\S]*?)<\/span>/i.exec(card);
        const imgMatch = /<img[^>]+src="([^"]+)"/i.exec(card);

        const animeTitle = titleMatch ? decodeHtmlEntities(titleMatch[1].replace(/<[^>]+>/g, "")) : slug;
        const epBadge = epMatch ? decodeHtmlEntities(epMatch[1].replace(/<[^>]+>/g, "")) : ("Ep " + num);
        const timeLabel = timeMatch ? decodeHtmlEntities(timeMatch[1].replace(/<[^>]+>/g, "")) : "";
        const thumb = imgMatch ? decodeHtmlEntities(imgMatch[1]) : ("https://cdn.jkdesa.com/assets/images/animes/image/" + slug + ".jpg");
        const dtUnix = parseRelativeDateToUnix(timeLabel);

        episodes.push(episodeItem(slug, num, animeTitle + " - " + epBadge, thumb, dtUnix));
    }
    return episodes;
}

function parseTendenciasChannels(html) {
    if (!html) return [];
    const items = [];
    const seen = new Set();

    const topMatch = /<div class="row upto[\s\S]*?<\/div>\s*<\/div>\s*<\/div>/i.exec(html);
    const scope = topMatch ? topMatch[0] : html;

    const re = /<a href="(https:\/\/jkanime\.net\/([\w-]+)\/)"[^>]*>[\s\S]*?<h5[^>]*class="[^"]*card-title[^"]*"[^>]*>([\s\S]*?)<\/h5>/gi;
    let m;
    while ((m = re.exec(scope)) !== null) {
        const url = m[1];
        const slug = m[2];
        const title = decodeHtmlEntities(m[3].replace(/<[^>]+>/g, ""));
        if (!title || seen.has(url)) continue;
        seen.add(url);

        const thumb = "https://cdn.jkdesa.com/assets/images/animes/image/" + slug + ".jpg";
        items.push(animeItem(slug, title, url, thumb, "Top", ""));
    }
    return items.slice(0, 20);
}

// Feed / Tendencias: si el host pasa URLs de canales, obtiene episodios de esos canales;
// si no pasa URLs o falla, devuelve los episodios de programación en emisión.
source.sansonFeed = function (urls) {
    try {
        const s = getSession();
        if (Array.isArray(urls) && urls.length > 0 && typeof source.getChannelContents === "function") {
            const collected = [];
            const seenUrls = new Set();
            const limit = Math.min(urls.length, 10);

            for (let i = 0; i < limit; i++) {
                const chanUrl = urls[i];
                if (!chanUrl) continue;
                try {
                    const pager = source.getChannelContents(chanUrl);
                    const list = pager && Array.isArray(pager.results) ? pager.results : [];
                    for (let j = list.length - 1; j >= 0 && collected.length < 40; j--) {
                        const ep = list[j];
                        if (ep && ep.url && !seenUrls.has(ep.url)) {
                            seenUrls.add(ep.url);
                            collected.push(ep);
                        }
                    }
                } catch (e) {
                    safeTrace("Error en canal de feed (" + chanUrl + "): " + e);
                }
            }
            if (collected.length > 0) {
                return new VideoPager(collected, false, {});
            }
        }

        const episodes = parseProgramacionEpisodes(s.home);
        return new VideoPager(episodes, false, {});
    } catch (e) {
        safeTrace("Error en sansonFeed: " + e);
        return new VideoPager([], false, {});
    }
};

source.sansonComments = function (url, token) {
    try {
        const s = getSession();
        const page = token ? (parseInt(token, 10) || 1) : 1;
        const apiUrl = `${LOGIN_BASE}/api/comentarios?url=${encodeURIComponent(url || "")}&page=${page}`;
        const resp = http.GET(apiUrl, {
            "User-Agent": UA,
            "Referer": _0x5f + "/",
            "Accept": "application/json, text/plain, */*",
            "Cookie": s.cookies
        }, false);

        if (!isOkResp(resp) || !resp.body) {
            return { comments: [], next: "", disabled: true };
        }

        const trimmed = String(resp.body).trim();
        if (!trimmed.startsWith("{") && !trimmed.startsWith("[")) {
            return { comments: [], next: "", disabled: true };
        }

        const data = JSON.parse(trimmed);
        const rawList = Array.isArray(data) ? data : (Array.isArray(data?.comments) ? data.comments : (Array.isArray(data?.data) ? data.data : []));
        const comments = [];

        for (let i = 0; i < rawList.length; i++) {
            const c = rawList[i] || {};
            comments.push({
                author: decodeHtmlEntities(c.author || c.user || c.username || "Anónimo"),
                text: decodeHtmlEntities(c.text || c.comment || c.body || ""),
                when: String(c.when || c.date || c.created_at || ""),
                likes: c.likes != null ? String(c.likes) : "",
                replies: c.replies != null ? String(c.replies) : ""
            });
        }

        return {
            comments: comments,
            next: comments.length > 0 && data?.has_more ? String(page + 1) : "",
            count: data?.total != null ? String(data.total) : String(comments.length)
        };
    } catch (e) {
        safeTrace("Comentarios no disponibles en RamenTV: " + e);
        return { comments: [], next: "", disabled: true };
    }
};

source.getHome = function () {
    const s = getSession();
    const html = s.home;
    const items = [];
    const seen = new Set();
    const re = /<a href="(https:\/\/jkanime\.net\/[^\/]+\/)"[^>]*>[\s\S]*?<img[^>]* src="([^"]+)"[^>]*>[\s\S]*?<h[^>]*>([^<]+)<\/h/g;
    let m;
    while ((m = re.exec(html)) !== null) {
        const url = m[1], title = decodeHtmlEntities(m[3]);
        if (!title || url.includes("/buscar/") || seen.has(url)) continue;
        seen.add(url);
        const slugMatch = /\/([\w-]+)\/?$/.exec(url);
        const slug = slugMatch ? slugMatch[1] : url;
        const highResThumb = "https://cdn.jkdesa.com/assets/images/animes/image/" + slug + ".jpg";
        items.push(animeItem(slug, title, url, highResThumb, "", ""));
    }
    return new VideoPager(items.slice(0, 60), false, {});
};

source.search = function (query) {
    const s = getSession();
    const body = "_token=" + encodeURIComponent(s.csrf) + "&q=" + encodeURIComponent(query);
    const resp = sansonRequest("POST", _0x5f + "/ajax_search", body, {
        "User-Agent": UA, "Content-Type": "application/x-www-form-urlencoded; charset=UTF-8",
        "X-Requested-With": "XMLHttpRequest", "Referer": _0x5f + "/buscar/" + encodeURIComponent(query),
        "Origin": _0x5f, "Cookie": s.cookies
    }, false, PLATFORM);
    const results = JSON.parse(resp);
    const items = [];
    const arr = Array.isArray(results) ? results : (results.data ? results.data : []);
    for (let i = 0; i < arr.length; i++) {
        const r = arr[i];
        const highResThumb = "https://cdn.jkdesa.com/assets/images/animes/image/" + r.slug + ".jpg";
        items.push(animeItem(r.id, r.title, _0x5f + "/" + r.slug + "/", highResThumb, r.type, r.status));
    }
    return new VideoPager(items, false, {});
};

source.getChannel = function (url) {
    const s = getSession();
    const resp = http.GET(url, { "User-Agent": UA, "Referer": _0x5f + "/", "Cookie": s.cookies }, false);
    const html = resp.body;
    const title = (/<h1[^>]*>([^<]+)<\/h1>/.exec(html) || [])[1] || "Anime";
    const thumb = (/<meta property="og:image" content="([^"]+)"/.exec(html) || [])[1] || "";
    const desc = (/<meta name="description" content="([^"]+)"/.exec(html) || [])[1] || "";
    const slugMatch = /\/([\w-]+)\/?$/.exec(url);
    const slug = slugMatch ? slugMatch[1] : url;
    return new PlatformChannel({
        id: sansonPid(PLATFORM, slug), name: title.trim(), thumbnail: thumb,
        url: url, description: desc, subscribers: -1
    });
};

source.getChannelContents = function (url) {
    const s = getSession();
    const html = http.GET(url, { "User-Agent": UA, "Referer": _0x5f + "/", "Cookie": s.cookies }, false).body;
    const slugMatch = /jkanime\.net\/([\w-]+)\/?/.exec(url);
    const slug = slugMatch ? slugMatch[1] : "";
    if (!slug) return new VideoPager([], false, {});

    const items = [];
    const seen = new Set();

    let animeId = null;
    let m = /data-anime=["'](\d+)["']/.exec(html);
    if (m) animeId = m[1];
    else {
        m = /var\s+anime_id\s*=\s*["']?(\d+)["']?/i.exec(html);
        if (m) animeId = m[1];
        else {
            m = /data-id=["'](\d+)["']/.exec(html);
            if (m) animeId = m[1];
        }
    }

    if (animeId) {
        let page = 1;
        let hasMore = true;
        while (hasMore) {
            try {
                const apiUrl = _0x5f + "/ajax/episodes/" + animeId + "/" + page;
                const body = "_token=" + encodeURIComponent(s.csrf);
                const rawJson = sansonRequest("POST", apiUrl, body, {
                    "User-Agent": UA, "Accept": "application/json, text/javascript, */*; q=0.01",
                    "Content-Type": "application/x-www-form-urlencoded; charset=UTF-8",
                    "X-Requested-With": "XMLHttpRequest", "Referer": url,
                    "Origin": _0x5f, "Cookie": s.cookies
                }, false, PLATFORM);

                const json = JSON.parse(rawJson);
                if (json && json.data && Array.isArray(json.data) && json.data.length > 0) {
                    for (let i = 0; i < json.data.length; i++) {
                        const ep = json.data[i];
                        const num = String(ep.number || ep.id);
                        if (!seen.has(num)) {
                            seen.add(num);
                            items.push(episodeItem(slug, num, ep.title || ("Episodio " + num), ""));
                        }
                    }
                    page++;
                } else {
                    hasMore = false;
                }
            } catch (e) {
                hasMore = false;
            }
        }
    }

    if (items.length === 0) {
        const loose = new RegExp('\\/' + slug + '\\/(\\d+)\\/', "g");
        while ((m = loose.exec(html)) !== null) {
            const num = m[1];
            if (seen.has(num)) continue;
            seen.add(num);
            items.push(episodeItem(slug, num, "Episodio " + num, ""));
        }
    }

    items.sort(function(a, b) {
        const na = parseInt((/\/(\d+)\/?$/.exec(a.url) || ["", "0"])[1], 10);
        const nb = parseInt((/\/(\d+)\/?$/.exec(b.url) || ["", "0"])[1], 10);
        return na - nb;
    });

    return new VideoPager(items, false, {});
};

function extractServers(html) {
    const servers = [];
    let m;
    const mainRegex = /src="([^"]*jkplayer\/um[^"]*)"/g;
    while ((m = mainRegex.exec(html)) !== null) {
        let u = m[1];
        if (u.startsWith("/")) u = _0x5f + u;
        servers.push(u);
    }
    const embedRegex = /"remote":"([^"]*)"/g;
    while ((m = embedRegex.exec(html)) !== null) {
        try {
            const decoded = atob(m[1]);
            if (decoded && decoded !== "null") servers.push(decoded);
        } catch(e) {}
    }
    return servers;
}

function extractVideoUrl(html) {
    let m;
    m = /atob\('([^']+)'\)/.exec(html);
    if (m) {
        try {
            const decoded = atob(m[1]);
            const u = /(https?:\/\/[^"'\s]+\.m3u8[^"'\s]*)/.exec(decoded);
            if (u) return u[1];
        } catch (e) {}
    }
    m = /var\s+\w+\s*=\s*['"](https?:\/\/[^"']+\.m3u8[^"']*)['"]/.exec(html);
    if (m) return m[1];
    m = /(https?:\/\/[^"'\s]+\.m3u8[^"'\s]*)/.exec(html);
    if (m) return m[1];
    m = /(https?:\/\/[^"'\s]+\.mp4[^"'\s]*)/.exec(html);
    if (m) return m[1];
    return null;
}

source.getContentDetails = function (url) {
    const s = getSession();
    const html = http.GET(url, { "User-Agent": UA, "Referer": _0x5f + "/", "Cookie": s.cookies }, false).body;
    const slugMatch = /jkanime\.net\/([\w-]+)\//.exec(url);
    const slug = slugMatch ? slugMatch[1] : "";
    const epNumMatch = /\/(\d+)\/?$/.exec(url);
    const epNum = epNumMatch ? epNumMatch[1] : "1";

    let animeName = slug.replace(/-/g, " ").replace(/\b\w/g, function(l) { return l.toUpperCase(); });
    let totalEps = "?";

    try {
        const animeUrl = url.replace(/\/\d+\/?$/, "/");
        const animeHtml = http.GET(animeUrl, { "User-Agent": UA, "Referer": _0x5f + "/", "Cookie": s.cookies }, false).body;

        let animeId = null;
        let m = /data-anime=["'](\d+)["']/.exec(animeHtml);
        if (m) animeId = m[1];
        if (!animeId) {
            m = /var\s+anime_id\s*=\s*["']?(\d+)["']?/i.exec(animeHtml);
            if (m) animeId = m[1];
        }

        if (animeId) {
            const searchBody = "_token=" + encodeURIComponent(s.csrf) + "&q=" + encodeURIComponent(slug.replace(/-/g, " "));
            const searchResp = sansonRequest("POST", _0x5f + "/ajax_search", searchBody, {
                "User-Agent": UA, "Content-Type": "application/x-www-form-urlencoded; charset=UTF-8",
                "X-Requested-With": "XMLHttpRequest", "Referer": _0x5f + "/buscar/",
                "Origin": _0x5f, "Cookie": s.cookies
            }, false, PLATFORM);
            const searchResults = JSON.parse(searchResp);
            if (searchResults && searchResults[0] && searchResults[0].slug === slug) {
                animeName = searchResults[0].title;
            }

            const apiUrl = _0x5f + "/ajax/episodes/" + animeId + "/1";
            const apiBody = "_token=" + encodeURIComponent(s.csrf);
            const rawJson = sansonRequest("POST", apiUrl, apiBody, {
                "User-Agent": UA, "Accept": "application/json, text/javascript, */*; q=0.01",
                "Content-Type": "application/x-www-form-urlencoded; charset=UTF-8",
                "X-Requested-With": "XMLHttpRequest", "Referer": animeUrl,
                "Origin": _0x5f, "Cookie": s.cookies
            }, false, PLATFORM);
            const json = JSON.parse(rawJson);
            if (json && json.total) totalEps = String(json.total);
        }
    } catch (e) {}

    const desc = "Anime: " + animeName + "\nEpisodio: " + epNum + "\nCategoría: Anime Sub Español\nTotal Episodios: " + totalEps + "\n\nAVISO: Enlaces extraídos de fuentes públicas.";

    const servers = extractServers(html);
    let videoUrl = null;
    for (let i = 0; i < servers.length; i++) {
        let full = servers[i];
        if (full.startsWith("//")) full = "https:" + full;
        else if (full.startsWith("/")) full = _0x5f + full;
        else if (!/^https?:/.test(full)) full = "https://cdn.jkdesa.com" + full;
        try {
            const iframeHtml = http.GET(full, { "User-Agent": UA, "Referer": url, "Cookie": s.cookies }, false).body;
            videoUrl = extractVideoUrl(iframeHtml);
            if (videoUrl) break;
        } catch (e) {}
    }
    if (!videoUrl) videoUrl = extractVideoUrl(html);
    if (!videoUrl) throw new ScriptException("No se pudo cargar el video.");

    const isHls = videoUrl.includes(".m3u8");
    const highResThumb = "https://cdn.jkdesa.com/assets/images/animes/image/" + slug + ".jpg";
    return new PlatformVideoDetails({
        id: sansonPid(PLATFORM, url), name: animeName + " - Episodio " + epNum,
        thumbnails: sansonThumbs(highResThumb), author: sansonAuthor(PLATFORM, "", "RamenTV", _0x5f, null),
        url: url, duration: 0, viewCount: -1, description: desc,
        video: new VideoSourceDescriptor([new VideoUrlSource({
            name: isHls ? "Stream HD" : "MP4", url: videoUrl, width: 0, height: 0,
            codec: "", container: isHls ? "m3u8" : "mp4", bitrate: 0, duration: 0
        })])
    });
};

source.getContentRecommendations = function (url) {
    return new VideoPager([], false, {});
};
