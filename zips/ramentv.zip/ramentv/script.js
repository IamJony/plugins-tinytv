// RamenTV plugin para Sanson — API interna optimizada
// GPL-3.0-or-later

const PLATFORM = "RamenTV";

// Ofuscación básica de la URL base para evitar detección simple por strings
const _0x5f = "https://" + "jk" + "anime" + ".net";
const UA = "Mozilla/5.0 (X11; Linux x86_64; rv:133.0) Gecko/20100101 Firefox/133.0";

let session = null;

source.enable = function () {};

// --- Gestión de sesión -----------------------------------------------------------------------
function initSession() {
    const resp = http.GET(_0x5f + "/", {
        "User-Agent": UA,
        "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
        "Accept-Language": "es-CO,es;q=0.8,en-US;q=0.5,en;q=0.3"
    }, false);

    if (resp.code !== 200) {
        throw new CaptchaRequiredException(_0x5f + "/", "");
    }

    const csrfMatch = /name="csrf-token" content="([^"]+)"/.exec(resp.body);
    if (!csrfMatch) {
        throw new CaptchaRequiredException(_0x5f + "/", resp.body.substring(0, 500));
    }

    let setCookies = resp.headers["set-cookie"];
    if (!Array.isArray(setCookies)) setCookies = setCookies ? [setCookies] : [];
    
    let cookieHeader = "";
    for (const c of setCookies) {
        const kv = c.split(";")[0].trim();
        if (kv.includes("=")) cookieHeader += (cookieHeader ? "; " : "") + kv;
    }

    session = {
        csrf: csrfMatch[1],
        cookies: cookieHeader,
        home: resp.body
    };
    return session;
}

function getSession() {
    if (!session) initSession();
    return session;
}

// --- Peticiones --------------------------------------------------------------------------------
function apiSearch(query) {
    const s = getSession();
    const body = "_token=" + encodeURIComponent(s.csrf) + "&q=" + encodeURIComponent(query);
    
    try {
        const resp = sansonRequest("POST", _0x5f + "/ajax_search", body, {
            "User-Agent": UA,
            "Content-Type": "application/x-www-form-urlencoded; charset=UTF-8",
            "X-Requested-With": "XMLHttpRequest",
            "Referer": _0x5f + "/buscar/" + encodeURIComponent(query),
            "Origin": _0x5f,
            "Cookie": s.cookies
        }, false, PLATFORM);
        return JSON.parse(resp);
    } catch (e) {
        // Renovar sesión si falla
        session = null;
        const s2 = getSession();
        const body2 = "_token=" + encodeURIComponent(s2.csrf) + "&q=" + encodeURIComponent(query);
        const resp2 = sansonRequest("POST", _0x5f + "/ajax_search", body2, {
            "User-Agent": UA,
            "Content-Type": "application/x-www-form-urlencoded; charset=UTF-8",
            "X-Requested-With": "XMLHttpRequest",
            "Referer": _0x5f + "/buscar/" + encodeURIComponent(query),
            "Origin": _0x5f,
            "Cookie": s2.cookies
        }, false, PLATFORM);
        return JSON.parse(resp2);
    }
}

function fetchPage(url, referer) {
    const s = getSession();
    const resp = http.GET(url, {
        "User-Agent": UA,
        "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
        "Accept-Language": "es-CO,es;q=0.8,en-US;q=0.5,en;q=0.3",
        "Referer": referer || (_0x5f + "/"),
        "Cookie": s.cookies
    }, false);

    if (resp.code !== 200) {
        throw new ScriptException("Error de conexión al obtener contenido.");
    }
    return resp.body;
}

// --- Items -------------------------------------------------------------------------------------
function animeItem(id, title, url, thumb, type, status) {
    return new PlatformChannel({
        id: sansonPid(PLATFORM, String(id ?? url)),
        name: title ?? "",
        thumbnail: thumb || "",
        url: url,
        description: (type || "") + (status ? (type ? " · " : "") + status : ""),
        subscribers: -1
    });
}

function episodeItem(slug, num, title, thumb) {
    return new PlatformVideo({
        id: sansonPid(PLATFORM, slug + "-" + num),
        name: title || ("Episodio " + num),
        thumbnails: sansonThumbs(thumb || ""),
        author: sansonAuthor(PLATFORM, "", "RamenTV", _0x5f, null),
        duration: 0,
        viewCount: -1,
        url: _0x5f + "/" + slug + "/" + num + "/",
        isLive: false
    });
}

// --- Home --------------------------------------------------------------------------------------
source.getHome = function () {
    const s = getSession();
    const html = s.home;
    const items = [];
    const seen = new Set();

    // Extracción de tarjetas de la portada
    const re = /<a href="(https:\/\/jkanime\.net\/[^\/]+\/)"[^>]*>[\s\S]*?<img[^>]* src="([^"]+)"[^>]*>[\s\S]*?<h[^>]*>([^<]+)<\/h/g;
    let m;
    while ((m = re.exec(html)) !== null) {
        const url = m[1];
        const thumb = m[2];
        const title = m[3].trim();
        
        if (!title || url.includes("/buscar/") || seen.has(url)) continue;
        
        seen.add(url);
        const slugMatch = /\/([\w-]+)\/?$/.exec(url);
        const slug = slugMatch ? slugMatch[1] : url;
        
        items.push(animeItem(slug, title, url, thumb, "", ""));
    }
    return new VideoPager(items.slice(0, 60), false, {});
};

// --- Búsqueda (API AJAX) -----------------------------------------------------------------------
source.search = function (query) {
    const results = apiSearch(query);
    const items = [];
    for (const r of (Array.isArray(results) ? results : results.data ?? [])) {
        items.push(animeItem(
            r.id,
            r.title,
            _0x5f + "/" + r.slug + "/",
            r.thumbnail || (r.image ? "https://cdn.jkdesa.com/assets/images/animes/image/" + r.image : ""),
            r.type,
            r.status
        ));
    }
    return new VideoPager(items, false, {});
};

// --- Canal (anime) -----------------------------------------------------------------------------
source.getChannel = function (url) {
    const html = fetchPage(url);
    const title = (/<h1[^>]*>([^<]+)<\/h1>/.exec(html) ?? [])[1] ||
                  (/<title>([^<—|]+)/.exec(html) ?? [])[1] || "Anime";
    
    const thumb = (/<meta property="og:image" content="([^"]+)"/.exec(html) ?? [])[1] || "";
    const desc = (/<meta name="description" content="([^"]+)"/.exec(html) ?? [])[1] || "";
    
    const slugMatch = /\/([\w-]+)\/?$/.exec(url);
    const slug = slugMatch ? slugMatch[1] : url;

    return new PlatformChannel({
        id: sansonPid(PLATFORM, slug),
        name: title.trim(),
        thumbnail: thumb,
        url: url,
        description: desc,
        subscribers: -1
    });
};

// --- Capítulos (Usando la API interna) ---------------------------------------------------------
source.getChannelContents = function (url) {
    const html = fetchPage(url);
    const slugMatch = /jkanime\.net\/([\w-]+)\/?/.exec(url);
    const slug = slugMatch ? slugMatch[1] : "";
    
    if (!slug) return new VideoPager([], false, {});

    const items = [];
    const seen = new Set();

    // 1. Buscar el ID del anime en el HTML
    let animeId = null;
    let m = /data-id=["'](\d+)["']/.exec(html);
    if (m) animeId = m[1];
    else {
        m = /var\s+anime_id\s*=\s*["']?(\d+)["']?/i.exec(html);
        if (m) animeId = m[1];
    }

    // 2. Consultar la API si tenemos el ID
    if (animeId) {
        try {
            const s = getSession();
            const apiUrl = _0x5f + "/ajax/episodes/" + animeId + "/1";
            const body = "_token=" + encodeURIComponent(s.csrf);
            
            const rawJson = sansonRequest("POST", apiUrl, body, {
                "User-Agent": UA,
                "Accept": "application/json, text/javascript, */*; q=0.01",
                "Content-Type": "application/x-www-form-urlencoded; charset=UTF-8",
                "X-Requested-With": "XMLHttpRequest",
                "Referer": url,
                "Origin": _0x5f,
                "Cookie": s.cookies
            }, false, PLATFORM);
            
            const json = JSON.parse(rawJson);
            
            if (json && json.data && Array.isArray(json.data)) {
                for (const ep of json.data) {
                    const num = String(ep.number || ep.id);
                    if (!seen.has(num)) {
                        seen.add(num);
                        items.push(episodeItem(slug, num, ep.title || ("Episodio " + num), ""));
                    }
                }
            } else if (json && json.total > 0) {
                for (let i = 1; i <= json.total; i++) {
                    items.push(episodeItem(slug, String(i), "Episodio " + i, ""));
                }
            }
        } catch (e) {
            // Silenciar error de API para no exponer detalles
        }
    }

    // 3. Fallbacks de HTML (si la API falla)
    if (items.length === 0) {
        const re = new RegExp('href="(?:https?:\\/\\/jkanime\\.net)?\\/' + slug + '\\/(\\d+)\\/?"[^>]*>([\\s\\S]*?)<\\/a>', "g");
        while ((m = re.exec(html)) !== null) {
            const num = m[1];
            if (seen.has(num)) continue;
            seen.add(num);
            const raw = m[2].replace(/<[^>]+>/g, "").replace(/\s+/g, " ").trim();
            items.push(episodeItem(slug, num, /episodio/i.test(raw) ? raw : ("Episodio " + num), ""));
        }
    }

    if (items.length === 0) {
        const loose = new RegExp('\\/' + slug + '\\/(\\d+)\\/', "g");
        while ((m = loose.exec(html)) !== null) {
            const num = m[1];
            if (seen.has(num)) continue;
            seen.add(num);
            items.push(episodeItem(slug, num, "Episodio " + num, ""));
        }
    }

    // Ordenar de menor a mayor
    items.sort((a, b) => {
        const na = parseInt((/\/(\d+)\/?$/.exec(a.url) ?? [])[1] || "0", 10);
        const nb = parseInt((/\/(\d+)\/?$/.exec(b.url) ?? [])[1] || "0", 10);
        return na - nb;
    });

    return new VideoPager(items, false, {});
};

// --- Extracción de video -----------------------------------------------------------------------
function extractServers(html) {
    const servers = [];
    let m;
    
    // Servidores principales
    const mainRegex = /src="([^"]*jkplayer\/um[^"]*)"/g;
    while ((m = mainRegex.exec(html)) !== null) {
        let url = m[1];
        if (url.startsWith("/")) url = _0x5f + url;
        servers.push(url);
    }
    
    // Servidores embebidos (Base64)
    const embedRegex = /"remote":"([^"]*)"/g;
    while ((m = embedRegex.exec(html)) !== null) {
        try {
            const decoded = atob(m[1]);
            if (decoded && decoded !== "null") {
                servers.push(decoded);
            }
        } catch(e) {}
    }
    return servers;
}

function extractVideoUrl(html) {
    let m;
    
    // 1. atob()
    m = /atob\('([^']+)'\)/.exec(html);
    if (m) {
        try {
            const decoded = atob(m[1]);
            const u = /(https?:\/\/[^"'\s]+\.m3u8[^"'\s]*)/.exec(decoded);
            if (u) return u[1];
        } catch (e) {}
    }
    
    // 2. Variables JS
    m = /var\s+\w+\s*=\s*['"](https?:\/\/[^"']+\.m3u8[^"']*)['"]/.exec(html);
    if (m) return m[1];
    
    // 3. URL Directa
    m = /(https?:\/\/[^"'\s]+\.m3u8[^"'\s]*)/.exec(html);
    if (m) return m[1];
    
    // 4. unescape()
    m = /unescape\('([^']+)'\)/.exec(html);
    if (m) {
        const decoded = unescape(m[1]);
        const u = /(https?:\/\/[^"'\s]+\.m3u8[^"'\s]*)/.exec(decoded);
        if (u) return u[1];
    }
    
    // 5. eval packed
    m = /eval\((.*?)\)/s.exec(html);
    if (m) {
        const u = /(https?:\/\/[^"'\s]+\.m3u8[^"'\s]*)/.exec(m[1]);
        if (u) return u[1];
    }
    
    // 6. URL Directa MP4
    m = /(https?:\/\/[^"'\s]+\.mp4[^"'\s]*)/.exec(html);
    if (m) return m[1];
    
    return null;
}

source.getContentDetails = function (url) {
    const html = fetchPage(url);
    const title = (/<h1[^>]*>([^<]+)<\/h1>/.exec(html) ?? [])[1] || "Episodio";
    
    const servers = extractServers(html);
    let videoUrl = null;
    
    for (const serverUrl of servers) {
        let full = serverUrl;
        if (full.startsWith("//")) full = "https:" + full;
        else if (full.startsWith("/")) full = _0x5f + full;
        else if (!/^https?:/.test(full)) full = "https://cdn.jkdesa.com" + full;
        
        try {
            const iframeHtml = fetchPage(full, url);
            videoUrl = extractVideoUrl(iframeHtml);
            if (videoUrl) break;
        } catch (e) {
            // Continuar con el siguiente servidor
        }
    }
    
    if (!videoUrl) videoUrl = extractVideoUrl(html);
    
    if (!videoUrl)
        throw new ScriptException("No se pudo cargar el video. Intenta más tarde.");
        
    const isHls = videoUrl.includes(".m3u8");
    
    return new PlatformVideoDetails({
        id: sansonPid(PLATFORM, url),
        name: title.trim(),
        thumbnails: sansonThumbs(""),
        author: sansonAuthor(PLATFORM, "", "RamenTV", _0x5f, null),
        url: url,
        duration: 0,
        viewCount: -1,
        description: "",
        video: new VideoSourceDescriptor([
            new VideoUrlSource({
                name: isHls ? "Stream HD" : "MP4",
                url: videoUrl,
                width: 0,
                height: 0,
                codec: "",
                container: isHls ? "m3u8" : "mp4",
                bitrate: 0,
                duration: 0
            })
        ])
    });
};

source.getContentRecommendations = function (url) {
    return new VideoPager([], false, {});
};
