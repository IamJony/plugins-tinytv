// RamenTV plugin para Sanson — Corregido para paginación completa
const PLATFORM = "RamenTV";
const _0x5f = "https://jkanime.net";
const UA = "Mozilla/5.0 (X11; Linux x86_64; rv:133.0) Gecko/20100101 Firefox/133.0";
let session = null;

source.enable = function () {};

function initSession() {
    const resp = http.GET(_0x5f + "/", {
        "User-Agent": UA,
        "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8"
    }, false);
    if (resp.code !== 200) throw new CaptchaRequiredException(_0x5f + "/", "");
    
    const csrfMatch = /name="csrf-token" content="([^"]+)"/.exec(resp.body);
    if (!csrfMatch) throw new ScriptException("No se pudo obtener CSRF");
    
    let setCookies = resp.headers["set-cookie"];
    if (!Array.isArray(setCookies)) setCookies = setCookies ? [setCookies] : [];
    let cookieHeader = "";
    for (const c of setCookies) {
        const kv = c.split(";")[0].trim();
        if (kv.includes("=")) cookieHeader += (cookieHeader ? "; " : "") + kv;
    }
    session = { csrf: csrfMatch[1], cookies: cookieHeader, home: resp.body };
    return session;
}

function getSession() {
    if (!session) initSession();
    return session;
}

function animeItem(id, title, url, thumb, type, status) {
    return new PlatformChannel({
        id: sansonPid(PLATFORM, String(id || url)),
        name: title || "",
        thumbnail: thumb || "",
        url: url,
        description: (type || "") + (status ? (type ? " · " : "") + status : ""),
        subscribers: -1
    });
}

function episodeItem(slug, num, title, thumb) {
    let finalThumb = "https://cdn.jkdesa.com/assets/images/animes/image/" + slug + ".jpg";
    return new PlatformVideo({
        id: sansonPid(PLATFORM, slug + "-" + num),
        name: title || ("Episodio " + num),
        thumbnails: sansonThumbs(finalThumb),
        author: sansonAuthor(PLATFORM, "", "RamenTV", _0x5f, null),
        duration: 0,
        viewCount: -1,
        url: _0x5f + "/" + slug + "/" + num + "/",
        isLive: false
    });
}

source.getHome = function () {
    const s = getSession();
    const html = s.home;
    const items = [];
    const seen = new Set();
    const re = /<a href="(https:\/\/jkanime\.net\/[^\/]+\/)"[^>]*>[\s\S]*?<img[^>]* src="([^"]+)"[^>]*>[\s\S]*?<h[^>]*>([^<]+)<\/h/g;
    let m;
    while ((m = re.exec(html)) !== null) {
        const url = m[1], thumb = m[2], title = m[3].trim();
        if (!title || url.includes("/buscar/") || seen.has(url)) continue;
        seen.add(url);
        const slugMatch = /\/([\w-]+)\/?$/.exec(url);
        const slug = slugMatch ? slugMatch[1] : url;
        const highResThumb = "https://cdn.jkdesa.com/assets/images/animes/image/" + slug + ".jpg";
        items.push(animeItem(slug, title, url, highResThumb, "", ""));
    }
    return new VideoPager(items.slice(0, 60), false, {});
};

source.search = function (query) {
    const s = getSession();
    const body = "_token=" + encodeURIComponent(s.csrf) + "&q=" + encodeURIComponent(query);
    const resp = sansonRequest("POST", _0x5f + "/ajax_search", body, {
        "User-Agent": UA, "Content-Type": "application/x-www-form-urlencoded; charset=UTF-8",
        "X-Requested-With": "XMLHttpRequest", "Referer": _0x5f + "/buscar/" + encodeURIComponent(query),
        "Origin": _0x5f, "Cookie": s.cookies
    }, false, PLATFORM);
    const results = JSON.parse(resp);
    const items = [];
    const arr = Array.isArray(results) ? results : (results.data ? results.data : []);
    for (let i = 0; i < arr.length; i++) {
        const r = arr[i];
        const highResThumb = "https://cdn.jkdesa.com/assets/images/animes/image/" + r.slug + ".jpg";
        items.push(animeItem(r.id, r.title, _0x5f + "/" + r.slug + "/", highResThumb, r.type, r.status));
    }
    return new VideoPager(items, false, {});
};

source.getChannel = function (url) {
    const s = getSession();
    const resp = http.GET(url, { "User-Agent": UA, "Referer": _0x5f + "/", "Cookie": s.cookies }, false);
    const html = resp.body;
    const title = (/<h1[^>]*>([^<]+)<\/h1>/.exec(html) || [])[1] || "Anime";
    const thumb = (/<meta property="og:image" content="([^"]+)"/.exec(html) || [])[1] || "";
    const desc = (/<meta name="description" content="([^"]+)"/.exec(html) || [])[1] || "";
    const slugMatch = /\/([\w-]+)\/?$/.exec(url);
    const slug = slugMatch ? slugMatch[1] : url;
    return new PlatformChannel({
        id: sansonPid(PLATFORM, slug), name: title.trim(), thumbnail: thumb,
        url: url, description: desc, subscribers: -1
    });
};

source.getChannelContents = function (url) {
    const s = getSession();
    const html = http.GET(url, { "User-Agent": UA, "Referer": _0x5f + "/", "Cookie": s.cookies }, false).body;
    const slugMatch = /jkanime\.net\/([\w-]+)\/?/.exec(url);
    const slug = slugMatch ? slugMatch[1] : "";
    if (!slug) return new VideoPager([], false, {});

    const items = [];
    const seen = new Set();

    // Buscar ID del anime
    let animeId = null;
    let m = /data-anime=["'](\d+)["']/.exec(html);
    if (m) animeId = m[1];
    else {
        m = /var\s+anime_id\s*=\s*["']?(\d+)["']?/i.exec(html);
        if (m) animeId = m[1];
        else {
            m = /data-id=["'](\d+)["']/.exec(html);
            if (m) animeId = m[1];
        }
    }

    // Iterar sobre TODAS las páginas de la API
    if (animeId) {
        let page = 1;
        let hasMore = true;
        while (hasMore) {
            try {
                const apiUrl = _0x5f + "/ajax/episodes/" + animeId + "/" + page;
                const body = "_token=" + encodeURIComponent(s.csrf);
                const rawJson = sansonRequest("POST", apiUrl, body, {
                    "User-Agent": UA, "Accept": "application/json, text/javascript, */*; q=0.01",
                    "Content-Type": "application/x-www-form-urlencoded; charset=UTF-8",
                    "X-Requested-With": "XMLHttpRequest", "Referer": url,
                    "Origin": _0x5f, "Cookie": s.cookies
                }, false, PLATFORM);
                
                const json = JSON.parse(rawJson);
                if (json && json.data && Array.isArray(json.data) && json.data.length > 0) {
                    for (let i = 0; i < json.data.length; i++) {
                        const ep = json.data[i];
                        const num = String(ep.number || ep.id);
                        if (!seen.has(num)) {
                            seen.add(num);
                            items.push(episodeItem(slug, num, ep.title || ("Episodio " + num), ""));
                        }
                    }
                    page++;
                } else {
                    hasMore = false;
                }
            } catch (e) {
                hasMore = false;
            }
        }
    }

    // Fallback HTML si la API falla completamente
    if (items.length === 0) {
        const loose = new RegExp('\\/' + slug + '\\/(\\d+)\\/', "g");
        while ((m = loose.exec(html)) !== null) {
            const num = m[1];
            if (seen.has(num)) continue;
            seen.add(num);
            items.push(episodeItem(slug, num, "Episodio " + num, ""));
        }
    }

    items.sort(function(a, b) {
        const na = parseInt((/\/(\d+)\/?$/.exec(a.url) || ["", "0"])[1], 10);
        const nb = parseInt((/\/(\d+)\/?$/.exec(b.url) || ["", "0"])[1], 10);
        return na - nb;
    });

    return new VideoPager(items, false, {});
};

function extractServers(html) {
    const servers = [];
    let m;
    const mainRegex = /src="([^"]*jkplayer\/um[^"]*)"/g;
    while ((m = mainRegex.exec(html)) !== null) {
        let u = m[1];
        if (u.startsWith("/")) u = _0x5f + u;
        servers.push(u);
    }
    const embedRegex = /"remote":"([^"]*)"/g;
    while ((m = embedRegex.exec(html)) !== null) {
        try {
            const decoded = atob(m[1]);
            if (decoded && decoded !== "null") servers.push(decoded);
        } catch(e) {}
    }
    return servers;
}

function extractVideoUrl(html) {
    let m;
    m = /atob\('([^']+)'\)/.exec(html);
    if (m) {
        try {
            const decoded = atob(m[1]);
            const u = /(https?:\/\/[^"'\s]+\.m3u8[^"'\s]*)/.exec(decoded);
            if (u) return u[1];
        } catch (e) {}
    }
    m = /var\s+\w+\s*=\s*['"](https?:\/\/[^"']+\.m3u8[^"']*)['"]/.exec(html);
    if (m) return m[1];
    m = /(https?:\/\/[^"'\s]+\.m3u8[^"'\s]*)/.exec(html);
    if (m) return m[1];
    m = /(https?:\/\/[^"'\s]+\.mp4[^"'\s]*)/.exec(html);
    if (m) return m[1];
    return null;
}

source.getContentDetails = function (url) {
    const s = getSession();
    const html = http.GET(url, { "User-Agent": UA, "Referer": _0x5f + "/", "Cookie": s.cookies }, false).body;
    const slugMatch = /jkanime\.net\/([\w-]+)\//.exec(url);
    const slug = slugMatch ? slugMatch[1] : "";
    const epNumMatch = /\/(\d+)\/?$/.exec(url);
    const epNum = epNumMatch ? epNumMatch[1] : "1";

    let animeName = slug.replace(/-/g, " ").replace(/\b\w/g, function(l) { return l.toUpperCase(); });
    let totalEps = "?";

    // Obtener nombre real y total desde API
    try {
        const animeUrl = url.replace(/\/\d+\/?$/, "/");
        const animeHtml = http.GET(animeUrl, { "User-Agent": UA, "Referer": _0x5f + "/", "Cookie": s.cookies }, false).body;
        
        let animeId = null;
        let m = /data-anime=["'](\d+)["']/.exec(animeHtml);
        if (m) animeId = m[1];
        if (!animeId) {
            m = /var\s+anime_id\s*=\s*["']?(\d+)["']?/i.exec(animeHtml);
            if (m) animeId = m[1];
        }

        if (animeId) {
            // Buscar título en búsqueda AJAX
            const searchBody = "_token=" + encodeURIComponent(s.csrf) + "&q=" + encodeURIComponent(slug.replace(/-/g, " "));
            const searchResp = sansonRequest("POST", _0x5f + "/ajax_search", searchBody, {
                "User-Agent": UA, "Content-Type": "application/x-www-form-urlencoded; charset=UTF-8",
                "X-Requested-With": "XMLHttpRequest", "Referer": _0x5f + "/buscar/",
                "Origin": _0x5f, "Cookie": s.cookies
            }, false, PLATFORM);
            const searchResults = JSON.parse(searchResp);
            if (searchResults && searchResults[0] && searchResults[0].slug === slug) {
                animeName = searchResults[0].title;
            }

            // Obtener total de episodios
            const apiUrl = _0x5f + "/ajax/episodes/" + animeId + "/1";
            const apiBody = "_token=" + encodeURIComponent(s.csrf);
            const rawJson = sansonRequest("POST", apiUrl, apiBody, {
                "User-Agent": UA, "Accept": "application/json, text/javascript, */*; q=0.01",
                "Content-Type": "application/x-www-form-urlencoded; charset=UTF-8",
                "X-Requested-With": "XMLHttpRequest", "Referer": animeUrl,
                "Origin": _0x5f, "Cookie": s.cookies
            }, false, PLATFORM);
            const json = JSON.parse(rawJson);
            if (json && json.total) totalEps = String(json.total);
        }
    } catch (e) {}

    const desc = "Anime: " + animeName + "\nEpisodio: " + epNum + "\nCategoría: Anime Sub Español\nTotal Episodios: " + totalEps + "\n\nAVISO: Enlaces extraídos de fuentes públicas.";

    const servers = extractServers(html);
    let videoUrl = null;
    for (let i = 0; i < servers.length; i++) {
        let full = servers[i];
        if (full.startsWith("//")) full = "https:" + full;
        else if (full.startsWith("/")) full = _0x5f + full;
        else if (!/^https?:/.test(full)) full = "https://cdn.jkdesa.com" + full;
        try {
            const iframeHtml = http.GET(full, { "User-Agent": UA, "Referer": url, "Cookie": s.cookies }, false).body;
            videoUrl = extractVideoUrl(iframeHtml);
            if (videoUrl) break;
        } catch (e) {}
    }
    if (!videoUrl) videoUrl = extractVideoUrl(html);
    if (!videoUrl) throw new ScriptException("No se pudo cargar el video.");

    const isHls = videoUrl.includes(".m3u8");
    const highResThumb = "https://cdn.jkdesa.com/assets/images/animes/image/" + slug + ".jpg";
    return new PlatformVideoDetails({
        id: sansonPid(PLATFORM, url), name: animeName + " - Episodio " + epNum,
        thumbnails: sansonThumbs(highResThumb), author: sansonAuthor(PLATFORM, "", "RamenTV", _0x5f, null),
        url: url, duration: 0, viewCount: -1, description: desc,
        video: new VideoSourceDescriptor([new VideoUrlSource({
            name: isHls ? "Stream HD" : "MP4", url: videoUrl, width: 0, height: 0,
            codec: "", container: isHls ? "m3u8" : "mp4", bitrate: 0, duration: 0
        })])
    });
};

source.getContentRecommendations = function (url) {
    return new VideoPager([], false, {});
};
