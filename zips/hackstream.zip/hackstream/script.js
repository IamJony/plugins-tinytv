"use strict";

const PLATFORM = "HackStream";
const HACKSTREAM_BASE = "https://hackstream.io";
const HACKSTREAM_HOME_URL = "https://hackstream.io/";
const HACKSTREAM_BROWSE_URL = "https://hackstream.io/browse";
const HACKSTREAM_SEARCH_API = "https://hackstream.io/api/search/advanced";

const LBRY_PROXY_URL = "https://api.lbry.tv/api/v1/proxy";
const ODYSEE_PROXY_FALLBACK = "https://api.na-backend.odysee.com/api/v1/proxy";
const LBRY_LIVESTREAM_URL = "https://api.odysee.live/livestream/is_live";
const URL_COMMENTS = "https://comments.odysee.com/api/v2?m=comment.List";

const ODYSEE_REFERER = "https://odysee.com/";
const DEFAULT_UA = "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/136.0.0.0 Safari/537.36";
const SESSION_USER_ID = String(1000000000 + Math.floor(Math.random() * 1000000000));

const HTML_HEADERS = {
    "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
    "Referer": `${HACKSTREAM_BASE}/`,
    "User-Agent": DEFAULT_UA
};

const API_HEADERS = {
    "Accept": "application/json",
    "Origin": HACKSTREAM_BASE,
    "Referer": `${HACKSTREAM_BASE}/`,
    "User-Agent": DEFAULT_UA
};

const ODYSEE_STREAM_HEADERS = {
    "User-Agent": DEFAULT_UA,
    "Accept": "*/*",
    "Accept-Language": "es-ES,es;q=0.9,en-US;q=0.8,en;q=0.7",
    "Accept-Encoding": "identity",
    "Origin": "https://odysee.com",
    "Referer": ODYSEE_REFERER,
    "X-Odysee-User-Id": SESSION_USER_ID,
    "Sec-GPC": "1",
    "Sec-Fetch-Dest": "empty",
    "Sec-Fetch-Mode": "cors",
    "Sec-Fetch-Site": "cross-site"
};

let localConfig = {};
let localSettings = {};

const WATCH_CACHE = new Map();
const CLAIM_CACHE = new Map();
const HS_ODYSEE_MAP = new Map();
const CACHE_TTL_MS = 5 * 60 * 1000;

function traceMsg(msg) {
    const line = `[HackStream] ${msg}`;
    if (typeof trace === "function") trace(line);
    else if (typeof log === "function") log(line);
}

function getCache(map, key) {
    if (!key) return null;
    const entry = map.get(key);
    if (!entry) return null;
    if ((Date.now() - entry.ts) > CACHE_TTL_MS) {
        map.delete(key);
        return null;
    }
    return entry.val;
}

function setCache(map, key, val) {
    if (!key || val == null) return;
    if (map.size >= 200) {
        const oldest = map.keys().next().value;
        map.delete(oldest);
    }
    map.set(key, { val, ts: Date.now() });
}

function clearAllCaches() {
    WATCH_CACHE.clear();
    CLAIM_CACHE.clear();
    HS_ODYSEE_MAP.clear();
    try {
        if (typeof sp_stop_hackstream === "function") sp_stop_hackstream();
    } catch (_) {}
}

function makeId(val) {
    if (typeof sansonPid === "function") return sansonPid(PLATFORM, String(val ?? ""));
    return new PlatformID(PLATFORM, String(val ?? ""), localConfig.id || "hackstream");
}

function normalizeUrl(u) {
    if (!u) return "";
    let s = String(u).trim();
    if (!s) return "";
    if (s.startsWith("//")) s = "https:" + s;
    else if (s.startsWith("/")) s = HACKSTREAM_BASE + s;
    else if (s.startsWith("http://")) s = "https://" + s.slice(7);
    if (s.includes("thumbnails.odycdn.com/")) {
        s = s.replace(/\/s:\d+:\d+\//, "/s:480:270/");
    }
    return s;
}

function safeEncodeUrl(u) {
    if (!u) return "";
    const s = String(u).trim();
    if (!s) return "";
    try {
        const mark = "__PCT__";
        const prot = s.replace(/%[0-9a-fA-F]{2}/g, m => mark + m.slice(1));
        return encodeURI(prot).replace(new RegExp(mark, "g"), "%");
    } catch (_) {
        return s;
    }
}

function makeThumbs(url) {
    const clean = normalizeUrl(url);
    if (typeof sansonThumbs === "function") return sansonThumbs(clean);
    return new Thumbnails(clean ? [new Thumbnail(clean, 0)] : []);
}

function makeAuthor(name, url, thumb) {
    const safeName = name || "s4vitar";
    const safeUrl = url || "https://odysee.com/@s4visinfiltro:8";
    const safeThumb = normalizeUrl(thumb);
    if (typeof sansonAuthor === "function") {
        return sansonAuthor(PLATFORM, safeUrl || safeName, safeName, safeUrl, safeThumb || null, null);
    }
    return new PlatformAuthorLink(makeId(safeUrl || safeName), safeName, safeUrl, safeThumb || null, null);
}

function decodeEscapes(str) {
    if (typeof str !== "string") return "";
    return str
        .replace(/\\u002F/gi, "/")
        .replace(/\\u003A/gi, ":")
        .replace(/\\u003F/gi, "?")
        .replace(/\\u0026/gi, "&")
        .replace(/\\u003D/gi, "=")
        .replace(/\\"/g, '"')
        .replace(/\\n/g, "\n")
        .replace(/\\r/g, "");
}

function urlDecode(str) {
    if (!str) return "";
    try { return decodeURIComponent(String(str).replace(/\+/g, " ")); }
    catch (_) { return String(str); }
}

function parseDuration(dur) {
    if (typeof dur === "number" && !Number.isNaN(dur)) return Math.max(0, Math.floor(dur));
    if (!dur || typeof dur !== "string") return 0;
    const iso = /^PT(?:(\d+)H)?(?:(\d+)M)?(?:(\d+)S)?$/i.exec(dur.trim());
    if (iso) {
        return (parseInt(iso[1] || "0", 10) * 3600)
             + (parseInt(iso[2] || "0", 10) * 60)
             + parseInt(iso[3] || "0", 10);
    }
    const parts = dur.trim().split(":").map(n => parseInt(n, 10) || 0);
    if (parts.length === 2) return parts[0] * 60 + parts[1];
    if (parts.length === 3) return parts[0] * 3600 + parts[1] * 60 + parts[2];
    return parseInt(dur, 10) || 0;
}

function parseUnixDate(d) {
    if (d === null || d === undefined || d === "" || d === "$undefined") return 0;
    if (typeof d === "number" && !Number.isNaN(d)) {
        if (d <= 0) return 0;
        return d > 1e11 ? Math.floor(d / 1000) : Math.floor(d);
    }
    let raw = String(d).trim();
    if (!raw || raw === "$undefined") return 0;
    if (raw.startsWith("$D")) raw = raw.slice(2).trim();
    if (/^\d+$/.test(raw)) {
        const n = Number(raw);
        if (n <= 0) return 0;
        return n > 1e11 ? Math.floor(n / 1000) : Math.floor(n);
    }
    const isoCandidate = raw.includes(" ") && !raw.includes("T") ? raw.replace(" ", "T") : raw;
    const t = Date.parse(isoCandidate);
    if (!Number.isNaN(t) && t > 0) return Math.floor(t / 1000);
    const tOrig = Date.parse(raw);
    return (!Number.isNaN(tOrig) && tOrig > 0) ? Math.floor(tOrig / 1000) : 0;
}

function pickDateField(obj) {
    if (!obj || typeof obj !== "object") return 0;
    const candidates = [
        obj.publishedAt,
        obj.createdAt,
        obj.uploadDate,
        obj.datePublished,
        obj.published_at,
        obj.created_at,
        obj.upload_date,
        obj.date,
        obj.release_time,
        obj.timestamp
    ];
    for (let i = 0; i < candidates.length; i++) {
        const ts = parseUnixDate(candidates[i]);
        if (ts > 0) return ts;
    }
    return 0;
}

function getAuthToken() {
    if (localSettings && typeof localSettings.auth_token === "string" && localSettings.auth_token.trim()) {
        return localSettings.auth_token.trim();
    }
    if (localConfig && typeof localConfig.auth_token === "string" && localConfig.auth_token.trim()) {
        return localConfig.auth_token.trim();
    }
    try {
        if (typeof http !== "undefined" && typeof http.getCookies === "function") {
            const cookies = http.getCookies(ODYSEE_REFERER);
            if (Array.isArray(cookies)) {
                const tok = cookies.find(c => c && c.name === "auth_token");
                if (tok && tok.value) return String(tok.value).trim();
            }
        }
    } catch (_) {}
    return "";
}

function rpcCall(method, params, endpoint = LBRY_PROXY_URL) {
    const isComments = String(endpoint).includes("comments.odysee.com");
    const headers = {
        "Content-Type": isComments ? "application/json" : "application/json-rpc",
        "Origin": ODYSEE_REFERER.slice(0, -1),
        "Referer": ODYSEE_REFERER,
        "User-Agent": DEFAULT_UA
    };
    const token = getAuthToken();
    if (token) headers["x-lbry-auth-token"] = token;

    const payload = JSON.stringify({
        method: method,
        params: params || {}
    });

    let resp = http.POST(endpoint, payload, headers, false);
    if ((!resp || !resp.isOk) && endpoint === LBRY_PROXY_URL) {
        resp = http.POST(ODYSEE_PROXY_FALLBACK, payload, headers, false);
    }
    if (!resp || !resp.isOk) {
        throw new ScriptException(`Error HTTP ${resp?.code ?? "unknown"} en ${method}`);
    }
    if (!resp.body || !String(resp.body).trim()) {
        if (isComments) return null;
        throw new ScriptException(`Respuesta vacía en ${method}`);
    }
    const parsed = JSON.parse(resp.body);
    if (parsed && parsed.error) {
        throw new ScriptException(`LBRY API (${method}): ${parsed.error.message || parsed.error.code || "error"}`);
    }
    return parsed ? parsed.result : null;
}

// --- Conversión de URLs de HackStream / Odysee a lbry:// URI (solo para metadata) ---
function toLbryUri(rawUrl) {
    if (!rawUrl) return "";
    let clean = urlDecode(String(rawUrl).trim());
    if (clean.startsWith("lbry://")) return clean;

    clean = clean.replace(/^https?:\/\/(?:www\.)?(?:lbry\.tv|odysee\.com)\/(?:\$|%24)\/(?:download|embed)\//i, "");
    clean = clean.replace(/^https?:\/\/(?:www\.)?(?:lbry\.tv|odysee\.com)\//i, "");
    clean = clean.split(/[?#]/)[0].replace(/^\/+|\/+$/g, "");
    if (!clean) return "";

    if (clean.startsWith("@")) {
        return `lbry://${clean.replace(":", "#")}`;
    }
    return `lbry://${clean.replace(/\//g, ":")}`;
}

function extractHackStreamSlug(url) {
    const m = /\/watch\/([^/?#]+)/.exec(String(url || ""));
    return m ? urlDecode(m[1]) : "";
}

function fetchWatchHtml(watchUrl) {
    const clean = String(watchUrl || "").trim();
    const cached = getCache(WATCH_CACHE, clean);
    if (cached) return cached;
    const resp = http.GET(clean, HTML_HEADERS, false);
    if (!resp || !resp.isOk) {
        throw new ScriptException(`No se pudo cargar ${clean} (HTTP ${resp?.code ?? "unknown"})`);
    }
    const html = resp.body || "";
    setCache(WATCH_CACHE, clean, html);
    return html;
}

function extractFlightText(html) {
    const parts = [];
    const re = /self\.__next_f\.push\(\s*\[\s*\d+\s*,\s*"((?:\\.|[^"\\])*?)"\s*\]\s*\)/g;
    let m;
    while ((m = re.exec(html)) !== null) {
        parts.push(decodeEscapes(m[1]));
    }
    return parts.join("\n");
}

function extractWatchInfo(html) {
    const info = {
        title: "",
        description: "",
        thumbnailUrl: "",
        duration: 0,
        embedUrl: "",
        datetime: 0
    };
    if (!html) return info;

    const ldRe = /<script[^>]*type=["']application\/ld\+json["'][^>]*>([\s\S]*?)<\/script>/gi;
    let m;
    while ((m = ldRe.exec(html)) !== null) {
        try {
            const data = JSON.parse(m[1]);
            const obj = Array.isArray(data) ? data.find(x => x && x["@type"] === "VideoObject") : data;
            if (obj && obj["@type"] === "VideoObject") {
                info.title = obj.name || "";
                info.description = obj.description || "";
                info.thumbnailUrl = Array.isArray(obj.thumbnailUrl) ? (obj.thumbnailUrl[0] || "") : (obj.thumbnailUrl || "");
                info.duration = parseDuration(obj.duration || "");
                info.embedUrl = obj.embedUrl || "";
                info.datetime = pickDateField(obj);
                break;
            }
        } catch (_) {}
    }

    const combined = `${html}\n${extractFlightText(html)}`;

    if (!info.datetime) {
        const dateMatch = combined.match(/"(?:publishedAt|createdAt|uploadDate|datePublished|published_at|created_at|upload_date)"\s*:\s*("(?:\\.|[^"\\])*"|\d+)/i);
        if (dateMatch) {
            let rawVal = dateMatch[1];
            if (rawVal.startsWith('"')) {
                try { rawVal = JSON.parse(rawVal); } catch (_) { rawVal = rawVal.slice(1, -1); }
            }
            info.datetime = parseUnixDate(rawVal);
        }
    }

    if (!info.embedUrl) {
        const embedMatch = combined.match(/https?:\/\/(?:www\.)?(?:odysee\.com|odysee\.tv|lbry\.tv)\/(?:\$|%24)\/embed\/[^"'\s<>\\]+/i);
        if (embedMatch) {
            info.embedUrl = decodeEscapes(embedMatch[0]);
        } else {
            const urlMatch = combined.match(/https?:\/\/(?:www\.)?odysee\.com\/@[^"'\s<>\\]+\/[^"'\s<>\\]+/i);
            if (urlMatch) info.embedUrl = decodeEscapes(urlMatch[0]);
        }
    }

    return info;
}

function resolveClaim(uri) {
    if (!uri) return null;
    const cached = getCache(CLAIM_CACHE, uri);
    if (cached) return cached;

    const res = rpcCall("resolve", { urls: uri });
    let claim = res ? res[uri] : null;
    if (!claim && typeof res === "object" && res !== null) {
        const keys = Object.keys(res);
        if (keys.length === 1) claim = res[keys[0]];
    }
    if (!claim || claim.error) return null;

    if (claim.value_type === "repost" && claim.reposted_claim && claim.reposted_claim.value) {
        claim = claim.reposted_claim;
    }
    setCache(CLAIM_CACHE, uri, claim);
    return claim;
}

// ---------------------------------------------------------------------------
// REPRODUCCIÓN VÍA PROXY
// ---------------------------------------------------------------------------
function buildSourceViaProxy(playUrl, opts) {
    const cleanUrl = safeEncodeUrl(playUrl);
    let proxyUrl = cleanUrl;

    if (typeof sp_add_hackstream === "function") {
        try {
            const proxied = sp_add_hackstream(cleanUrl);
            if (proxied) {
                proxyUrl = String(proxied);
                traceMsg(`Fuente vía hackstream_proxy -> ${proxyUrl} (origen: ${cleanUrl})`);
            } else {
                traceMsg(`hackstream_proxy devolvió null, usando URL directa: ${cleanUrl}`);
            }
        } catch (e) {
            traceMsg(`sp_add_hackstream falló (${e}), usando URL directa: ${cleanUrl}`);
        }
    } else {
        traceMsg(`sp_add_hackstream no disponible, usando URL directa: ${cleanUrl}`);
    }

    return new VideoUrlSource({
        name: opts.name || "HackStream / Odysee",
        url: proxyUrl,
        referer: opts.referer || ODYSEE_REFERER,
        container: opts.container || "mp4",
        codec: opts.codec || "h264",
        width: opts.width || 0,
        height: opts.height || 0,
        bitrate: opts.bitrate || 0,
        duration: opts.duration || 0,
        requestModifier: {
            headers: Object.assign({}, ODYSEE_STREAM_HEADERS, {
                "Referer": opts.referer || ODYSEE_REFERER
            })
        }
    });
}

function buildSourcesFromClaim(claim, rawUrl, odyseeUrl) {
    const sources = [];
    let isLive = false;

    const val = claim?.value || {};
    const streamType = val.stream_type || "";
    const valueType = claim?.value_type || "";
    const duration = val.video?.duration || val.audio?.duration || 0;
    const width = val.video?.width || 0;
    const height = val.video?.height || 0;
    const ext = (val.source?.name && /\.([a-z0-9]{2,5})$/i.exec(val.source.name)?.[1]?.toLowerCase())
             || (val.source?.media_type && String(val.source.media_type).split("/")[1])
             || "mp4";

    const targetUrl = odyseeUrl || rawUrl || "";
    if (!targetUrl) {
        return { sources, isLive };
    }

    if (streamType === "video" || streamType === "audio" || !streamType) {
        sources.push(buildSourceViaProxy(targetUrl, {
            name: "HackStream / Odysee",
            referer: ODYSEE_REFERER,
            container: ext,
            codec: streamType === "audio" ? "none" : "h264",
            width: width,
            height: height,
            duration: duration
        }));
    } else if (valueType === "stream") {
        isLive = true;
        sources.push(buildSourceViaProxy(targetUrl, {
            name: "En Vivo",
            referer: ODYSEE_REFERER,
            container: "mp4",
            codec: "h264",
            width: width,
            height: height,
            duration: 0
        }));
    }

    return { sources, isLive };
}

// --- Homepage y Búsqueda ---
function buildVideoItem(obj) {
    if (!obj || !obj.slug) return null;
    const slug = String(obj.slug).trim();
    const title = String(obj.title || obj.name || slug).trim();
    const thumb = normalizeUrl(obj.thumbnailUrl || obj.thumbnail || "");
    const duration = parseDuration(obj.duration);
    const datetime = pickDateField(obj);
    const views = typeof obj.views === "number" ? obj.views : -1;
    const creator = (obj.creatorName && obj.creatorName !== "$undefined") ? String(obj.creatorName) : "s4vitar";
    const watchUrl = `${HACKSTREAM_BASE}/watch/${slug}`;
    const creatorUrl = creator.toLowerCase() === "s4vitar"
        ? "https://odysee.com/@s4visinfiltro:8"
        : `${HACKSTREAM_BASE}/usuario/${encodeURIComponent(creator)}`;

    if (obj.odyseeUrl || obj.embedUrl) {
        HS_ODYSEE_MAP.set(slug, obj.odyseeUrl || obj.embedUrl);
    }

    return new PlatformVideo({
        id: makeId(obj.videoId || obj.id || slug),
        name: title,
        thumbnails: makeThumbs(thumb),
        author: makeAuthor(creator, creatorUrl, ""),
        url: watchUrl,
        isLive: false,
        duration: duration,
        viewCount: views,
        datetime: datetime
    });
}

function parseVideosFromHtml(html) {
    const text = `${html}\n${extractFlightText(html)}`;
    const videos = [];
    const seen = new Set();

    const slugRe = /"slug"\s*:\s*"([^"]+)"/g;
    let m;
    while ((m = slugRe.exec(text)) !== null) {
        const slug = m[1];
        if (!slug || seen.has(slug)) continue;

        const start = text.lastIndexOf("{", m.index);
        const end = text.indexOf("}", m.index);
        if (start < 0 || end < 0 || (end - start) > 2500) continue;

        const chunk = text.slice(start, end + 1);
        const titleM = /"title"\s*:\s*"((?:\\.|[^"\\])+)"/.exec(chunk);
        const thumbM = /"thumbnailUrl"\s*:\s*"((?:\\.|[^"\\])+)"/.exec(chunk);
        if (!titleM || !thumbM) continue;

        seen.add(slug);

        const durM = /"duration"\s*:\s*(?:"([^"]+)"|(\d+))/.exec(chunk);
        const dateM = /"(?:publishedAt|createdAt|uploadDate|datePublished|published_at|created_at|upload_date|date|timestamp)"\s*:\s*(?:"((?:\\.|[^"\\])*)"|(\d+))/.exec(chunk);
        const viewsM = /"(?:views|viewCount)"\s*:\s*(\d+)/.exec(chunk);
        const creatorM = /"creatorName"\s*:\s*"([^"]+)"/.exec(chunk);
        const idM = /"(?:videoId|id)"\s*:\s*"([^"]+)"/.exec(chunk);

        const v = buildVideoItem({
            slug,
            title: decodeEscapes(titleM[1]),
            thumbnailUrl: decodeEscapes(thumbM[1]),
            duration: durM ? (durM[1] || Number(durM[2])) : 0,
            publishedAt: dateM ? (dateM[1] != null ? decodeEscapes(dateM[1]) : Number(dateM[2])) : 0,
            views: viewsM ? parseInt(viewsM[1], 10) : -1,
            creatorName: creatorM ? creatorM[1] : "s4vitar",
            videoId: idM ? idM[1] : slug
        });
        if (v) videos.push(v);
    }

    if (!videos.length) {
        const linkRe = /href="\/watch\/([^"?#]+)"[\s\S]{0,900}?<img[^>]+src="([^"]+)"[^>]+alt="([^"]+)"/g;
        while ((m = linkRe.exec(html)) !== null) {
            const slug = m[1];
            if (!slug || seen.has(slug)) continue;
            seen.add(slug);
            const v = buildVideoItem({
                slug,
                thumbnailUrl: m[2],
                title: decodeEscapes(m[3])
            });
            if (v) videos.push(v);
        }
    }

    return videos;
}

function fetchHomeVideos(page = 1) {
    const url = page <= 1 ? HACKSTREAM_HOME_URL : `${HACKSTREAM_BROWSE_URL}?page=${page}`;
    const resp = http.GET(url, HTML_HEADERS, false);
    if (!resp || !resp.isOk) {
        throw new ScriptException(`Error cargando HackStream (HTTP ${resp?.code ?? "unknown"})`);
    }
    return parseVideosFromHtml(resp.body || "");
}

class HomePager extends VideoPager {
    constructor(results, page) {
        super(results, Array.isArray(results) && results.length > 0 && page < 5, { page });
    }
    nextPage() {
        const next = (this.context.page || 1) + 1;
        return new HomePager(fetchHomeVideos(next), next);
    }
}

function isOdyseeOrLbryUrl(url) {
    const s = String(url || "").trim();
    return s.includes("odysee.com") || s.includes("odysee.tv") || s.includes("lbry.tv") || s.startsWith("lbry://");
}

function fetchAllChannelVideos(channelClaimId, fallbackAuthorName, fallbackAuthorUrl, fallbackAuthorThumb) {
    const vids = [];
    const seen = new Set();
    const pageSize = 50;
    let page = 1;
    const maxPages = 20;

    while (page <= maxPages) {
        const res = rpcCall("claim_search", {
            channel_ids: [channelClaimId],
            claim_type: ["stream", "repost"],
            stream_types: ["video", "audio"],
            order_by: ["release_time"],
            has_source: true,
            page: page,
            page_size: pageSize,
            no_totals: true
        });
        const items = Array.isArray(res?.items) ? res.items : [];
        if (!items.length) break;

        for (let i = 0; i < items.length; i++) {
            const rawIt = items[i];
            const it = (rawIt?.value_type === "repost" && rawIt?.reposted_claim && rawIt.reposted_claim.value)
                ? rawIt.reposted_claim
                : rawIt;
            if (!it || !it.value) continue;

            const ch = it.signing_channel || rawIt?.signing_channel;
            const claimId = it.claim_id || rawIt?.claim_id || "";
            const name = it.name || rawIt?.name || "";
            const playUrl = it.canonical_url || it.permanent_url || (name && claimId ? `https://odysee.com/${name}:${claimId}` : "");
            if (!playUrl || seen.has(playUrl)) continue;
            seen.add(playUrl);

            const authorName = ch?.value?.title || ch?.name || fallbackAuthorName || "s4vitar";
            const authorUrl = ch?.canonical_url || ch?.permanent_url || fallbackAuthorUrl || "https://odysee.com/@s4visinfiltro:8";
            const authorThumb = ch?.value?.thumbnail?.url || fallbackAuthorThumb || "";

            vids.push(new PlatformVideo({
                id: makeId(claimId || playUrl),
                name: it.value?.title || it.name || "Sin título",
                thumbnails: makeThumbs(it.value?.thumbnail?.url || ""),
                author: makeAuthor(authorName, authorUrl, authorThumb),
                url: playUrl,
                isLive: false,
                duration: it.value?.video?.duration || it.value?.audio?.duration || 0,
                viewCount: -1,
                datetime: parseInt(it.value?.release_time ?? it.timestamp ?? 0, 10) || 0
            }));
        }

        if (items.length < pageSize) break;
        page++;
    }

    return vids;
}

function collectCreatorCandidates(list, target, out, seen) {
    if (!Array.isArray(list)) return;
    for (let i = 0; i < list.length; i++) {
        const v = list[i];
        if (!v || !v.url || seen.has(v.url)) continue;
        const vAuthor = String(v.author?.name || "").trim().toLowerCase();
        const vAuthorUrl = String(v.author?.url || "").trim().toLowerCase();
        if (!target || vAuthor === target || vAuthorUrl.endsWith("/usuario/" + target)) {
            seen.add(v.url);
            out.push(v);
        }
    }
}

function fetchHackStreamCreatorVideos(creatorName) {
    const rawName = String(creatorName || "").trim();
    const target = rawName.toLowerCase();
    const out = [];
    const seen = new Set();

    // 1) Página del usuario en HackStream (/usuario/<creatorName>)
    if (rawName) {
        try {
            const userHtml = fetchWatchHtml(`${HACKSTREAM_BASE}/usuario/${encodeURIComponent(rawName)}`);
            const pageVids = parseVideosFromHtml(userHtml);
            for (let i = 0; i < pageVids.length; i++) {
                const v = pageVids[i];
                if (v && v.url && !seen.has(v.url)) {
                    seen.add(v.url);
                    out.push(v);
                }
            }
        } catch (_) {}
    }

    // 2) Búsqueda en API de HackStream por nombre de creador
    if (rawName) {
        try {
            const resp = http.GET(`${HACKSTREAM_SEARCH_API}?q=${encodeURIComponent(rawName)}`, API_HEADERS, false);
            if (resp && resp.isOk && resp.body) {
                const raw = JSON.parse(resp.body);
                const list = Array.isArray(raw)
                    ? raw
                    : (raw?.videos || raw?.items || raw?.results || raw?.data || []);
                const apiVids = [];
                for (let i = 0; i < list.length; i++) {
                    const it = list[i];
                    if (!it) continue;
                    const v = buildVideoItem({
                        slug: it.slug || it.videoSlug || "",
                        title: it.title || it.name || "Sin título",
                        thumbnailUrl: it.thumbnailUrl || it.thumbnail || it.image || "",
                        duration: it.duration || 0,
                        publishedAt: it.publishedAt || it.createdAt || it.uploadDate || it.published_at || it.created_at || it.upload_date || it.date || 0,
                        views: typeof it.views === "number" ? it.views : (typeof it.viewCount === "number" ? it.viewCount : -1),
                        creatorName: it.creatorName || it.author?.name || it.user?.username || rawName,
                        videoId: it.id || it.videoId || it.slug,
                        odyseeUrl: it.odyseeUrl || it.embedUrl || ""
                    });
                    if (v) apiVids.push(v);
                }
                collectCreatorCandidates(apiVids, target, out, seen);
            }
        } catch (_) {}
    }

    // 3) Páginas de inicio/explorar filtradas por creador
    for (let p = 1; p <= 5; p++) {
        try {
            const list = fetchHomeVideos(p);
            if (!list.length) break;
            collectCreatorCandidates(list, target, out, seen);
        } catch (_) {
            break;
        }
    }

    return out;
}

source.enable = function (config, settings) {
    localConfig = config || {};
    localSettings = settings || {};
    clearAllCaches();
};

source.getHome = function () {
    return new HomePager(fetchHomeVideos(1), 1);
};

source.search = function (query) {
    const q = (query || "").trim();
    if (!q) return new VideoPager([], false);

    const resp = http.GET(`${HACKSTREAM_SEARCH_API}?q=${encodeURIComponent(q)}`, API_HEADERS, false);
    if (!resp || !resp.isOk) {
        throw new ScriptException(`Error al buscar en HackStream (HTTP ${resp?.code ?? "unknown"})`);
    }

    const raw = JSON.parse(resp.body);
    const list = Array.isArray(raw)
        ? raw
        : (raw?.videos || raw?.items || raw?.results || raw?.data || []);

    const videos = [];
    for (let i = 0; i < list.length; i++) {
        const it = list[i];
        if (!it) continue;
        const v = buildVideoItem({
            slug: it.slug || it.videoSlug || "",
            title: it.title || it.name || "Sin título",
            thumbnailUrl: it.thumbnailUrl || it.thumbnail || it.image || "",
            duration: it.duration || 0,
            publishedAt: it.publishedAt || it.createdAt || it.uploadDate || it.published_at || it.created_at || it.upload_date || it.date || 0,
            views: typeof it.views === "number" ? it.views : (typeof it.viewCount === "number" ? it.viewCount : -1),
            creatorName: it.creatorName || it.author?.name || it.user?.username || "s4vitar",
            videoId: it.id || it.videoId || it.slug,
            odyseeUrl: it.odyseeUrl || it.embedUrl || ""
        });
        if (v) videos.push(v);
    }
    return new VideoPager(videos, false);
};

source.getContentRecommendations = function (url) {
    const currentSlug = extractHackStreamSlug(url);
    let list = [];
    if (String(url || "").includes("hackstream.io/watch/")) {
        try { list = parseVideosFromHtml(fetchWatchHtml(url)); } catch (_) {}
    }
    if (!list.length) {
        try { list = fetchHomeVideos(1); } catch (_) { return new VideoPager([], false); }
    }
    const out = [];
    for (let i = 0; i < list.length; i++) {
        const v = list[i];
        if (!v) continue;
        if (currentSlug && v.url && v.url.includes(`/watch/${currentSlug}`)) continue;
        out.push(v);
        if (out.length >= 15) break;
    }
    return new VideoPager(out, false);
};

source.getChannel = function (url) {
    if (url && isOdyseeOrLbryUrl(url)) {
        const claim = resolveClaim(toLbryUri(url));
        if (claim) {
            return new PlatformChannel({
                id: makeId(claim.claim_id || url),
                name: claim.value?.title || claim.name || "s4vitar",
                url: claim.canonical_url || claim.permanent_url || url,
                thumbnail: normalizeUrl(claim.value?.thumbnail?.url || ""),
                description: claim.value?.description || "",
                subscribers: -1
            });
        }
    }
    const m = /\/usuario\/([^/?#]+)/.exec(url || "");
    const name = m ? urlDecode(m[1]) : "s4vitar";
    return new PlatformChannel({
        id: makeId(url || name),
        name: name,
        url: url || `${HACKSTREAM_BASE}/usuario/admin`,
        thumbnail: "",
        description: "Creador en HackStream",
        subscribers: -1
    });
};

source.getChannelContents = function (url) {
    if (url && isOdyseeOrLbryUrl(url)) {
        const claim = resolveClaim(toLbryUri(url));
        if (claim?.claim_id) {
            const vids = fetchAllChannelVideos(
                claim.claim_id,
                claim.value?.title || claim.name || "s4vitar",
                claim.canonical_url || claim.permanent_url || url,
                claim.value?.thumbnail?.url || ""
            );
            return new VideoPager(vids, false);
        }
    }
    const m = /\/usuario\/([^/?#]+)/.exec(url || "");
    const creatorName = m ? urlDecode(m[1]) : "";
    return new VideoPager(fetchHackStreamCreatorVideos(creatorName), false);
};

source.sansonComments = function (url, token) {
    let claimId = "";
    try {
        let odyUrl = String(url || "");
        if (odyUrl.includes("hackstream.io/watch/")) {
            const slug = extractHackStreamSlug(odyUrl);
            odyUrl = HS_ODYSEE_MAP.get(slug) || extractWatchInfo(fetchWatchHtml(odyUrl)).embedUrl || "";
        }
        const claim = resolveClaim(toLbryUri(odyUrl));
        claimId = claim?.claim_id || "";
    } catch (e) {
        traceMsg("Error resolviendo claim para comentarios: " + e);
    }

    if (!claimId) return { comments: [], next: "", disabled: true };

    const page = token ? (parseInt(token, 10) || 1) : 1;
    const pageSize = 20;
    let res;
    try {
        res = rpcCall("comment.List", {
            claim_id: claimId,
            page: page,
            page_size: pageSize,
            top_level: false,
            sort_by: 0
        }, URL_COMMENTS);
    } catch (e) {
        traceMsg("Comentarios no disponibles: " + e);
        return { comments: [], next: "", disabled: true };
    }

    if (!res) return { comments: [], next: "", disabled: true };
    const rawItems = Array.isArray(res?.items) ? res.items : [];
    const comments = [];
    for (let i = 0; i < rawItems.length; i++) {
        const it = rawItems[i];
        if (!it) continue;
        const ch = it.signing_channel;
        const baseAuthor = it.channel_name || ch?.value?.title || ch?.name || "Anónimo";
        const author = it.parent_id ? `↳ ${baseAuthor}` : baseAuthor;
        const text = it.comment ?? it.text ?? "";
        const ts = Number(it.timestamp || 0);
        const when = ts > 0 ? new Date(ts * 1000).toISOString().slice(0, 10) : "";
        const likes = it.support_amount != null ? String(it.support_amount) : (it.likes != null ? String(it.likes) : "");
        const replies = it.replies != null ? String(it.replies) : "";
        comments.push({ author, text, when, likes, replies });
    }

    const totalPages = Number(res?.total_pages || 0);
    const hasMore = totalPages > 0 ? page < totalPages : rawItems.length >= pageSize;
    return {
        comments,
        next: hasMore ? String(page + 1) : "",
        count: res?.total_items != null ? String(res.total_items) : String(comments.length)
    };
};

source.getContentDetails = function (url) {
    const rawUrl = String(url || "").trim();
    if (!rawUrl) throw new ScriptException("URL vacía en getContentDetails");

    let watchMeta = { title: "", description: "", thumbnailUrl: "", duration: 0, embedUrl: "", datetime: 0 };
    let odyseeUrl = rawUrl;

    if (rawUrl.includes("hackstream.io/watch/")) {
        const slug = extractHackStreamSlug(rawUrl);
        try {
            const html = fetchWatchHtml(rawUrl);
            watchMeta = extractWatchInfo(html);
            odyseeUrl = watchMeta.embedUrl || HS_ODYSEE_MAP.get(slug) || rawUrl;
            if (slug && odyseeUrl) HS_ODYSEE_MAP.set(slug, odyseeUrl);
        } catch (_) {
            odyseeUrl = HS_ODYSEE_MAP.get(slug) || rawUrl;
        }
    }

    let claim = null;
    try {
        const uri = toLbryUri(odyseeUrl);
        claim = resolveClaim(uri);
    } catch (e) {
        traceMsg("Aviso resolviendo claim en metadata: " + e);
    }

    const { sources, isLive } = buildSourcesFromClaim(claim, rawUrl, odyseeUrl);
    if (!sources.length) {
        throw new UnavailableException("No se obtuvieron fuentes de reproducción para este vídeo");
    }

    const val = claim?.value || {};
    const title = watchMeta.title || val.title || claim?.name || "Vídeo de HackStream";
    const thumb = normalizeUrl(watchMeta.thumbnailUrl) || normalizeUrl(val.thumbnail?.url || "");
    const duration = watchMeta.duration || val.video?.duration || val.audio?.duration || 0;
    const description = watchMeta.description || val.description || title;
    const datetime = watchMeta.datetime
        || parseUnixDate(val.release_time)
        || parseUnixDate(claim?.timestamp)
        || 0;

    const ch = claim?.signing_channel;
    const authorName = ch?.value?.title || ch?.name || "s4vitar";
    const authorUrl = ch?.canonical_url || ch?.permanent_url || "https://odysee.com/@s4visinfiltro:8";
    const authorThumb = ch?.value?.thumbnail?.url || "";

    return new PlatformVideoDetails({
        id: makeId(claim?.claim_id || rawUrl),
        name: title,
        thumbnails: makeThumbs(thumb),
        author: makeAuthor(authorName, authorUrl, authorThumb),
        url: rawUrl,
        isLive: isLive,
        duration: duration,
        viewCount: -1,
        description: description,
        datetime: datetime,
        video: new VideoSourceDescriptor(sources)
    });
};

source.sansonFeed = function (urls) {
    if (!Array.isArray(urls) || !urls.length) {
        return new VideoPager([], false);
    }

    const channelIds = [];
    for (let i = 0; i < urls.length; i++) {
        const raw = String(urls[i] || "").trim();
        if (!raw) continue;

        let cid = "";
        let slug = "";
        if (raw.startsWith("lbry://")) {
            const m = /^lbry:\/\/@([^#\/]+)#([a-fA-F0-9]+)/.exec(raw);
            if (m) { slug = m[1]; cid = m[2]; }
        } else {
            const m = /@([^\/:?#]+)[:#]([a-fA-F0-9]+)/.exec(raw);
            if (m) { slug = m[1]; cid = m[2]; }
        }
        if (!cid) continue;

        if (cid.length < 40 && slug) {
            try {
                const full = resolveClaim(`lbry://@${slug}#${cid}`);
                if (full?.claim_id) {
                    traceMsg(`sansonFeed: ${slug} short=${cid} -> claim_id=${full.claim_id}`);
                    cid = full.claim_id;
                } else {
                    traceMsg(`sansonFeed: no se pudo resolver ${slug}#${cid}, se omite`);
                    continue;
                }
            } catch (e) {
                traceMsg(`sansonFeed: error resolviendo ${slug}#${cid}: ${e}`);
                continue;
            }
        }

        if (cid && !channelIds.includes(cid)) channelIds.push(cid);
    }

    if (!channelIds.length) {
        traceMsg("sansonFeed: ninguna URL contenía claim_id de canal; feed vacío");
        return new VideoPager([], false);
    }

    traceMsg(`sansonFeed: consultando ${channelIds.length} canal(es)`);

    let items = [];
    try {
        const res = rpcCall("claim_search", {
            channel_ids: channelIds,
            claim_type: ["stream", "repost"],
            order_by: ["release_time"],
            has_source: true,
            page: 1,
            page_size: 50,
            no_totals: true,
            not_tags: ["c:members-only"]
        });
        items = Array.isArray(res?.items) ? res.items : [];
    } catch (e) {
        traceMsg("sansonFeed: error en claim_search: " + e);
        return new VideoPager([], false);
    }

    if (!Array.isArray(items) || items.length === 0) {
        traceMsg("sansonFeed: claim_search devolvió 0 items. channel_ids=" + JSON.stringify(channelIds));
        try {
            const raw = rpcCall("claim_search", {
                channel_ids: channelIds,
                claim_type: ["stream", "repost"],
                order_by: ["release_time"],
                has_source: true,
                page: 1,
                page_size: 50,
                no_totals: true
            });
            traceMsg("sansonFeed: respuesta cruda (sin not_tags)=" + JSON.stringify(raw).slice(0, 800));
        } catch (e2) {
            traceMsg("sansonFeed: reintento sin not_tags falló: " + e2);
        }
    }

    const videos = [];
    for (let i = 0; i < items.length; i++) {
        const it = items[i];
        if (!it || !it.value) continue;

        const ch = it.signing_channel;
        const claimId = it.claim_id || "";
        const name = it.name || "";
        const title = it.value.title || name || "Sin título";
        let thumb = it.value.thumbnail?.url || "";
        if (thumb.startsWith("//")) thumb = "https:" + thumb;
        const duration = it.value.video?.duration || it.value.audio?.duration || 0;
        const datetime = parseInt(it.value.release_time ?? it.timestamp ?? 0, 10) || 0;

        const odyseeUrl = it.canonical_url
            || (name && claimId ? `https://odysee.com/${name}:${claimId}` : "");
        if (!odyseeUrl) continue;

        const slugGuess = name && claimId ? `${name}-${claimId}` : claimId;
        if (slugGuess) HS_ODYSEE_MAP.set(slugGuess, odyseeUrl);

        videos.push(new PlatformVideo({
            id: makeId(claimId || odyseeUrl),
            name: title,
            thumbnails: makeThumbs(thumb),
            author: makeAuthor(
                ch?.value?.title || ch?.name || "Odysee",
                ch?.canonical_url || ch?.permanent_url || "",
                ch?.value?.thumbnail?.url || ""
            ),
            url: odyseeUrl,
            isLive: false,
            duration: duration,
            viewCount: -1,
            datetime: datetime
        }));
    }

    videos.sort((a, b) => (b.datetime || 0) - (a.datetime || 0));
    const seen = new Set();
    const out = [];
    for (let i = 0; i < videos.length; i++) {
        if (!seen.has(videos[i].url)) {
            seen.add(videos[i].url);
            out.push(videos[i]);
        }
    }

    traceMsg(`sansonFeed: ${out.length} vídeo(s) devueltos`);
    return new VideoPager(out, false);
};
