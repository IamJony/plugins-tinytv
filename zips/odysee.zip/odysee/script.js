"use strict";

const PLATFORM = "Odysee";
const URL_CLAIM_SEARCH = "https://api.na-backend.odysee.com/api/v1/proxy?m=claim_search";
const URL_RESOLVE = "https://api.na-backend.odysee.com/api/v1/proxy?m=resolve";
const URL_CONTENT = "https://odysee.com/$/api/content/v2/get";
const URL_SEARCH = "https://lighthouse.odysee.tv/search";
const URL_COMMENTS = "https://comments.odysee.com/api/v2?m=comment.List";

const DEFAULT_UA = "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/136.0.0.0 Safari/537.36";

const JSON_HEADERS = {
    "Content-Type": "application/json",
    "Origin": "https://odysee.com",
    "Referer": "https://odysee.com/",
    "User-Agent": DEFAULT_UA
};

const STREAM_HEADERS = {
    "User-Agent": DEFAULT_UA
};

const MATURE_TAGS = new Set([
    "porn", "porno", "nsfw", "mature", "xxx", "sex",
    "creampie", "blowjob", "handjob", "vagina", "boobs",
    "pussy", "cumshot", "anal", "fuck", "hentai"
]);

const MATURE_TAGS_LIST = Array.from(MATURE_TAGS);

const CLAIM_CACHE = new Map();
const CLAIM_CACHE_TTL_MS = 5 * 60 * 1000;

function getCachedClaim(key) {
    if (!key) return null;
    const entry = CLAIM_CACHE.get(key);
    if (!entry) return null;
    if ((Date.now() - entry.ts) > CLAIM_CACHE_TTL_MS) {
        CLAIM_CACHE.delete(key);
        return null;
    }
    return entry.value;
}

function setCachedClaim(key, value) {
    if (key && value) {
        CLAIM_CACHE.set(key, { value, ts: Date.now() });
    }
}

let localConfig = {};
let localSettings = {};
let cachedPrimaryContent = null;
let primaryContentChecked = false;

function makeId(value) {
    if (typeof sansonPid === "function") {
        return sansonPid(PLATFORM, String(value ?? ""));
    }
    return new PlatformID(PLATFORM, String(value ?? ""), localConfig.id || "odysee");
}

const AUTHOR_CACHE = new Map();

function normalizeOdyseeUrl(name, claimId) {
    if (!claimId) return "";
    const n = name || "claim";
    return `https://odysee.com/${n}:${claimId}`;
}

function normalizeThumbUrl(url) {
    if (!url) return "";
    return String(url).trim();
}

function makeThumbs(url) {
    let cleanUrl = normalizeThumbUrl(url);
    // Thumbnails de Odysee vienen con // o con http://
    if (cleanUrl.startsWith("//")) cleanUrl = "https:" + cleanUrl;
    if (cleanUrl.startsWith("http://")) cleanUrl = "https://" + cleanUrl.slice(7);
    if (typeof sansonThumbs === "function") {
        return sansonThumbs(cleanUrl);
    }
    return new Thumbnails(cleanUrl ? [new Thumbnail(cleanUrl, 0)] : []);
}

function channelUrlFromOdysee(name, claimId) {
    if (!claimId) return "";
    const n = (name || "channel").replace(/^@/, "");
    return `https://odysee.com/@${n}:${claimId}`;
}

function makeAuthor(name, url, thumb) {
    const cleanName = name || "Odysee";
    const cleanUrl = url ? String(url).trim() : "";
    let cleanThumb = normalizeThumbUrl(thumb);
    if (cleanThumb.startsWith("//")) cleanThumb = "https:" + cleanThumb;
    const key = `${cleanUrl}|${cleanName}|${cleanThumb}`;

    const cached = AUTHOR_CACHE.get(key);
    if (cached) return cached;

    let authorObj;
    if (typeof sansonAuthor === "function") {
        // Orden correcto de sansonAuthor: (plat, id, name, url, thumb)
        const id = cleanUrl || cleanName || "author";
        authorObj = sansonAuthor(PLATFORM, id, cleanName, cleanUrl, cleanThumb);
    } else {
        authorObj = new PlatformAuthorLink(makeId(cleanUrl || cleanName || "author"), cleanName, cleanUrl, cleanThumb, null);
    }

    AUTHOR_CACHE.set(key, authorObj);
    return authorObj;
}

function safeTrace(msg) {
    if (typeof trace === "function") {
        trace(msg);
    } else if (typeof log === "function") {
        log(msg);
    }
}

function rpcPost(url, method, params) {
    const body = JSON.stringify({
        jsonrpc: "2.0",
        method: method,
        params: params || {},
        id: Date.now()
    });
    const resp = http.POST(url, body, JSON_HEADERS, false);
    if (!resp || !resp.isOk) {
        throw new ScriptException(`Error HTTP ${resp?.code ?? "unknown"} en ${method}`);
    }
    const parsed = JSON.parse(resp.body);
    if (parsed.error) {
        throw new ScriptException(parsed.error.message || parsed.error.name || `Error RPC en ${method}`);
    }
    return parsed.result;
}

function hasMatureTag(claim) {
    const tags = claim?.value?.tags;
    if (!Array.isArray(tags) || !tags.length) return false;
    for (let i = 0; i < tags.length; i++) {
        if (MATURE_TAGS.has(String(tags[i]).toLowerCase())) {
            return true;
        }
    }
    return false;
}

function unwrapClaim(claim) {
    if (!claim) return null;
    if (claim.value_type === "repost" && claim.reposted_claim?.value) {
        return claim.reposted_claim;
    }
    return claim;
}

function claimToVideo(claim, isLive = false) {
    const item = unwrapClaim(claim);
    if (!item || !item.value) return null;
    if (hasMatureTag(item)) return null;

    const streamType = item.value.stream_type;
    if (!isLive && streamType && streamType !== "video" && streamType !== "audio") {
        return null;
    }

    const claimId = item.claim_id || "";
    if (claimId) {
        setCachedClaim(`id:${claimId}`, item);
    }
    const name = item.name || "";
    const title = item.value.title || name || "Sin título";
    let thumb = item.value.thumbnail?.url || "";
    if (thumb.startsWith("//")) thumb = "https:" + thumb;
    const duration = isLive ? 0 : (item.value.video?.duration || item.value.audio?.duration || 0);
    const datetime = parseInt(item.value.release_time ?? item.timestamp ?? 0, 10) || 0;
    const url = normalizeOdyseeUrl(name, claimId);

    const channel = item.signing_channel;
    const channelName = channel?.value?.title || channel?.name || "Odysee";
    // Forzar URL HTTP del canal (evita lbry:// y thumbnails confundidos)
    const channelUrl = channelUrlFromOdysee(channel?.name, channel?.claim_id);
    let channelThumb = channel?.value?.thumbnail?.url || "";
    if (channelThumb.startsWith("//")) channelThumb = "https:" + channelThumb;

    return new PlatformVideo({
        id: makeId(claimId || url),
        name: title,
        thumbnails: makeThumbs(thumb),
        author: makeAuthor(channelName, channelUrl, channelThumb),
        url: url,
        isLive: !!isLive,
        duration: duration,
        viewCount: -1,
        datetime: datetime
    });
}

function claimsToVideos(claims, isLive = false) {
    if (!Array.isArray(claims)) return [];
    const out = [];
    for (let i = 0; i < claims.length; i++) {
        const v = claimToVideo(claims[i], isLive);
        if (v) out.push(v);
    }
    return out;
}

function getPrimaryContentConfig() {
    if (primaryContentChecked) {
        return cachedPrimaryContent;
    }
    primaryContentChecked = true;

    try {
        const cfgResp = http.GET(URL_CONTENT, JSON_HEADERS, false);
        if (cfgResp && cfgResp.isOk) {
            cachedPrimaryContent = JSON.parse(cfgResp.body)?.data?.en?.categories?.PRIMARY_CONTENT || null;
        }
    } catch (e) {
        safeTrace("No se pudo leer configuración de inicio de Odysee, usando feed por defecto: " + e);
    }

    return cachedPrimaryContent;
}

function fetchHomeQuery(page = 1, pageSize = 20) {
    const params = {
        page: page,
        page_size: pageSize,
        claim_type: ["stream"],
        stream_types: ["video"],
        order_by: ["trending_group", "trending_mixed"],
        has_source: true,
        no_totals: true,
        remove_duplicates: true,
        not_tags: ["c:members-only", ...MATURE_TAGS_LIST]
    };

    const cfgData = getPrimaryContentConfig();
    if (cfgData) {
        if (Array.isArray(cfgData.channelIds) && cfgData.channelIds.length) {
            params.channel_ids = cfgData.channelIds;
        }
        if (Array.isArray(cfgData.claimType) && cfgData.claimType.length) {
            params.claim_type = cfgData.claimType;
        }
    }

    const res = rpcPost(URL_CLAIM_SEARCH, "claim_search", params);
    return claimsToVideos(res?.items || [], false);
}

function resolveByClaimIds(claimIds) {
    if (!Array.isArray(claimIds) || !claimIds.length) return [];

    const byId = new Map();
    const missingIds = [];

    for (let i = 0; i < claimIds.length; i++) {
        const id = claimIds[i];
        if (!id) continue;
        const cached = getCachedClaim(`id:${id}`);
        if (cached) {
            byId.set(id, cached);
        } else if (!missingIds.includes(id)) {
            missingIds.push(id);
        }
    }

    if (missingIds.length) {
        const res = rpcPost(URL_CLAIM_SEARCH, "claim_search", {
            claim_ids: missingIds,
            page: 1,
            page_size: missingIds.length,
            no_totals: true
        });
        const items = res?.items || [];
        for (let i = 0; i < items.length; i++) {
            const unwrapped = unwrapClaim(items[i]);
            if (unwrapped?.claim_id) {
                byId.set(unwrapped.claim_id, unwrapped);
                setCachedClaim(`id:${unwrapped.claim_id}`, unwrapped);
            }
        }
    }

    const ordered = [];
    for (let i = 0; i < claimIds.length; i++) {
        const found = byId.get(claimIds[i]);
        if (found) ordered.push(found);
    }
    return claimsToVideos(ordered, false);
}

function parseOdyseeUrl(url) {
    if (!url) return null;
    let clean = String(url).trim();

    // lbry://@canal#claimId/slug#claimId -> https://odysee.com/@canal:claimId/slug:claimId
    if (clean.startsWith("lbry://")) {
        clean = clean.slice(7);
        // lbry usa # para separar claim id, odysee usa :
        // @canal#id -> @canal:id ; @canal#id/slug#id -> @canal:id/slug:id
        clean = clean.replace(/#([a-fA-F0-9]+)/g, ":$1");
        clean = "https://odysee.com/" + clean;
    }

    // Extraer el nombre y claimId del canal (con @)
    const chanMatch = /@([^/:?#]+)(?::|#)([a-fA-F0-9]+)/.exec(clean);

    // Extraer TODOS los pares slug:claimId (vídeo y canal)
    const videoMatches = [...clean.matchAll(/([^/@:?#]+)(?::|#)([a-fA-F0-9]+)/g)];

    if (videoMatches.length >= 2) {
        const last = videoMatches[videoMatches.length - 1];
        return {
            kind: "video",
            slug: decodeURIComponent(last[1]),
            claimId: last[2]
        };
    }

    if (chanMatch) {
        return {
            kind: "channel",
            slug: decodeURIComponent(chanMatch[1]),
            claimId: chanMatch[2]
        };
    }

    if (videoMatches.length === 1) {
        const only = videoMatches[0];
        if (only[1].startsWith("@")) {
            return {
                kind: "channel",
                slug: decodeURIComponent(only[1]),
                claimId: only[2]
            };
        }
        return {
            kind: "video",
            slug: decodeURIComponent(only[1]),
            claimId: only[2]
        };
    }

    return null;
}

function resolveClaimSingle(slug, claimId) {
    const idKey = claimId ? `id:${claimId}` : "";
    const slugKey = slug ? `slug:${slug}` : "";

    const cachedById = getCachedClaim(idKey);
    if (cachedById) return cachedById;

    const cachedBySlug = getCachedClaim(slugKey);
    if (cachedBySlug) return cachedBySlug;

    let resolved = null;

    if (claimId) {
        const res = rpcPost(URL_CLAIM_SEARCH, "claim_search", {
            claim_ids: [claimId],
            page: 1,
            page_size: 1,
            no_totals: true
        });
        if (res?.items?.length) {
            resolved = unwrapClaim(res.items[0]);
        }
    }

    if (!resolved && slug && claimId) {
        const uri = `lbry://${slug}#${claimId}`;
        const res = rpcPost(URL_RESOLVE, "resolve", { urls: [uri] });
        const claim = res?.[uri];
        if (claim && !claim.error) {
            resolved = unwrapClaim(claim);
        }
    }

    if (resolved) {
        setCachedClaim(idKey, resolved);
        setCachedClaim(slugKey, resolved);
    }

    return resolved;
}

class OdyseeHomePager extends VideoPager {
    constructor(results, page, pageSize) {
        super(results, Array.isArray(results) && results.length > 0, { page, pageSize });
    }

    nextPage() {
        const nextP = (this.context.page || 1) + 1;
        const size = this.context.pageSize || 20;
        const more = fetchHomeQuery(nextP, size);
        return new OdyseeHomePager(more, nextP, size);
    }
}

source.enable = function (config, settings) {
    localConfig = config || {};
    localSettings = settings || {};
    cachedPrimaryContent = null;
    primaryContentChecked = false;
    CLAIM_CACHE.clear();
    AUTHOR_CACHE.clear();
};

source.getHome = function () {
    const pageSize = 20;
    const results = fetchHomeQuery(1, pageSize);
    return new OdyseeHomePager(results, 1, pageSize);
};

source.search = function (query) {
    const q = (query || "").trim();
    if (!q) {
        return new VideoPager([], false);
    }

    const searchUrl = `${URL_SEARCH}?s=${encodeURIComponent(q)}&from=0&size=20&nsfw=false&claimType=file&mediaType=video`;
    const resp = http.GET(searchUrl, JSON_HEADERS, false);
    if (!resp || !resp.isOk) {
        throw new ScriptException(`Error al buscar en Odysee (${resp?.code ?? "unknown"})`);
    }

    const rawList = JSON.parse(resp.body);
    if (!Array.isArray(rawList) || !rawList.length) {
        return new VideoPager([], false);
    }

    const ids = [];
    for (let i = 0; i < rawList.length; i++) {
        if (rawList[i]?.claimId) ids.push(rawList[i].claimId);
    }
    const videos = resolveByClaimIds(ids);
    return new VideoPager(videos, false);
};

source.getChannel = function (url) {
    const cleanUrl = String(url || "").trim();
    // Si nos pasan un thumbnail por error, no es un canal
    if (cleanUrl.includes("thumbnails.") || cleanUrl.includes("spee.ch") || cleanUrl.includes("odycdn.com")) {
        throw new ScriptException("URL de canal no válida (es un thumbnail): " + url);
    }
    const parsed = parseOdyseeUrl(cleanUrl);
    if (!parsed || !parsed.claimId) {
        throw new ScriptException("URL de canal de Odysee no válida: " + url);
    }

    const claim = resolveClaimSingle(parsed.slug, parsed.claimId);
    if (!claim) {
        throw new ScriptException("No se pudo resolver el canal: " + url);
    }

    const title = claim.value?.title || claim.name || parsed.slug || "Canal Odysee";
    let thumb = claim.value?.thumbnail?.url || "";
    if (thumb.startsWith("//")) thumb = "https:" + thumb;
    const desc = claim.value?.description || "";

    const channelUrl = channelUrlFromOdysee(claim.name || parsed.slug, claim.claim_id || parsed.claimId);
    return new PlatformChannel({
        id: makeId(claim.claim_id || parsed.claimId),
        name: title,
        url: channelUrl,
        thumbnail: thumb,
        description: desc,
        subscribers: -1
    });
};

source.getChannelContents = function (url) {
    const parsed = parseOdyseeUrl(url);
    if (!parsed || !parsed.claimId) {
        return new VideoPager([], false);
    }

    const res = rpcPost(URL_CLAIM_SEARCH, "claim_search", {
        channel_ids: [parsed.claimId],
        claim_type: ["stream", "repost"],
        order_by: ["release_time"],
        has_source: true,
        page: 1,
        page_size: 30,
        no_totals: true,
        not_tags: ["c:members-only", ...MATURE_TAGS_LIST]
    });

    const videos = claimsToVideos(res?.items || [], false);
    return new VideoPager(videos, false);
};

source.sansonComments = function (url, token) {
    const parsed = parseOdyseeUrl(url);
    let claimId = parsed?.claimId;

    if (url && (parsed?.slug || parsed?.claimId)) {
        try {
            const claim = resolveClaimSingle(parsed?.slug, parsed?.claimId);
            if (claim?.claim_id) {
                claimId = claim.claim_id;
            }
        } catch (e) {
            safeTrace("No se pudo resolver claim para comentarios: " + e);
        }
    }

    if (!claimId) {
        return { comments: [], next: "", disabled: true };
    }

    const page = token ? (parseInt(token, 10) || 1) : 1;
    const pageSize = 20;

    let result;
    try {
        result = rpcPost(URL_COMMENTS, "comment.List", {
            claim_id: claimId,
            page: page,
            page_size: pageSize,
            top_level: false,
            sort_by: 0
        });
    } catch (e) {
        safeTrace("Comentarios no disponibles: " + e);
        return { comments: [], next: "", disabled: true };
    }

    const rawItems = Array.isArray(result?.items) ? result.items : [];
    const comments = [];

    for (let i = 0; i < rawItems.length; i++) {
        const it = rawItems[i];
        if (!it) continue;
        const ch = it.signing_channel;
        const isReply = !!it.parent_id;
        const baseAuthor = it.channel_name || ch?.value?.title || ch?.name || "Anónimo";
        const author = isReply ? `↳ ${baseAuthor}` : baseAuthor;
        const text = it.comment ?? it.text ?? "";
        const ts = Number(it.timestamp || 0);
        const when = ts > 0 ? new Date(ts * 1000).toISOString().slice(0, 10) : "";
        const likes = it.support_amount != null ? String(it.support_amount) : (it.likes != null ? String(it.likes) : "");
        const replies = it.replies != null ? String(it.replies) : "";

        comments.push({
            author,
            text,
            when,
            likes,
            replies
        });
    }

    const totalPages = Number(result?.total_pages || 0);
    const hasMore = totalPages > 0 ? page < totalPages : rawItems.length >= pageSize;
    const next = hasMore ? String(page + 1) : "";
    const count = result?.total_items != null ? String(result.total_items) : String(comments.length);

    return { comments, next, count };
};

source.sansonFeed = function (urls) {
    if (!Array.isArray(urls) || !urls.length) {
        return new VideoPager([], false);
    }

    // Extraer los claimIds de los canales
    const channelIds = [];
    for (let i = 0; i < urls.length; i++) {
        const parsed = parseOdyseeUrl(urls[i]);
        if (parsed?.claimId && !channelIds.includes(parsed.claimId)) {
            channelIds.push(parsed.claimId);
        }
    }

    if (!channelIds.length) {
        return new VideoPager([], false);
    }

    // Pedir los vídeos de todos los canales a la vez (Odysee soporta channel_ids en array)
    // Ordenamos por release_time (más recientes primero)
    let items = [];
    try {
        const res = rpcPost(URL_CLAIM_SEARCH, "claim_search", {
            channel_ids: channelIds,
            claim_type: ["stream", "repost"],
            order_by: ["release_time"],
            has_source: true,
            page: 1,
            page_size: 50,
            no_totals: true,
            not_tags: ["c:members-only", ...MATURE_TAGS_LIST]
        });
        items = res?.items || [];
    } catch (e) {
        safeTrace("Error cargando el feed de Odysee: " + e);
        return new VideoPager([], false);
    }

    // Convertir claims a vídeos y ordenar por fecha descendente
    const videos = claimsToVideos(items, false);
    videos.sort((a, b) => (b.datetime || 0) - (a.datetime || 0));

    // Deduplicar por url (por si hay reposts duplicados)
    const seen = new Set();
    const out = [];
    for (let i = 0; i < videos.length; i++) {
        if (!seen.has(videos[i].url)) {
            seen.add(videos[i].url);
            out.push(videos[i]);
        }
    }

    return new VideoPager(out, false);
};

source.getContentDetails = function (url) {
    const parsed = parseOdyseeUrl(url);
    const claim = resolveClaimSingle(parsed?.slug, parsed?.claimId);
    if (!claim) {
        throw new ScriptException("No se pudo obtener el detalle del video en Odysee");
    }

    const claimId = claim.claim_id;
    const name = claim.name;
    const title = claim.value?.title || name || "Video de Odysee";
    let thumb = claim.value?.thumbnail?.url || "";
    if (thumb.startsWith("//")) thumb = "https:" + thumb;
    const duration = claim.value?.video?.duration || claim.value?.audio?.duration || 0;
    const sdHash = claim.value?.source?.sd_hash || "";
    const channel = claim.signing_channel;
    const channelName = channel?.value?.title || channel?.name || "Odysee";
    const channelUrl = channelUrlFromOdysee(channel?.name, channel?.claim_id);
    let channelThumb = channel?.value?.thumbnail?.url || "";
    if (channelThumb.startsWith("//")) channelThumb = "https:" + channelThumb;

    // URL HTTP de Odysee: canonical_url devuelve lbry:// y el proxy necesita https://
    const canonicalUrl = `https://odysee.com/${name}:${claimId}`;

    const sources = [];
    const isLive = !sdHash && !!channel?.claim_id;

    sources.push(new VideoUrlSource({
        name: isLive ? "En Vivo" : "Odysee (vía proxy)",
        url: canonicalUrl,
        container: isLive ? "m3u8" : "mp4",
        codec: "h264",
        width: claim.value?.video?.width || 0,
        height: claim.value?.video?.height || 0,
        bitrate: 0,
        duration: isLive ? 0 : duration,
        requestModifier: { headers: STREAM_HEADERS }
    }));

    const description = claim.value?.description || title;

    return new PlatformVideoDetails({
        id: makeId(claimId || url),
        name: title,
        thumbnails: makeThumbs(thumb),
        author: makeAuthor(channelName, channelUrl, channelThumb),
        url: normalizeOdyseeUrl(name, claimId) || url,
        isLive: !sdHash && !!channel?.claim_id,
        duration: duration,
        viewCount: -1,
        description: description,
        video: new VideoSourceDescriptor(sources)
    });
};
